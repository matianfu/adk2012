/*****************************************************************************
 *
 * Copyright (C) 2010 Atmel Corporation
 * 
 * Model        : UC3000
 * Revision     : $Revision: 83926 $
 * Checkin Date : $Date: 2010-04-27 15:13:30 +0200 (Tue, 27 Apr 2010) $ 
 *
 ****************************************************************************/
#ifndef AVR32_UC3000_ADCIFD_H_INCLUDED
#define AVR32_UC3000_ADCIFD_H_INCLUDED

#include "abi.h"

#include "avr32/adcifd_100.h"

/*#ifdef AVR32_UC3000_ADCIFD_H_INCLUDED*/
#endif

