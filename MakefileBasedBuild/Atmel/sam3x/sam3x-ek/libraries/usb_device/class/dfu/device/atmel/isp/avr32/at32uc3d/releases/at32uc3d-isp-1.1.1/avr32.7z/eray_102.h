/*****************************************************************************
 *
 * Copyright (C) 2009 Atmel Corporation
 * 
 * Model        : UC3000
 * Revision     : $Revision: 3615 $
 * Checkin Date : $Date: 2009-07-27 16:46:49 +0200 (må, 27 jul 2009) $ 
 *
 ****************************************************************************/
#ifndef AVR32_ERAY_102_H_INCLUDED
#define AVR32_ERAY_102_H_INCLUDED

#include "avr32/abi.h"


/*
 Note to user:

 The following defines are always generated:
 - Register offset: AVR32_ERAY_<register>
 - Bitfield mask:   AVR32_ERAY_<register>_<bitfield>
 - Bitfield offset: AVR32_ERAY_<register>_<bitfield>_OFFSET
 - Bitfield size:   AVR32_ERAY_<register>_<bitfield>_SIZE
 - Bitfield values: AVR32_ERAY_<register>_<bitfield>_<value name>

 The following defines are generated if they don't cause ambiguities,
 i.e. the name is unique, or all values with that name are the same.
 - Bitfield mask:   AVR32_ERAY_<bitfield>
 - Bitfield offset: AVR32_ERAY_<bitfield>_OFFSET
 - Bitfield size:   AVR32_ERAY_<bitfield>_SIZE
 - Bitfield values: AVR32_ERAY_<bitfield>_<value name>
 - Bitfield values: AVR32_ERAY_<value name>

 All defines are sorted alphabetically.
*/


#define AVR32_ERAY_ACS                                      0x00000128
#define AVR32_ERAY_ACS_CEDA                                          2
#define AVR32_ERAY_ACS_CEDA_MASK                            0x00000004
#define AVR32_ERAY_ACS_CEDA_OFFSET                                   2
#define AVR32_ERAY_ACS_CEDA_SIZE                                     1
#define AVR32_ERAY_ACS_CEDB                                         10
#define AVR32_ERAY_ACS_CEDB_MASK                            0x00000400
#define AVR32_ERAY_ACS_CEDB_OFFSET                                  10
#define AVR32_ERAY_ACS_CEDB_SIZE                                     1
#define AVR32_ERAY_ACS_CIA                                           3
#define AVR32_ERAY_ACS_CIA_MASK                             0x00000008
#define AVR32_ERAY_ACS_CIA_OFFSET                                    3
#define AVR32_ERAY_ACS_CIA_SIZE                                      1
#define AVR32_ERAY_ACS_CIB                                          11
#define AVR32_ERAY_ACS_CIB_MASK                             0x00000800
#define AVR32_ERAY_ACS_CIB_OFFSET                                   11
#define AVR32_ERAY_ACS_CIB_SIZE                                      1
#define AVR32_ERAY_ACS_MASK                                 0x00001f1f
#define AVR32_ERAY_ACS_RESETVALUE                           0x00000000
#define AVR32_ERAY_ACS_SBVA                                          4
#define AVR32_ERAY_ACS_SBVA_MASK                            0x00000010
#define AVR32_ERAY_ACS_SBVA_OFFSET                                   4
#define AVR32_ERAY_ACS_SBVA_SIZE                                     1
#define AVR32_ERAY_ACS_SBVB                                         12
#define AVR32_ERAY_ACS_SBVB_MASK                            0x00001000
#define AVR32_ERAY_ACS_SBVB_OFFSET                                  12
#define AVR32_ERAY_ACS_SBVB_SIZE                                     1
#define AVR32_ERAY_ACS_SEDA                                          1
#define AVR32_ERAY_ACS_SEDA_MASK                            0x00000002
#define AVR32_ERAY_ACS_SEDA_OFFSET                                   1
#define AVR32_ERAY_ACS_SEDA_SIZE                                     1
#define AVR32_ERAY_ACS_SEDB                                          9
#define AVR32_ERAY_ACS_SEDB_MASK                            0x00000200
#define AVR32_ERAY_ACS_SEDB_OFFSET                                   9
#define AVR32_ERAY_ACS_SEDB_SIZE                                     1
#define AVR32_ERAY_ACS_VFRA                                          0
#define AVR32_ERAY_ACS_VFRA_MASK                            0x00000001
#define AVR32_ERAY_ACS_VFRA_OFFSET                                   0
#define AVR32_ERAY_ACS_VFRA_SIZE                                     1
#define AVR32_ERAY_ACS_VFRB                                          8
#define AVR32_ERAY_ACS_VFRB_MASK                            0x00000100
#define AVR32_ERAY_ACS_VFRB_OFFSET                                   8
#define AVR32_ERAY_ACS_VFRB_SIZE                                     1
#define AVR32_ERAY_AOA                                               8
#define AVR32_ERAY_AOA_MASK                                 0x00000100
#define AVR32_ERAY_AOA_OFFSET                                        8
#define AVR32_ERAY_AOA_SIZE                                          1
#define AVR32_ERAY_AOB                                               9
#define AVR32_ERAY_AOB_MASK                                 0x00000200
#define AVR32_ERAY_AOB_OFFSET                                        9
#define AVR32_ERAY_AOB_SIZE                                          1
#define AVR32_ERAY_APO                                               0
#define AVR32_ERAY_APO_MASK                                 0x0000003f
#define AVR32_ERAY_APO_OFFSET                                        0
#define AVR32_ERAY_APO_SIZE                                          6
#define AVR32_ERAY_ASR                                               0
#define AVR32_ERAY_ASR_MASK                                 0x000007ff
#define AVR32_ERAY_ASR_OFFSET                                        0
#define AVR32_ERAY_ASR_SIZE                                         11
#define AVR32_ERAY_BN                                               16
#define AVR32_ERAY_BN_MASK                                  0x000f0000
#define AVR32_ERAY_BN_OFFSET                                        16
#define AVR32_ERAY_BN_SIZE                                           4
#define AVR32_ERAY_BRP                                              14
#define AVR32_ERAY_BRP_MASK                                 0x0000c000
#define AVR32_ERAY_BRP_OFFSET                                       14
#define AVR32_ERAY_BRP_SIZE                                          2
#define AVR32_ERAY_CAS                                               1
#define AVR32_ERAY_CASE                                              1
#define AVR32_ERAY_CASE_MASK                                0x00000002
#define AVR32_ERAY_CASE_OFFSET                                       1
#define AVR32_ERAY_CASE_SIZE                                         1
#define AVR32_ERAY_CASL                                              1
#define AVR32_ERAY_CASL_MASK                                0x00000002
#define AVR32_ERAY_CASL_OFFSET                                       1
#define AVR32_ERAY_CASL_SIZE                                         1
#define AVR32_ERAY_CASM                                              4
#define AVR32_ERAY_CASM_MASK                                0x000007f0
#define AVR32_ERAY_CASM_OFFSET                                       4
#define AVR32_ERAY_CASM_SIZE                                         7
#define AVR32_ERAY_CAS_MASK                                 0x00000002
#define AVR32_ERAY_CAS_OFFSET                                        1
#define AVR32_ERAY_CAS_SIZE                                          1
#define AVR32_ERAY_CCEV                                     0x00000104
#define AVR32_ERAY_CCEV_CCFC                                         0
#define AVR32_ERAY_CCEV_CCFC_MASK                           0x0000000f
#define AVR32_ERAY_CCEV_CCFC_OFFSET                                  0
#define AVR32_ERAY_CCEV_CCFC_SIZE                                    4
#define AVR32_ERAY_CCEV_ERRM                                         6
#define AVR32_ERAY_CCEV_ERRM_MASK                           0x000000c0
#define AVR32_ERAY_CCEV_ERRM_OFFSET                                  6
#define AVR32_ERAY_CCEV_ERRM_SIZE                                    2
#define AVR32_ERAY_CCEV_MASK                                0x00001fcf
#define AVR32_ERAY_CCEV_PTAC                                         8
#define AVR32_ERAY_CCEV_PTAC_MASK                           0x00001f00
#define AVR32_ERAY_CCEV_PTAC_OFFSET                                  8
#define AVR32_ERAY_CCEV_PTAC_SIZE                                    5
#define AVR32_ERAY_CCEV_RESETVALUE                          0x00000000
#define AVR32_ERAY_CCF                                               4
#define AVR32_ERAY_CCFC                                              0
#define AVR32_ERAY_CCFC_MASK                                0x0000000f
#define AVR32_ERAY_CCFC_OFFSET                                       0
#define AVR32_ERAY_CCFC_SIZE                                         4
#define AVR32_ERAY_CCFE                                              4
#define AVR32_ERAY_CCFE_MASK                                0x00000010
#define AVR32_ERAY_CCFE_OFFSET                                       4
#define AVR32_ERAY_CCFE_SIZE                                         1
#define AVR32_ERAY_CCFL                                              4
#define AVR32_ERAY_CCFL_MASK                                0x00000010
#define AVR32_ERAY_CCFL_OFFSET                                       4
#define AVR32_ERAY_CCFL_SIZE                                         1
#define AVR32_ERAY_CCF_MASK                                 0x00000010
#define AVR32_ERAY_CCF_OFFSET                                        4
#define AVR32_ERAY_CCF_SIZE                                          1
#define AVR32_ERAY_CCHA                                             26
#define AVR32_ERAY_CCHA_MASK                                0x04000000
#define AVR32_ERAY_CCHA_OFFSET                                      26
#define AVR32_ERAY_CCHA_SIZE                                         1
#define AVR32_ERAY_CCHB                                             27
#define AVR32_ERAY_CCHB_MASK                                0x08000000
#define AVR32_ERAY_CCHB_OFFSET                                      27
#define AVR32_ERAY_CCHB_SIZE                                         1
#define AVR32_ERAY_CCL                                               5
#define AVR32_ERAY_CCLE                                              5
#define AVR32_ERAY_CCLE_MASK                                0x00000020
#define AVR32_ERAY_CCLE_OFFSET                                       5
#define AVR32_ERAY_CCLE_SIZE                                         1
#define AVR32_ERAY_CCLL                                              5
#define AVR32_ERAY_CCLL_MASK                                0x00000020
#define AVR32_ERAY_CCLL_OFFSET                                       5
#define AVR32_ERAY_CCLL_SIZE                                         1
#define AVR32_ERAY_CCL_MASK                                 0x00000020
#define AVR32_ERAY_CCL_OFFSET                                        5
#define AVR32_ERAY_CCL_SIZE                                          1
#define AVR32_ERAY_CCR                                      0x00000804
#define AVR32_ERAY_CCR_BN                                           16
#define AVR32_ERAY_CCR_BN_MASK                              0x000f0000
#define AVR32_ERAY_CCR_BN_OFFSET                                    16
#define AVR32_ERAY_CCR_BN_SIZE                                       4
#define AVR32_ERAY_CCR_CKDIV                                         0
#define AVR32_ERAY_CCR_CKDIV_MASK                           0x000007ff
#define AVR32_ERAY_CCR_CKDIV_OFFSET                                  0
#define AVR32_ERAY_CCR_CKDIV_SIZE                                   11
#define AVR32_ERAY_CCR_MASK                                 0x000f07ff
#define AVR32_ERAY_CCR_RESETVALUE                           0x00000000
#define AVR32_ERAY_CCS                                              16
#define AVR32_ERAY_CCSV                                     0x00000100
#define AVR32_ERAY_CCSV_CSAI                                        13
#define AVR32_ERAY_CCSV_CSAI_MASK                           0x00002000
#define AVR32_ERAY_CCSV_CSAI_OFFSET                                 13
#define AVR32_ERAY_CCSV_CSAI_SIZE                                    1
#define AVR32_ERAY_CCSV_CSI                                         14
#define AVR32_ERAY_CCSV_CSI_MASK                            0x00004000
#define AVR32_ERAY_CCSV_CSI_OFFSET                                  14
#define AVR32_ERAY_CCSV_CSI_SIZE                                     1
#define AVR32_ERAY_CCSV_CSNI                                        12
#define AVR32_ERAY_CCSV_CSNI_MASK                           0x00001000
#define AVR32_ERAY_CCSV_CSNI_OFFSET                                 12
#define AVR32_ERAY_CCSV_CSNI_SIZE                                    1
#define AVR32_ERAY_CCSV_FSI                                          6
#define AVR32_ERAY_CCSV_FSI_MASK                            0x00000040
#define AVR32_ERAY_CCSV_FSI_OFFSET                                   6
#define AVR32_ERAY_CCSV_FSI_SIZE                                     1
#define AVR32_ERAY_CCSV_HRQ                                          7
#define AVR32_ERAY_CCSV_HRQ_MASK                            0x00000080
#define AVR32_ERAY_CCSV_HRQ_OFFSET                                   7
#define AVR32_ERAY_CCSV_HRQ_SIZE                                     1
#define AVR32_ERAY_CCSV_MASK                                0x3fff73ff
#define AVR32_ERAY_CCSV_POCS                                         0
#define AVR32_ERAY_CCSV_POCS_MASK                           0x0000003f
#define AVR32_ERAY_CCSV_POCS_OFFSET                                  0
#define AVR32_ERAY_CCSV_POCS_SIZE                                    6
#define AVR32_ERAY_CCSV_PSL                                         24
#define AVR32_ERAY_CCSV_PSL_MASK                            0x3f000000
#define AVR32_ERAY_CCSV_PSL_OFFSET                                  24
#define AVR32_ERAY_CCSV_PSL_SIZE                                     6
#define AVR32_ERAY_CCSV_RCA                                         19
#define AVR32_ERAY_CCSV_RCA_MASK                            0x00f80000
#define AVR32_ERAY_CCSV_RCA_OFFSET                                  19
#define AVR32_ERAY_CCSV_RCA_SIZE                                     5
#define AVR32_ERAY_CCSV_RESETVALUE                          0x00000000
#define AVR32_ERAY_CCSV_SLM                                          8
#define AVR32_ERAY_CCSV_SLM_MASK                            0x00000300
#define AVR32_ERAY_CCSV_SLM_OFFSET                                   8
#define AVR32_ERAY_CCSV_SLM_SIZE                                     2
#define AVR32_ERAY_CCSV_WSV                                         16
#define AVR32_ERAY_CCSV_WSV_MASK                            0x00070000
#define AVR32_ERAY_CCSV_WSV_OFFSET                                  16
#define AVR32_ERAY_CCSV_WSV_SIZE                                     3
#define AVR32_ERAY_CCS_MASK                                 0x003f0000
#define AVR32_ERAY_CCS_OFFSET                                       16
#define AVR32_ERAY_CCS_SIZE                                          6
#define AVR32_ERAY_CCV                                              16
#define AVR32_ERAY_CCV_MASK                                 0x003f0000
#define AVR32_ERAY_CCV_OFFSET                                       16
#define AVR32_ERAY_CCV_SIZE                                          6
#define AVR32_ERAY_CDD                                              16
#define AVR32_ERAY_CDD_MASK                                 0x001f0000
#define AVR32_ERAY_CDD_OFFSET                                       16
#define AVR32_ERAY_CDD_SIZE                                          5
#define AVR32_ERAY_CEDA                                              2
#define AVR32_ERAY_CEDA_MASK                                0x00000004
#define AVR32_ERAY_CEDA_OFFSET                                       2
#define AVR32_ERAY_CEDA_SIZE                                         1
#define AVR32_ERAY_CEDB                                             10
#define AVR32_ERAY_CEDB_MASK                                0x00000400
#define AVR32_ERAY_CEDB_OFFSET                                      10
#define AVR32_ERAY_CEDB_SIZE                                         1
#define AVR32_ERAY_CEOA                                              4
#define AVR32_ERAY_CEOA_MASK                                0x00000010
#define AVR32_ERAY_CEOA_OFFSET                                       4
#define AVR32_ERAY_CEOA_SIZE                                         1
#define AVR32_ERAY_CEOB                                              5
#define AVR32_ERAY_CEOB_MASK                                0x00000020
#define AVR32_ERAY_CEOB_OFFSET                                       5
#define AVR32_ERAY_CEOB_SIZE                                         1
#define AVR32_ERAY_CERA                                             24
#define AVR32_ERAY_CERA_MASK                                0x0f000000
#define AVR32_ERAY_CERA_OFFSET                                      24
#define AVR32_ERAY_CERA_SIZE                                         4
#define AVR32_ERAY_CERB                                             28
#define AVR32_ERAY_CERB_MASK                                0xf0000000
#define AVR32_ERAY_CERB_OFFSET                                      28
#define AVR32_ERAY_CERB_SIZE                                         4
#define AVR32_ERAY_CFG                                              26
#define AVR32_ERAY_CFG_MASK                                 0x04000000
#define AVR32_ERAY_CFG_OFFSET                                       26
#define AVR32_ERAY_CFG_SIZE                                          1
#define AVR32_ERAY_CH                                                0
#define AVR32_ERAY_CHA                                              24
#define AVR32_ERAY_CHA_MASK                                 0x01000000
#define AVR32_ERAY_CHA_OFFSET                                       24
#define AVR32_ERAY_CHA_SIZE                                          1
#define AVR32_ERAY_CHB                                              25
#define AVR32_ERAY_CHB_MASK                                 0x02000000
#define AVR32_ERAY_CHB_OFFSET                                       25
#define AVR32_ERAY_CHB_SIZE                                          1
#define AVR32_ERAY_CH_MASK                                  0x00000003
#define AVR32_ERAY_CH_OFFSET                                         0
#define AVR32_ERAY_CH_SIZE                                           2
#define AVR32_ERAY_CIA                                               3
#define AVR32_ERAY_CIA_MASK                                 0x00000008
#define AVR32_ERAY_CIA_OFFSET                                        3
#define AVR32_ERAY_CIA_SIZE                                          1
#define AVR32_ERAY_CIB                                              11
#define AVR32_ERAY_CIB_MASK                                 0x00000800
#define AVR32_ERAY_CIB_OFFSET                                       11
#define AVR32_ERAY_CIB_SIZE                                          1
#define AVR32_ERAY_CKDIV                                             0
#define AVR32_ERAY_CKDIV_MASK                               0x000007ff
#define AVR32_ERAY_CKDIV_OFFSET                                      0
#define AVR32_ERAY_CKDIV_SIZE                                       11
#define AVR32_ERAY_CL                                                0
#define AVR32_ERAY_CLK                                               0
#define AVR32_ERAY_CLK_MASK                                 0x000000ff
#define AVR32_ERAY_CLK_OFFSET                                        0
#define AVR32_ERAY_CLK_SIZE                                          8
#define AVR32_ERAY_CL_MASK                                  0x000000ff
#define AVR32_ERAY_CL_OFFSET                                         0
#define AVR32_ERAY_CL_SIZE                                           8
#define AVR32_ERAY_CMD                                               0
#define AVR32_ERAY_CMD_MASK                                 0x0000000f
#define AVR32_ERAY_CMD_OFFSET                                        0
#define AVR32_ERAY_CMD_SIZE                                          4
#define AVR32_ERAY_CNA                                               1
#define AVR32_ERAY_CNAE                                              1
#define AVR32_ERAY_CNAE_MASK                                0x00000002
#define AVR32_ERAY_CNAE_OFFSET                                       1
#define AVR32_ERAY_CNAE_SIZE                                         1
#define AVR32_ERAY_CNAL                                              1
#define AVR32_ERAY_CNAL_MASK                                0x00000002
#define AVR32_ERAY_CNAL_OFFSET                                       1
#define AVR32_ERAY_CNAL_SIZE                                         1
#define AVR32_ERAY_CNA_MASK                                 0x00000002
#define AVR32_ERAY_CNA_OFFSET                                        1
#define AVR32_ERAY_CNA_SIZE                                          1
#define AVR32_ERAY_CRAM                                              7
#define AVR32_ERAY_CRAM_MASK                                0x00000080
#define AVR32_ERAY_CRAM_OFFSET                                       7
#define AVR32_ERAY_CRAM_SIZE                                         1
#define AVR32_ERAY_CRC                                               0
#define AVR32_ERAY_CRC_MASK                                 0x000007ff
#define AVR32_ERAY_CRC_OFFSET                                        0
#define AVR32_ERAY_CRC_SIZE                                         11
#define AVR32_ERAY_CREL                                     0x000003f0
#define AVR32_ERAY_CREL_DAY                                          0
#define AVR32_ERAY_CREL_DAY_MASK                            0x000000ff
#define AVR32_ERAY_CREL_DAY_OFFSET                                   0
#define AVR32_ERAY_CREL_DAY_SIZE                                     8
#define AVR32_ERAY_CREL_MASK                                0xffffffff
#define AVR32_ERAY_CREL_MON                                          8
#define AVR32_ERAY_CREL_MON_MASK                            0x0000ff00
#define AVR32_ERAY_CREL_MON_OFFSET                                   8
#define AVR32_ERAY_CREL_MON_SIZE                                     8
#define AVR32_ERAY_CREL_REL                                         28
#define AVR32_ERAY_CREL_REL_MASK                            0xf0000000
#define AVR32_ERAY_CREL_REL_OFFSET                                  28
#define AVR32_ERAY_CREL_REL_SIZE                                     4
#define AVR32_ERAY_CREL_RESETVALUE                          0x00000000
#define AVR32_ERAY_CREL_STEP                                        20
#define AVR32_ERAY_CREL_STEP_MASK                           0x0ff00000
#define AVR32_ERAY_CREL_STEP_OFFSET                                 20
#define AVR32_ERAY_CREL_STEP_SIZE                                    8
#define AVR32_ERAY_CREL_YEAR                                        16
#define AVR32_ERAY_CREL_YEAR_MASK                           0x000f0000
#define AVR32_ERAY_CREL_YEAR_OFFSET                                 16
#define AVR32_ERAY_CREL_YEAR_SIZE                                    4
#define AVR32_ERAY_CSA                                              11
#define AVR32_ERAY_CSAI                                             13
#define AVR32_ERAY_CSAI_MASK                                0x00002000
#define AVR32_ERAY_CSAI_OFFSET                                      13
#define AVR32_ERAY_CSAI_SIZE                                         1
#define AVR32_ERAY_CSA_MASK                                 0x0000f800
#define AVR32_ERAY_CSA_OFFSET                                       11
#define AVR32_ERAY_CSA_SIZE                                          5
#define AVR32_ERAY_CSI                                              14
#define AVR32_ERAY_CSI_MASK                                 0x00004000
#define AVR32_ERAY_CSI_OFFSET                                       14
#define AVR32_ERAY_CSI_SIZE                                          1
#define AVR32_ERAY_CSNI                                             12
#define AVR32_ERAY_CSNI_MASK                                0x00001000
#define AVR32_ERAY_CSNI_OFFSET                                      12
#define AVR32_ERAY_CSNI_SIZE                                         1
#define AVR32_ERAY_CUST1                                    0x00000004
#define AVR32_ERAY_CUST1_MASK                               0x00000000
#define AVR32_ERAY_CUST1_RESETVALUE                         0x00000000
#define AVR32_ERAY_CUST2                                    0x00000008
#define AVR32_ERAY_CUST2_MASK                               0x00000000
#define AVR32_ERAY_CUST2_RESETVALUE                         0x00000000
#define AVR32_ERAY_CUST3                                    0x0000000c
#define AVR32_ERAY_CUST3_MASK                               0x00000000
#define AVR32_ERAY_CUST3_RESETVALUE                         0x00000000
#define AVR32_ERAY_CYC                                              16
#define AVR32_ERAY_CYCS                                              2
#define AVR32_ERAY_CYCSE                                             2
#define AVR32_ERAY_CYCSE_MASK                               0x00000004
#define AVR32_ERAY_CYCSE_OFFSET                                      2
#define AVR32_ERAY_CYCSE_SIZE                                        1
#define AVR32_ERAY_CYCSL                                             2
#define AVR32_ERAY_CYCSL_MASK                               0x00000004
#define AVR32_ERAY_CYCSL_OFFSET                                      2
#define AVR32_ERAY_CYCSL_SIZE                                        1
#define AVR32_ERAY_CYCS_MASK                                0x00000004
#define AVR32_ERAY_CYCS_OFFSET                                       2
#define AVR32_ERAY_CYCS_SIZE                                         1
#define AVR32_ERAY_CYC_MASK                                 0x007f0000
#define AVR32_ERAY_CYC_OFFSET                                       16
#define AVR32_ERAY_CYC_SIZE                                          7
#define AVR32_ERAY_CYF                                              16
#define AVR32_ERAY_CYF_MASK                                 0x007f0000
#define AVR32_ERAY_CYF_OFFSET                                       16
#define AVR32_ERAY_CYF_SIZE                                          7
#define AVR32_ERAY_DAY                                               0
#define AVR32_ERAY_DAY_MASK                                 0x000000ff
#define AVR32_ERAY_DAY_OFFSET                                        0
#define AVR32_ERAY_DAY_SIZE                                          8
#define AVR32_ERAY_DCA                                               0
#define AVR32_ERAY_DCA_MASK                                 0x000000ff
#define AVR32_ERAY_DCA_OFFSET                                        0
#define AVR32_ERAY_DCA_SIZE                                          8
#define AVR32_ERAY_DCB                                               8
#define AVR32_ERAY_DCB_MASK                                 0x0000ff00
#define AVR32_ERAY_DCB_OFFSET                                        8
#define AVR32_ERAY_DCB_SIZE                                          8
#define AVR32_ERAY_DEC                                              24
#define AVR32_ERAY_DEC_MASK                                 0xff000000
#define AVR32_ERAY_DEC_OFFSET                                       24
#define AVR32_ERAY_DEC_SIZE                                          8
#define AVR32_ERAY_DIAGR1                                            8
#define AVR32_ERAY_DIAGR1_MASK                              0x00000100
#define AVR32_ERAY_DIAGR1_OFFSET                                     8
#define AVR32_ERAY_DIAGR1_SIZE                                       1
#define AVR32_ERAY_DIAGR2                                            9
#define AVR32_ERAY_DIAGR2_MASK                              0x00000200
#define AVR32_ERAY_DIAGR2_OFFSET                                     9
#define AVR32_ERAY_DIAGR2_SIZE                                       1
#define AVR32_ERAY_DP                                                0
#define AVR32_ERAY_DP_MASK                                  0x000007ff
#define AVR32_ERAY_DP_OFFSET                                         0
#define AVR32_ERAY_DP_SIZE                                          11
#define AVR32_ERAY_DSI                                              16
#define AVR32_ERAY_DSI_MASK                                 0x00030000
#define AVR32_ERAY_DSI_OFFSET                                       16
#define AVR32_ERAY_DSI_SIZE                                          2
#define AVR32_ERAY_EDA                                              16
#define AVR32_ERAY_EDAE                                             16
#define AVR32_ERAY_EDAE_MASK                                0x00010000
#define AVR32_ERAY_EDAE_OFFSET                                      16
#define AVR32_ERAY_EDAE_SIZE                                         1
#define AVR32_ERAY_EDAL                                             16
#define AVR32_ERAY_EDAL_MASK                                0x00010000
#define AVR32_ERAY_EDAL_OFFSET                                      16
#define AVR32_ERAY_EDAL_SIZE                                         1
#define AVR32_ERAY_EDA_MASK                                 0x00010000
#define AVR32_ERAY_EDA_OFFSET                                       16
#define AVR32_ERAY_EDA_SIZE                                          1
#define AVR32_ERAY_EDB                                              24
#define AVR32_ERAY_EDBE                                             24
#define AVR32_ERAY_EDBE_MASK                                0x01000000
#define AVR32_ERAY_EDBE_OFFSET                                      24
#define AVR32_ERAY_EDBE_SIZE                                         1
#define AVR32_ERAY_EDBL                                             24
#define AVR32_ERAY_EDBL_MASK                                0x01000000
#define AVR32_ERAY_EDBL_OFFSET                                      24
#define AVR32_ERAY_EDBL_SIZE                                         1
#define AVR32_ERAY_EDB_MASK                                 0x01000000
#define AVR32_ERAY_EDB_OFFSET                                       24
#define AVR32_ERAY_EDB_SIZE                                          1
#define AVR32_ERAY_EDGE                                              2
#define AVR32_ERAY_EDGE_MASK                                0x00000004
#define AVR32_ERAY_EDGE_OFFSET                                       2
#define AVR32_ERAY_EDGE_SIZE                                         1
#define AVR32_ERAY_EETP                                              4
#define AVR32_ERAY_EETP_MASK                                0x00000010
#define AVR32_ERAY_EETP_OFFSET                                       4
#define AVR32_ERAY_EETP_SIZE                                         1
#define AVR32_ERAY_EFA                                               8
#define AVR32_ERAY_EFAE                                              8
#define AVR32_ERAY_EFAE_MASK                                0x00000100
#define AVR32_ERAY_EFAE_OFFSET                                       8
#define AVR32_ERAY_EFAE_SIZE                                         1
#define AVR32_ERAY_EFAL                                              8
#define AVR32_ERAY_EFAL_MASK                                0x00000100
#define AVR32_ERAY_EFAL_OFFSET                                       8
#define AVR32_ERAY_EFAL_SIZE                                         1
#define AVR32_ERAY_EFA_MASK                                 0x00000100
#define AVR32_ERAY_EFA_OFFSET                                        8
#define AVR32_ERAY_EFA_SIZE                                          1
#define AVR32_ERAY_EID                                               0
#define AVR32_ERAY_EID_MASK                                 0x000003ff
#define AVR32_ERAY_EID_OFFSET                                        0
#define AVR32_ERAY_EID_SIZE                                         10
#define AVR32_ERAY_EIER                                     0x00000034
#define AVR32_ERAY_EIER_CCFE                                         4
#define AVR32_ERAY_EIER_CCFE_MASK                           0x00000010
#define AVR32_ERAY_EIER_CCFE_OFFSET                                  4
#define AVR32_ERAY_EIER_CCFE_SIZE                                    1
#define AVR32_ERAY_EIER_CCLE                                         5
#define AVR32_ERAY_EIER_CCLE_MASK                           0x00000020
#define AVR32_ERAY_EIER_CCLE_OFFSET                                  5
#define AVR32_ERAY_EIER_CCLE_SIZE                                    1
#define AVR32_ERAY_EIER_CNAE                                         1
#define AVR32_ERAY_EIER_CNAE_MASK                           0x00000002
#define AVR32_ERAY_EIER_CNAE_OFFSET                                  1
#define AVR32_ERAY_EIER_CNAE_SIZE                                    1
#define AVR32_ERAY_EIER_EDAE                                        16
#define AVR32_ERAY_EIER_EDAE_MASK                           0x00010000
#define AVR32_ERAY_EIER_EDAE_OFFSET                                 16
#define AVR32_ERAY_EIER_EDAE_SIZE                                    1
#define AVR32_ERAY_EIER_EDBE                                        24
#define AVR32_ERAY_EIER_EDBE_MASK                           0x01000000
#define AVR32_ERAY_EIER_EDBE_OFFSET                                 24
#define AVR32_ERAY_EIER_EDBE_SIZE                                    1
#define AVR32_ERAY_EIER_EFAE                                         8
#define AVR32_ERAY_EIER_EFAE_MASK                           0x00000100
#define AVR32_ERAY_EIER_EFAE_OFFSET                                  8
#define AVR32_ERAY_EIER_EFAE_SIZE                                    1
#define AVR32_ERAY_EIER_IIBAE                                        9
#define AVR32_ERAY_EIER_IIBAE_MASK                          0x00000200
#define AVR32_ERAY_EIER_IIBAE_OFFSET                                 9
#define AVR32_ERAY_EIER_IIBAE_SIZE                                   1
#define AVR32_ERAY_EIER_IOBAE                                       10
#define AVR32_ERAY_EIER_IOBAE_MASK                          0x00000400
#define AVR32_ERAY_EIER_IOBAE_OFFSET                                10
#define AVR32_ERAY_EIER_IOBAE_SIZE                                   1
#define AVR32_ERAY_EIER_LTVAE                                       17
#define AVR32_ERAY_EIER_LTVAE_MASK                          0x00020000
#define AVR32_ERAY_EIER_LTVAE_OFFSET                                17
#define AVR32_ERAY_EIER_LTVAE_SIZE                                   1
#define AVR32_ERAY_EIER_LTVBE                                       25
#define AVR32_ERAY_EIER_LTVBE_MASK                          0x02000000
#define AVR32_ERAY_EIER_LTVBE_OFFSET                                25
#define AVR32_ERAY_EIER_LTVBE_SIZE                                   1
#define AVR32_ERAY_EIER_MASK                                0x07070fff
#define AVR32_ERAY_EIER_MHFE                                        11
#define AVR32_ERAY_EIER_MHFE_MASK                           0x00000800
#define AVR32_ERAY_EIER_MHFE_OFFSET                                 11
#define AVR32_ERAY_EIER_MHFE_SIZE                                    1
#define AVR32_ERAY_EIER_PEMCE                                        0
#define AVR32_ERAY_EIER_PEMCE_MASK                          0x00000001
#define AVR32_ERAY_EIER_PEMCE_OFFSET                                 0
#define AVR32_ERAY_EIER_PEMCE_SIZE                                   1
#define AVR32_ERAY_EIER_PERRE                                        6
#define AVR32_ERAY_EIER_PERRE_MASK                          0x00000040
#define AVR32_ERAY_EIER_PERRE_OFFSET                                 6
#define AVR32_ERAY_EIER_PERRE_SIZE                                   1
#define AVR32_ERAY_EIER_RESETVALUE                          0x00000000
#define AVR32_ERAY_EIER_RFOE                                         7
#define AVR32_ERAY_EIER_RFOE_MASK                           0x00000080
#define AVR32_ERAY_EIER_RFOE_OFFSET                                  7
#define AVR32_ERAY_EIER_RFOE_SIZE                                    1
#define AVR32_ERAY_EIER_SFBME                                        2
#define AVR32_ERAY_EIER_SFBME_MASK                          0x00000004
#define AVR32_ERAY_EIER_SFBME_OFFSET                                 2
#define AVR32_ERAY_EIER_SFBME_SIZE                                   1
#define AVR32_ERAY_EIER_SFOE                                         3
#define AVR32_ERAY_EIER_SFOE_MASK                           0x00000008
#define AVR32_ERAY_EIER_SFOE_OFFSET                                  3
#define AVR32_ERAY_EIER_SFOE_SIZE                                    1
#define AVR32_ERAY_EIER_TABAE                                       18
#define AVR32_ERAY_EIER_TABAE_MASK                          0x00040000
#define AVR32_ERAY_EIER_TABAE_OFFSET                                18
#define AVR32_ERAY_EIER_TABAE_SIZE                                   1
#define AVR32_ERAY_EIER_TABBE                                       26
#define AVR32_ERAY_EIER_TABBE_MASK                          0x04000000
#define AVR32_ERAY_EIER_TABBE_OFFSET                                26
#define AVR32_ERAY_EIER_TABBE_SIZE                                   1
#define AVR32_ERAY_EIES                                     0x00000030
#define AVR32_ERAY_EIES_CCFE                                         4
#define AVR32_ERAY_EIES_CCFE_MASK                           0x00000010
#define AVR32_ERAY_EIES_CCFE_OFFSET                                  4
#define AVR32_ERAY_EIES_CCFE_SIZE                                    1
#define AVR32_ERAY_EIES_CCLE                                         5
#define AVR32_ERAY_EIES_CCLE_MASK                           0x00000020
#define AVR32_ERAY_EIES_CCLE_OFFSET                                  5
#define AVR32_ERAY_EIES_CCLE_SIZE                                    1
#define AVR32_ERAY_EIES_CNAE                                         1
#define AVR32_ERAY_EIES_CNAE_MASK                           0x00000002
#define AVR32_ERAY_EIES_CNAE_OFFSET                                  1
#define AVR32_ERAY_EIES_CNAE_SIZE                                    1
#define AVR32_ERAY_EIES_EDAE                                        16
#define AVR32_ERAY_EIES_EDAE_MASK                           0x00010000
#define AVR32_ERAY_EIES_EDAE_OFFSET                                 16
#define AVR32_ERAY_EIES_EDAE_SIZE                                    1
#define AVR32_ERAY_EIES_EDBE                                        24
#define AVR32_ERAY_EIES_EDBE_MASK                           0x01000000
#define AVR32_ERAY_EIES_EDBE_OFFSET                                 24
#define AVR32_ERAY_EIES_EDBE_SIZE                                    1
#define AVR32_ERAY_EIES_EFAE                                         8
#define AVR32_ERAY_EIES_EFAE_MASK                           0x00000100
#define AVR32_ERAY_EIES_EFAE_OFFSET                                  8
#define AVR32_ERAY_EIES_EFAE_SIZE                                    1
#define AVR32_ERAY_EIES_IIBAE                                        9
#define AVR32_ERAY_EIES_IIBAE_MASK                          0x00000200
#define AVR32_ERAY_EIES_IIBAE_OFFSET                                 9
#define AVR32_ERAY_EIES_IIBAE_SIZE                                   1
#define AVR32_ERAY_EIES_IOBAE                                       10
#define AVR32_ERAY_EIES_IOBAE_MASK                          0x00000400
#define AVR32_ERAY_EIES_IOBAE_OFFSET                                10
#define AVR32_ERAY_EIES_IOBAE_SIZE                                   1
#define AVR32_ERAY_EIES_LTVAE                                       17
#define AVR32_ERAY_EIES_LTVAE_MASK                          0x00020000
#define AVR32_ERAY_EIES_LTVAE_OFFSET                                17
#define AVR32_ERAY_EIES_LTVAE_SIZE                                   1
#define AVR32_ERAY_EIES_LTVBE                                       25
#define AVR32_ERAY_EIES_LTVBE_MASK                          0x02000000
#define AVR32_ERAY_EIES_LTVBE_OFFSET                                25
#define AVR32_ERAY_EIES_LTVBE_SIZE                                   1
#define AVR32_ERAY_EIES_MASK                                0x07070fff
#define AVR32_ERAY_EIES_MHFE                                        11
#define AVR32_ERAY_EIES_MHFE_MASK                           0x00000800
#define AVR32_ERAY_EIES_MHFE_OFFSET                                 11
#define AVR32_ERAY_EIES_MHFE_SIZE                                    1
#define AVR32_ERAY_EIES_PEMCE                                        0
#define AVR32_ERAY_EIES_PEMCE_MASK                          0x00000001
#define AVR32_ERAY_EIES_PEMCE_OFFSET                                 0
#define AVR32_ERAY_EIES_PEMCE_SIZE                                   1
#define AVR32_ERAY_EIES_PERRE                                        6
#define AVR32_ERAY_EIES_PERRE_MASK                          0x00000040
#define AVR32_ERAY_EIES_PERRE_OFFSET                                 6
#define AVR32_ERAY_EIES_PERRE_SIZE                                   1
#define AVR32_ERAY_EIES_RESETVALUE                          0x00000000
#define AVR32_ERAY_EIES_RFOE                                         7
#define AVR32_ERAY_EIES_RFOE_MASK                           0x00000080
#define AVR32_ERAY_EIES_RFOE_OFFSET                                  7
#define AVR32_ERAY_EIES_RFOE_SIZE                                    1
#define AVR32_ERAY_EIES_SFBME                                        2
#define AVR32_ERAY_EIES_SFBME_MASK                          0x00000004
#define AVR32_ERAY_EIES_SFBME_OFFSET                                 2
#define AVR32_ERAY_EIES_SFBME_SIZE                                   1
#define AVR32_ERAY_EIES_SFOE                                         3
#define AVR32_ERAY_EIES_SFOE_MASK                           0x00000008
#define AVR32_ERAY_EIES_SFOE_OFFSET                                  3
#define AVR32_ERAY_EIES_SFOE_SIZE                                    1
#define AVR32_ERAY_EIES_TABAE                                       18
#define AVR32_ERAY_EIES_TABAE_MASK                          0x00040000
#define AVR32_ERAY_EIES_TABAE_OFFSET                                18
#define AVR32_ERAY_EIES_TABAE_SIZE                                   1
#define AVR32_ERAY_EIES_TABBE                                       26
#define AVR32_ERAY_EIES_TABBE_MASK                          0x04000000
#define AVR32_ERAY_EIES_TABBE_OFFSET                                26
#define AVR32_ERAY_EIES_TABBE_SIZE                                   1
#define AVR32_ERAY_EILS                                     0x00000028
#define AVR32_ERAY_EILS_CCFL                                         4
#define AVR32_ERAY_EILS_CCFL_MASK                           0x00000010
#define AVR32_ERAY_EILS_CCFL_OFFSET                                  4
#define AVR32_ERAY_EILS_CCFL_SIZE                                    1
#define AVR32_ERAY_EILS_CCLL                                         5
#define AVR32_ERAY_EILS_CCLL_MASK                           0x00000020
#define AVR32_ERAY_EILS_CCLL_OFFSET                                  5
#define AVR32_ERAY_EILS_CCLL_SIZE                                    1
#define AVR32_ERAY_EILS_CNAL                                         1
#define AVR32_ERAY_EILS_CNAL_MASK                           0x00000002
#define AVR32_ERAY_EILS_CNAL_OFFSET                                  1
#define AVR32_ERAY_EILS_CNAL_SIZE                                    1
#define AVR32_ERAY_EILS_EDAL                                        16
#define AVR32_ERAY_EILS_EDAL_MASK                           0x00010000
#define AVR32_ERAY_EILS_EDAL_OFFSET                                 16
#define AVR32_ERAY_EILS_EDAL_SIZE                                    1
#define AVR32_ERAY_EILS_EDBL                                        24
#define AVR32_ERAY_EILS_EDBL_MASK                           0x01000000
#define AVR32_ERAY_EILS_EDBL_OFFSET                                 24
#define AVR32_ERAY_EILS_EDBL_SIZE                                    1
#define AVR32_ERAY_EILS_EFAL                                         8
#define AVR32_ERAY_EILS_EFAL_MASK                           0x00000100
#define AVR32_ERAY_EILS_EFAL_OFFSET                                  8
#define AVR32_ERAY_EILS_EFAL_SIZE                                    1
#define AVR32_ERAY_EILS_IIBAL                                        9
#define AVR32_ERAY_EILS_IIBAL_MASK                          0x00000200
#define AVR32_ERAY_EILS_IIBAL_OFFSET                                 9
#define AVR32_ERAY_EILS_IIBAL_SIZE                                   1
#define AVR32_ERAY_EILS_IOBAL                                       10
#define AVR32_ERAY_EILS_IOBAL_MASK                          0x00000400
#define AVR32_ERAY_EILS_IOBAL_OFFSET                                10
#define AVR32_ERAY_EILS_IOBAL_SIZE                                   1
#define AVR32_ERAY_EILS_LTVAL                                       17
#define AVR32_ERAY_EILS_LTVAL_MASK                          0x00020000
#define AVR32_ERAY_EILS_LTVAL_OFFSET                                17
#define AVR32_ERAY_EILS_LTVAL_SIZE                                   1
#define AVR32_ERAY_EILS_LTVBL                                       25
#define AVR32_ERAY_EILS_LTVBL_MASK                          0x02000000
#define AVR32_ERAY_EILS_LTVBL_OFFSET                                25
#define AVR32_ERAY_EILS_LTVBL_SIZE                                   1
#define AVR32_ERAY_EILS_MASK                                0x07070fff
#define AVR32_ERAY_EILS_MHFL                                        11
#define AVR32_ERAY_EILS_MHFL_MASK                           0x00000800
#define AVR32_ERAY_EILS_MHFL_OFFSET                                 11
#define AVR32_ERAY_EILS_MHFL_SIZE                                    1
#define AVR32_ERAY_EILS_PEMCL                                        0
#define AVR32_ERAY_EILS_PEMCL_MASK                          0x00000001
#define AVR32_ERAY_EILS_PEMCL_OFFSET                                 0
#define AVR32_ERAY_EILS_PEMCL_SIZE                                   1
#define AVR32_ERAY_EILS_PERRL                                        6
#define AVR32_ERAY_EILS_PERRL_MASK                          0x00000040
#define AVR32_ERAY_EILS_PERRL_OFFSET                                 6
#define AVR32_ERAY_EILS_PERRL_SIZE                                   1
#define AVR32_ERAY_EILS_RESETVALUE                          0x00000000
#define AVR32_ERAY_EILS_RFOL                                         7
#define AVR32_ERAY_EILS_RFOL_MASK                           0x00000080
#define AVR32_ERAY_EILS_RFOL_OFFSET                                  7
#define AVR32_ERAY_EILS_RFOL_SIZE                                    1
#define AVR32_ERAY_EILS_SFBML                                        2
#define AVR32_ERAY_EILS_SFBML_MASK                          0x00000004
#define AVR32_ERAY_EILS_SFBML_OFFSET                                 2
#define AVR32_ERAY_EILS_SFBML_SIZE                                   1
#define AVR32_ERAY_EILS_SFOL                                         3
#define AVR32_ERAY_EILS_SFOL_MASK                           0x00000008
#define AVR32_ERAY_EILS_SFOL_OFFSET                                  3
#define AVR32_ERAY_EILS_SFOL_SIZE                                    1
#define AVR32_ERAY_EILS_TABAL                                       18
#define AVR32_ERAY_EILS_TABAL_MASK                          0x00040000
#define AVR32_ERAY_EILS_TABAL_OFFSET                                18
#define AVR32_ERAY_EILS_TABAL_SIZE                                   1
#define AVR32_ERAY_EILS_TABBL                                       26
#define AVR32_ERAY_EILS_TABBL_MASK                          0x04000000
#define AVR32_ERAY_EILS_TABBL_OFFSET                                26
#define AVR32_ERAY_EILS_TABBL_SIZE                                   1
#define AVR32_ERAY_EINT0_SIZE                                        1
#define AVR32_ERAY_EINT1_SIZE                                        1
#define AVR32_ERAY_EIR                                      0x00000020
#define AVR32_ERAY_EIR_CCF                                           4
#define AVR32_ERAY_EIR_CCF_MASK                             0x00000010
#define AVR32_ERAY_EIR_CCF_OFFSET                                    4
#define AVR32_ERAY_EIR_CCF_SIZE                                      1
#define AVR32_ERAY_EIR_CCL                                           5
#define AVR32_ERAY_EIR_CCL_MASK                             0x00000020
#define AVR32_ERAY_EIR_CCL_OFFSET                                    5
#define AVR32_ERAY_EIR_CCL_SIZE                                      1
#define AVR32_ERAY_EIR_CNA                                           1
#define AVR32_ERAY_EIR_CNA_MASK                             0x00000002
#define AVR32_ERAY_EIR_CNA_OFFSET                                    1
#define AVR32_ERAY_EIR_CNA_SIZE                                      1
#define AVR32_ERAY_EIR_EDA                                          16
#define AVR32_ERAY_EIR_EDA_MASK                             0x00010000
#define AVR32_ERAY_EIR_EDA_OFFSET                                   16
#define AVR32_ERAY_EIR_EDA_SIZE                                      1
#define AVR32_ERAY_EIR_EDB                                          24
#define AVR32_ERAY_EIR_EDB_MASK                             0x01000000
#define AVR32_ERAY_EIR_EDB_OFFSET                                   24
#define AVR32_ERAY_EIR_EDB_SIZE                                      1
#define AVR32_ERAY_EIR_EFA                                           8
#define AVR32_ERAY_EIR_EFA_MASK                             0x00000100
#define AVR32_ERAY_EIR_EFA_OFFSET                                    8
#define AVR32_ERAY_EIR_EFA_SIZE                                      1
#define AVR32_ERAY_EIR_IIBA                                          9
#define AVR32_ERAY_EIR_IIBA_MASK                            0x00000200
#define AVR32_ERAY_EIR_IIBA_OFFSET                                   9
#define AVR32_ERAY_EIR_IIBA_SIZE                                     1
#define AVR32_ERAY_EIR_IOBA                                         10
#define AVR32_ERAY_EIR_IOBA_MASK                            0x00000400
#define AVR32_ERAY_EIR_IOBA_OFFSET                                  10
#define AVR32_ERAY_EIR_IOBA_SIZE                                     1
#define AVR32_ERAY_EIR_LTVA                                         17
#define AVR32_ERAY_EIR_LTVA_MASK                            0x00020000
#define AVR32_ERAY_EIR_LTVA_OFFSET                                  17
#define AVR32_ERAY_EIR_LTVA_SIZE                                     1
#define AVR32_ERAY_EIR_LTVB                                         25
#define AVR32_ERAY_EIR_LTVB_MASK                            0x02000000
#define AVR32_ERAY_EIR_LTVB_OFFSET                                  25
#define AVR32_ERAY_EIR_LTVB_SIZE                                     1
#define AVR32_ERAY_EIR_MASK                                 0x07070fff
#define AVR32_ERAY_EIR_MHF                                          11
#define AVR32_ERAY_EIR_MHF_MASK                             0x00000800
#define AVR32_ERAY_EIR_MHF_OFFSET                                   11
#define AVR32_ERAY_EIR_MHF_SIZE                                      1
#define AVR32_ERAY_EIR_PEMC                                          0
#define AVR32_ERAY_EIR_PEMC_MASK                            0x00000001
#define AVR32_ERAY_EIR_PEMC_OFFSET                                   0
#define AVR32_ERAY_EIR_PEMC_SIZE                                     1
#define AVR32_ERAY_EIR_PERR                                          6
#define AVR32_ERAY_EIR_PERR_MASK                            0x00000040
#define AVR32_ERAY_EIR_PERR_OFFSET                                   6
#define AVR32_ERAY_EIR_PERR_SIZE                                     1
#define AVR32_ERAY_EIR_RESETVALUE                           0x00000000
#define AVR32_ERAY_EIR_RFO                                           7
#define AVR32_ERAY_EIR_RFO_MASK                             0x00000080
#define AVR32_ERAY_EIR_RFO_OFFSET                                    7
#define AVR32_ERAY_EIR_RFO_SIZE                                      1
#define AVR32_ERAY_EIR_SFBM                                          2
#define AVR32_ERAY_EIR_SFBM_MASK                            0x00000004
#define AVR32_ERAY_EIR_SFBM_OFFSET                                   2
#define AVR32_ERAY_EIR_SFBM_SIZE                                     1
#define AVR32_ERAY_EIR_SFO                                           3
#define AVR32_ERAY_EIR_SFO_MASK                             0x00000008
#define AVR32_ERAY_EIR_SFO_OFFSET                                    3
#define AVR32_ERAY_EIR_SFO_SIZE                                      1
#define AVR32_ERAY_EIR_TABA                                         18
#define AVR32_ERAY_EIR_TABA_MASK                            0x00040000
#define AVR32_ERAY_EIR_TABA_OFFSET                                  18
#define AVR32_ERAY_EIR_TABA_SIZE                                     1
#define AVR32_ERAY_EIR_TABB                                         26
#define AVR32_ERAY_EIR_TABB_MASK                            0x04000000
#define AVR32_ERAY_EIR_TABB_OFFSET                                  26
#define AVR32_ERAY_EIR_TABB_SIZE                                     1
#define AVR32_ERAY_ELBE                                              1
#define AVR32_ERAY_ELBE_MASK                                0x00000002
#define AVR32_ERAY_ELBE_OFFSET                                       1
#define AVR32_ERAY_ELBE_SIZE                                         1
#define AVR32_ERAY_EN1                                               0
#define AVR32_ERAY_EN1_MASK                                 0x00000001
#define AVR32_ERAY_EN1_OFFSET                                        0
#define AVR32_ERAY_EN1_SIZE                                          1
#define AVR32_ERAY_EN2                                               1
#define AVR32_ERAY_EN2_MASK                                 0x00000002
#define AVR32_ERAY_EN2_OFFSET                                        1
#define AVR32_ERAY_EN2_SIZE                                          1
#define AVR32_ERAY_ENDN                                     0x000003f4
#define AVR32_ERAY_ENDN_ETV                                          0
#define AVR32_ERAY_ENDN_ETV_MASK                            0xffffffff
#define AVR32_ERAY_ENDN_ETV_OFFSET                                   0
#define AVR32_ERAY_ENDN_ETV_SIZE                                    32
#define AVR32_ERAY_ENDN_MASK                                0xffffffff
#define AVR32_ERAY_ENDN_RESETVALUE                          0x00000000
#define AVR32_ERAY_EOC                                              16
#define AVR32_ERAY_EOCC                                              0
#define AVR32_ERAY_EOCC_MASK                                0x00000003
#define AVR32_ERAY_EOCC_OFFSET                                       0
#define AVR32_ERAY_EOCC_SIZE                                         2
#define AVR32_ERAY_EOC_MASK                                 0x00070000
#define AVR32_ERAY_EOC_OFFSET                                       16
#define AVR32_ERAY_EOC_SIZE                                          3
#define AVR32_ERAY_ERC                                              24
#define AVR32_ERAY_ERCC                                              8
#define AVR32_ERAY_ERCC_MASK                                0x00000300
#define AVR32_ERAY_ERCC_OFFSET                                       8
#define AVR32_ERAY_ERCC_SIZE                                         2
#define AVR32_ERAY_ERC_MASK                                 0x07000000
#define AVR32_ERAY_ERC_OFFSET                                       24
#define AVR32_ERAY_ERC_SIZE                                          3
#define AVR32_ERAY_ERRM                                              6
#define AVR32_ERAY_ERRM_MASK                                0x000000c0
#define AVR32_ERAY_ERRM_OFFSET                                       6
#define AVR32_ERAY_ERRM_SIZE                                         2
#define AVR32_ERAY_ESA                                              10
#define AVR32_ERAY_ESA_MASK                                 0x00000400
#define AVR32_ERAY_ESA_OFFSET                                       10
#define AVR32_ERAY_ESA_SIZE                                          1
#define AVR32_ERAY_ESB                                              11
#define AVR32_ERAY_ESB_MASK                                 0x00000800
#define AVR32_ERAY_ESB_OFFSET                                       11
#define AVR32_ERAY_ESB_SIZE                                          1
#define AVR32_ERAY_ESID1                                    0x00000130
#define AVR32_ERAY_ESID10                                   0x00000154
#define AVR32_ERAY_ESID10_EID                                        0
#define AVR32_ERAY_ESID10_EID_MASK                          0x000003ff
#define AVR32_ERAY_ESID10_EID_OFFSET                                 0
#define AVR32_ERAY_ESID10_EID_SIZE                                  10
#define AVR32_ERAY_ESID10_MASK                              0x0000c3ff
#define AVR32_ERAY_ESID10_RESETVALUE                        0x00000000
#define AVR32_ERAY_ESID10_RXEA                                      14
#define AVR32_ERAY_ESID10_RXEA_MASK                         0x00004000
#define AVR32_ERAY_ESID10_RXEA_OFFSET                               14
#define AVR32_ERAY_ESID10_RXEA_SIZE                                  1
#define AVR32_ERAY_ESID10_RXEB                                      15
#define AVR32_ERAY_ESID10_RXEB_MASK                         0x00008000
#define AVR32_ERAY_ESID10_RXEB_OFFSET                               15
#define AVR32_ERAY_ESID10_RXEB_SIZE                                  1
#define AVR32_ERAY_ESID11                                   0x00000158
#define AVR32_ERAY_ESID11_EID                                        0
#define AVR32_ERAY_ESID11_EID_MASK                          0x000003ff
#define AVR32_ERAY_ESID11_EID_OFFSET                                 0
#define AVR32_ERAY_ESID11_EID_SIZE                                  10
#define AVR32_ERAY_ESID11_MASK                              0x0000c3ff
#define AVR32_ERAY_ESID11_RESETVALUE                        0x00000000
#define AVR32_ERAY_ESID11_RXEA                                      14
#define AVR32_ERAY_ESID11_RXEA_MASK                         0x00004000
#define AVR32_ERAY_ESID11_RXEA_OFFSET                               14
#define AVR32_ERAY_ESID11_RXEA_SIZE                                  1
#define AVR32_ERAY_ESID11_RXEB                                      15
#define AVR32_ERAY_ESID11_RXEB_MASK                         0x00008000
#define AVR32_ERAY_ESID11_RXEB_OFFSET                               15
#define AVR32_ERAY_ESID11_RXEB_SIZE                                  1
#define AVR32_ERAY_ESID12                                   0x0000015c
#define AVR32_ERAY_ESID12_EID                                        0
#define AVR32_ERAY_ESID12_EID_MASK                          0x000003ff
#define AVR32_ERAY_ESID12_EID_OFFSET                                 0
#define AVR32_ERAY_ESID12_EID_SIZE                                  10
#define AVR32_ERAY_ESID12_MASK                              0x0000c3ff
#define AVR32_ERAY_ESID12_RESETVALUE                        0x00000000
#define AVR32_ERAY_ESID12_RXEA                                      14
#define AVR32_ERAY_ESID12_RXEA_MASK                         0x00004000
#define AVR32_ERAY_ESID12_RXEA_OFFSET                               14
#define AVR32_ERAY_ESID12_RXEA_SIZE                                  1
#define AVR32_ERAY_ESID12_RXEB                                      15
#define AVR32_ERAY_ESID12_RXEB_MASK                         0x00008000
#define AVR32_ERAY_ESID12_RXEB_OFFSET                               15
#define AVR32_ERAY_ESID12_RXEB_SIZE                                  1
#define AVR32_ERAY_ESID13                                   0x00000160
#define AVR32_ERAY_ESID13_EID                                        0
#define AVR32_ERAY_ESID13_EID_MASK                          0x000003ff
#define AVR32_ERAY_ESID13_EID_OFFSET                                 0
#define AVR32_ERAY_ESID13_EID_SIZE                                  10
#define AVR32_ERAY_ESID13_MASK                              0x0000c3ff
#define AVR32_ERAY_ESID13_RESETVALUE                        0x00000000
#define AVR32_ERAY_ESID13_RXEA                                      14
#define AVR32_ERAY_ESID13_RXEA_MASK                         0x00004000
#define AVR32_ERAY_ESID13_RXEA_OFFSET                               14
#define AVR32_ERAY_ESID13_RXEA_SIZE                                  1
#define AVR32_ERAY_ESID13_RXEB                                      15
#define AVR32_ERAY_ESID13_RXEB_MASK                         0x00008000
#define AVR32_ERAY_ESID13_RXEB_OFFSET                               15
#define AVR32_ERAY_ESID13_RXEB_SIZE                                  1
#define AVR32_ERAY_ESID14                                   0x00000164
#define AVR32_ERAY_ESID14_EID                                        0
#define AVR32_ERAY_ESID14_EID_MASK                          0x000003ff
#define AVR32_ERAY_ESID14_EID_OFFSET                                 0
#define AVR32_ERAY_ESID14_EID_SIZE                                  10
#define AVR32_ERAY_ESID14_MASK                              0x0000c3ff
#define AVR32_ERAY_ESID14_RESETVALUE                        0x00000000
#define AVR32_ERAY_ESID14_RXEA                                      14
#define AVR32_ERAY_ESID14_RXEA_MASK                         0x00004000
#define AVR32_ERAY_ESID14_RXEA_OFFSET                               14
#define AVR32_ERAY_ESID14_RXEA_SIZE                                  1
#define AVR32_ERAY_ESID14_RXEB                                      15
#define AVR32_ERAY_ESID14_RXEB_MASK                         0x00008000
#define AVR32_ERAY_ESID14_RXEB_OFFSET                               15
#define AVR32_ERAY_ESID14_RXEB_SIZE                                  1
#define AVR32_ERAY_ESID15                                   0x00000168
#define AVR32_ERAY_ESID15_EID                                        0
#define AVR32_ERAY_ESID15_EID_MASK                          0x000003ff
#define AVR32_ERAY_ESID15_EID_OFFSET                                 0
#define AVR32_ERAY_ESID15_EID_SIZE                                  10
#define AVR32_ERAY_ESID15_MASK                              0x0000c3ff
#define AVR32_ERAY_ESID15_RESETVALUE                        0x00000000
#define AVR32_ERAY_ESID15_RXEA                                      14
#define AVR32_ERAY_ESID15_RXEA_MASK                         0x00004000
#define AVR32_ERAY_ESID15_RXEA_OFFSET                               14
#define AVR32_ERAY_ESID15_RXEA_SIZE                                  1
#define AVR32_ERAY_ESID15_RXEB                                      15
#define AVR32_ERAY_ESID15_RXEB_MASK                         0x00008000
#define AVR32_ERAY_ESID15_RXEB_OFFSET                               15
#define AVR32_ERAY_ESID15_RXEB_SIZE                                  1
#define AVR32_ERAY_ESID1_EID                                         0
#define AVR32_ERAY_ESID1_EID_MASK                           0x000003ff
#define AVR32_ERAY_ESID1_EID_OFFSET                                  0
#define AVR32_ERAY_ESID1_EID_SIZE                                   10
#define AVR32_ERAY_ESID1_MASK                               0x0000c3ff
#define AVR32_ERAY_ESID1_RESETVALUE                         0x00000000
#define AVR32_ERAY_ESID1_RXEA                                       14
#define AVR32_ERAY_ESID1_RXEA_MASK                          0x00004000
#define AVR32_ERAY_ESID1_RXEA_OFFSET                                14
#define AVR32_ERAY_ESID1_RXEA_SIZE                                   1
#define AVR32_ERAY_ESID1_RXEB                                       15
#define AVR32_ERAY_ESID1_RXEB_MASK                          0x00008000
#define AVR32_ERAY_ESID1_RXEB_OFFSET                                15
#define AVR32_ERAY_ESID1_RXEB_SIZE                                   1
#define AVR32_ERAY_ESID2                                    0x00000134
#define AVR32_ERAY_ESID2_EID                                         0
#define AVR32_ERAY_ESID2_EID_MASK                           0x000003ff
#define AVR32_ERAY_ESID2_EID_OFFSET                                  0
#define AVR32_ERAY_ESID2_EID_SIZE                                   10
#define AVR32_ERAY_ESID2_MASK                               0x0000c3ff
#define AVR32_ERAY_ESID2_RESETVALUE                         0x00000000
#define AVR32_ERAY_ESID2_RXEA                                       14
#define AVR32_ERAY_ESID2_RXEA_MASK                          0x00004000
#define AVR32_ERAY_ESID2_RXEA_OFFSET                                14
#define AVR32_ERAY_ESID2_RXEA_SIZE                                   1
#define AVR32_ERAY_ESID2_RXEB                                       15
#define AVR32_ERAY_ESID2_RXEB_MASK                          0x00008000
#define AVR32_ERAY_ESID2_RXEB_OFFSET                                15
#define AVR32_ERAY_ESID2_RXEB_SIZE                                   1
#define AVR32_ERAY_ESID3                                    0x00000138
#define AVR32_ERAY_ESID3_EID                                         0
#define AVR32_ERAY_ESID3_EID_MASK                           0x000003ff
#define AVR32_ERAY_ESID3_EID_OFFSET                                  0
#define AVR32_ERAY_ESID3_EID_SIZE                                   10
#define AVR32_ERAY_ESID3_MASK                               0x0000c3ff
#define AVR32_ERAY_ESID3_RESETVALUE                         0x00000000
#define AVR32_ERAY_ESID3_RXEA                                       14
#define AVR32_ERAY_ESID3_RXEA_MASK                          0x00004000
#define AVR32_ERAY_ESID3_RXEA_OFFSET                                14
#define AVR32_ERAY_ESID3_RXEA_SIZE                                   1
#define AVR32_ERAY_ESID3_RXEB                                       15
#define AVR32_ERAY_ESID3_RXEB_MASK                          0x00008000
#define AVR32_ERAY_ESID3_RXEB_OFFSET                                15
#define AVR32_ERAY_ESID3_RXEB_SIZE                                   1
#define AVR32_ERAY_ESID4                                    0x0000013c
#define AVR32_ERAY_ESID4_EID                                         0
#define AVR32_ERAY_ESID4_EID_MASK                           0x000003ff
#define AVR32_ERAY_ESID4_EID_OFFSET                                  0
#define AVR32_ERAY_ESID4_EID_SIZE                                   10
#define AVR32_ERAY_ESID4_MASK                               0x0000c3ff
#define AVR32_ERAY_ESID4_RESETVALUE                         0x00000000
#define AVR32_ERAY_ESID4_RXEA                                       14
#define AVR32_ERAY_ESID4_RXEA_MASK                          0x00004000
#define AVR32_ERAY_ESID4_RXEA_OFFSET                                14
#define AVR32_ERAY_ESID4_RXEA_SIZE                                   1
#define AVR32_ERAY_ESID4_RXEB                                       15
#define AVR32_ERAY_ESID4_RXEB_MASK                          0x00008000
#define AVR32_ERAY_ESID4_RXEB_OFFSET                                15
#define AVR32_ERAY_ESID4_RXEB_SIZE                                   1
#define AVR32_ERAY_ESID5                                    0x00000140
#define AVR32_ERAY_ESID5_EID                                         0
#define AVR32_ERAY_ESID5_EID_MASK                           0x000003ff
#define AVR32_ERAY_ESID5_EID_OFFSET                                  0
#define AVR32_ERAY_ESID5_EID_SIZE                                   10
#define AVR32_ERAY_ESID5_MASK                               0x0000c3ff
#define AVR32_ERAY_ESID5_RESETVALUE                         0x00000000
#define AVR32_ERAY_ESID5_RXEA                                       14
#define AVR32_ERAY_ESID5_RXEA_MASK                          0x00004000
#define AVR32_ERAY_ESID5_RXEA_OFFSET                                14
#define AVR32_ERAY_ESID5_RXEA_SIZE                                   1
#define AVR32_ERAY_ESID5_RXEB                                       15
#define AVR32_ERAY_ESID5_RXEB_MASK                          0x00008000
#define AVR32_ERAY_ESID5_RXEB_OFFSET                                15
#define AVR32_ERAY_ESID5_RXEB_SIZE                                   1
#define AVR32_ERAY_ESID6                                    0x00000144
#define AVR32_ERAY_ESID6_EID                                         0
#define AVR32_ERAY_ESID6_EID_MASK                           0x000003ff
#define AVR32_ERAY_ESID6_EID_OFFSET                                  0
#define AVR32_ERAY_ESID6_EID_SIZE                                   10
#define AVR32_ERAY_ESID6_MASK                               0x0000c3ff
#define AVR32_ERAY_ESID6_RESETVALUE                         0x00000000
#define AVR32_ERAY_ESID6_RXEA                                       14
#define AVR32_ERAY_ESID6_RXEA_MASK                          0x00004000
#define AVR32_ERAY_ESID6_RXEA_OFFSET                                14
#define AVR32_ERAY_ESID6_RXEA_SIZE                                   1
#define AVR32_ERAY_ESID6_RXEB                                       15
#define AVR32_ERAY_ESID6_RXEB_MASK                          0x00008000
#define AVR32_ERAY_ESID6_RXEB_OFFSET                                15
#define AVR32_ERAY_ESID6_RXEB_SIZE                                   1
#define AVR32_ERAY_ESID7                                    0x00000148
#define AVR32_ERAY_ESID7_EID                                         0
#define AVR32_ERAY_ESID7_EID_MASK                           0x000003ff
#define AVR32_ERAY_ESID7_EID_OFFSET                                  0
#define AVR32_ERAY_ESID7_EID_SIZE                                   10
#define AVR32_ERAY_ESID7_MASK                               0x0000c3ff
#define AVR32_ERAY_ESID7_RESETVALUE                         0x00000000
#define AVR32_ERAY_ESID7_RXEA                                       14
#define AVR32_ERAY_ESID7_RXEA_MASK                          0x00004000
#define AVR32_ERAY_ESID7_RXEA_OFFSET                                14
#define AVR32_ERAY_ESID7_RXEA_SIZE                                   1
#define AVR32_ERAY_ESID7_RXEB                                       15
#define AVR32_ERAY_ESID7_RXEB_MASK                          0x00008000
#define AVR32_ERAY_ESID7_RXEB_OFFSET                                15
#define AVR32_ERAY_ESID7_RXEB_SIZE                                   1
#define AVR32_ERAY_ESID8                                    0x0000014c
#define AVR32_ERAY_ESID8_EID                                         0
#define AVR32_ERAY_ESID8_EID_MASK                           0x000003ff
#define AVR32_ERAY_ESID8_EID_OFFSET                                  0
#define AVR32_ERAY_ESID8_EID_SIZE                                   10
#define AVR32_ERAY_ESID8_MASK                               0x0000c3ff
#define AVR32_ERAY_ESID8_RESETVALUE                         0x00000000
#define AVR32_ERAY_ESID8_RXEA                                       14
#define AVR32_ERAY_ESID8_RXEA_MASK                          0x00004000
#define AVR32_ERAY_ESID8_RXEA_OFFSET                                14
#define AVR32_ERAY_ESID8_RXEA_SIZE                                   1
#define AVR32_ERAY_ESID8_RXEB                                       15
#define AVR32_ERAY_ESID8_RXEB_MASK                          0x00008000
#define AVR32_ERAY_ESID8_RXEB_OFFSET                                15
#define AVR32_ERAY_ESID8_RXEB_SIZE                                   1
#define AVR32_ERAY_ESID9                                    0x00000150
#define AVR32_ERAY_ESID9_EID                                         0
#define AVR32_ERAY_ESID9_EID_MASK                           0x000003ff
#define AVR32_ERAY_ESID9_EID_OFFSET                                  0
#define AVR32_ERAY_ESID9_EID_SIZE                                   10
#define AVR32_ERAY_ESID9_MASK                               0x0000c3ff
#define AVR32_ERAY_ESID9_RESETVALUE                         0x00000000
#define AVR32_ERAY_ESID9_RXEA                                       14
#define AVR32_ERAY_ESID9_RXEA_MASK                          0x00004000
#define AVR32_ERAY_ESID9_RXEA_OFFSET                                14
#define AVR32_ERAY_ESID9_RXEA_SIZE                                   1
#define AVR32_ERAY_ESID9_RXEB                                       15
#define AVR32_ERAY_ESID9_RXEB_MASK                          0x00008000
#define AVR32_ERAY_ESID9_RXEB_OFFSET                                15
#define AVR32_ERAY_ESID9_RXEB_SIZE                                   1
#define AVR32_ERAY_ESWT                                              0
#define AVR32_ERAY_ESWT_MASK                                0x00000001
#define AVR32_ERAY_ESWT_OFFSET                                       0
#define AVR32_ERAY_ESWT_SIZE                                         1
#define AVR32_ERAY_ETV                                               0
#define AVR32_ERAY_ETV_MASK                                 0xffffffff
#define AVR32_ERAY_ETV_OFFSET                                        0
#define AVR32_ERAY_ETV_SIZE                                         32
#define AVR32_ERAY_FCL                                      0x0000030c
#define AVR32_ERAY_FCL_CL                                            0
#define AVR32_ERAY_FCL_CL_MASK                              0x000000ff
#define AVR32_ERAY_FCL_CL_OFFSET                                     0
#define AVR32_ERAY_FCL_CL_SIZE                                       8
#define AVR32_ERAY_FCL_MASK                                 0x000000ff
#define AVR32_ERAY_FCL_RESETVALUE                           0x00000000
#define AVR32_ERAY_FDB                                               0
#define AVR32_ERAY_FDB_MASK                                 0x000000ff
#define AVR32_ERAY_FDB_OFFSET                                        0
#define AVR32_ERAY_FDB_SIZE                                          8
#define AVR32_ERAY_FFB                                               8
#define AVR32_ERAY_FFB_MASK                                 0x0000ff00
#define AVR32_ERAY_FFB_OFFSET                                        8
#define AVR32_ERAY_FFB_SIZE                                          8
#define AVR32_ERAY_FID_SIZE                                         11
#define AVR32_ERAY_FIXNO                                            16
#define AVR32_ERAY_FIXNO_MASK                               0x00070000
#define AVR32_ERAY_FIXNO_OFFSET                                     16
#define AVR32_ERAY_FIXNO_SIZE                                        3
#define AVR32_ERAY_FMB                                               8
#define AVR32_ERAY_FMBD                                              5
#define AVR32_ERAY_FMBD_MASK                                0x00000020
#define AVR32_ERAY_FMBD_OFFSET                                       5
#define AVR32_ERAY_FMBD_SIZE                                         1
#define AVR32_ERAY_FMB_MASK                                 0x00007f00
#define AVR32_ERAY_FMB_OFFSET                                        8
#define AVR32_ERAY_FMB_SIZE                                          7
#define AVR32_ERAY_FNFA                                              2
#define AVR32_ERAY_FNFA_MASK                                0x00000004
#define AVR32_ERAY_FNFA_OFFSET                                       2
#define AVR32_ERAY_FNFA_SIZE                                         1
#define AVR32_ERAY_FNFB                                              3
#define AVR32_ERAY_FNFB_MASK                                0x00000008
#define AVR32_ERAY_FNFB_OFFSET                                       3
#define AVR32_ERAY_FNFB_SIZE                                         1
#define AVR32_ERAY_FRF                                      0x00000304
#define AVR32_ERAY_FRFM                                     0x00000308
#define AVR32_ERAY_FRFM_MASK                                0x00001ffc
#define AVR32_ERAY_FRFM_MFID                                         2
#define AVR32_ERAY_FRFM_MFID_MASK                           0x00001ffc
#define AVR32_ERAY_FRFM_MFID_OFFSET                                  2
#define AVR32_ERAY_FRFM_MFID_SIZE                                   11
#define AVR32_ERAY_FRFM_RESETVALUE                          0x00000000
#define AVR32_ERAY_FRF_CH                                            0
#define AVR32_ERAY_FRF_CH_MASK                              0x00000003
#define AVR32_ERAY_FRF_CH_OFFSET                                     0
#define AVR32_ERAY_FRF_CH_SIZE                                       2
#define AVR32_ERAY_FRF_CYF                                          16
#define AVR32_ERAY_FRF_CYF_MASK                             0x007f0000
#define AVR32_ERAY_FRF_CYF_OFFSET                                   16
#define AVR32_ERAY_FRF_CYF_SIZE                                      7
#define AVR32_ERAY_FRF_FID                                           2
#define AVR32_ERAY_FRF_FID_MASK                             0x00001ffc
#define AVR32_ERAY_FRF_FID_OFFSET                                    2
#define AVR32_ERAY_FRF_FID_SIZE                                     11
#define AVR32_ERAY_FRF_MASK                                 0x01ff1fff
#define AVR32_ERAY_FRF_RESETVALUE                           0x00000000
#define AVR32_ERAY_FRF_RNF                                          24
#define AVR32_ERAY_FRF_RNF_MASK                             0x01000000
#define AVR32_ERAY_FRF_RNF_OFFSET                                   24
#define AVR32_ERAY_FRF_RNF_SIZE                                      1
#define AVR32_ERAY_FRF_RSS                                          23
#define AVR32_ERAY_FRF_RSS_MASK                             0x00800000
#define AVR32_ERAY_FRF_RSS_OFFSET                                   23
#define AVR32_ERAY_FRF_RSS_SIZE                                      1
#define AVR32_ERAY_FSI                                               6
#define AVR32_ERAY_FSI_MASK                                 0x00000040
#define AVR32_ERAY_FSI_OFFSET                                        6
#define AVR32_ERAY_FSI_SIZE                                          1
#define AVR32_ERAY_FSR                                      0x00000318
#define AVR32_ERAY_FSR_MASK                                 0x0000ff07
#define AVR32_ERAY_FSR_RESETVALUE                           0x00000000
#define AVR32_ERAY_FSR_RFCL                                          1
#define AVR32_ERAY_FSR_RFCL_MASK                            0x00000002
#define AVR32_ERAY_FSR_RFCL_OFFSET                                   1
#define AVR32_ERAY_FSR_RFCL_SIZE                                     1
#define AVR32_ERAY_FSR_RFFL                                          8
#define AVR32_ERAY_FSR_RFFL_MASK                            0x0000ff00
#define AVR32_ERAY_FSR_RFFL_OFFSET                                   8
#define AVR32_ERAY_FSR_RFFL_SIZE                                     8
#define AVR32_ERAY_FSR_RFNE                                          0
#define AVR32_ERAY_FSR_RFNE_MASK                            0x00000001
#define AVR32_ERAY_FSR_RFNE_OFFSET                                   0
#define AVR32_ERAY_FSR_RFNE_SIZE                                     1
#define AVR32_ERAY_FSR_RFO                                           2
#define AVR32_ERAY_FSR_RFO_MASK                             0x00000004
#define AVR32_ERAY_FSR_RFO_OFFSET                                    2
#define AVR32_ERAY_FSR_RFO_SIZE                                      1
#define AVR32_ERAY_FTA                                              14
#define AVR32_ERAY_FTA_MASK                                 0x00004000
#define AVR32_ERAY_FTA_OFFSET                                       14
#define AVR32_ERAY_FTA_SIZE                                          1
#define AVR32_ERAY_FTB                                              15
#define AVR32_ERAY_FTB_MASK                                 0x00008000
#define AVR32_ERAY_FTB_OFFSET                                       15
#define AVR32_ERAY_FTB_SIZE                                          1
#define AVR32_ERAY_GTUC1                                    0x000000a0
#define AVR32_ERAY_GTUC10                                   0x000000c4
#define AVR32_ERAY_GTUC10_MASK                              0x07ff3fff
#define AVR32_ERAY_GTUC10_MOC                                        0
#define AVR32_ERAY_GTUC10_MOC_MASK                          0x00003fff
#define AVR32_ERAY_GTUC10_MOC_OFFSET                                 0
#define AVR32_ERAY_GTUC10_MOC_SIZE                                  14
#define AVR32_ERAY_GTUC10_MRC                                       16
#define AVR32_ERAY_GTUC10_MRC_MASK                          0x07ff0000
#define AVR32_ERAY_GTUC10_MRC_OFFSET                                16
#define AVR32_ERAY_GTUC10_MRC_SIZE                                  11
#define AVR32_ERAY_GTUC10_RESETVALUE                        0x00000000
#define AVR32_ERAY_GTUC11                                   0x000000c8
#define AVR32_ERAY_GTUC11_EOC                                       16
#define AVR32_ERAY_GTUC11_EOCC                                       0
#define AVR32_ERAY_GTUC11_EOCC_MASK                         0x00000003
#define AVR32_ERAY_GTUC11_EOCC_OFFSET                                0
#define AVR32_ERAY_GTUC11_EOCC_SIZE                                  2
#define AVR32_ERAY_GTUC11_EOC_MASK                          0x00070000
#define AVR32_ERAY_GTUC11_EOC_OFFSET                                16
#define AVR32_ERAY_GTUC11_EOC_SIZE                                   3
#define AVR32_ERAY_GTUC11_ERC                                       24
#define AVR32_ERAY_GTUC11_ERCC                                       8
#define AVR32_ERAY_GTUC11_ERCC_MASK                         0x00000300
#define AVR32_ERAY_GTUC11_ERCC_OFFSET                                8
#define AVR32_ERAY_GTUC11_ERCC_SIZE                                  2
#define AVR32_ERAY_GTUC11_ERC_MASK                          0x07000000
#define AVR32_ERAY_GTUC11_ERC_OFFSET                                24
#define AVR32_ERAY_GTUC11_ERC_SIZE                                   3
#define AVR32_ERAY_GTUC11_MASK                              0x07070303
#define AVR32_ERAY_GTUC11_RESETVALUE                        0x00000000
#define AVR32_ERAY_GTUC1_MASK                               0x000fffff
#define AVR32_ERAY_GTUC1_RESETVALUE                         0x00000000
#define AVR32_ERAY_GTUC1_UT                                          0
#define AVR32_ERAY_GTUC1_UT_MASK                            0x000fffff
#define AVR32_ERAY_GTUC1_UT_OFFSET                                   0
#define AVR32_ERAY_GTUC1_UT_SIZE                                    20
#define AVR32_ERAY_GTUC2                                    0x000000a4
#define AVR32_ERAY_GTUC2_MASK                               0x000f3fff
#define AVR32_ERAY_GTUC2_MPC                                         0
#define AVR32_ERAY_GTUC2_MPC_MASK                           0x00003fff
#define AVR32_ERAY_GTUC2_MPC_OFFSET                                  0
#define AVR32_ERAY_GTUC2_MPC_SIZE                                   14
#define AVR32_ERAY_GTUC2_RESETVALUE                         0x00000000
#define AVR32_ERAY_GTUC2_SNM                                        16
#define AVR32_ERAY_GTUC2_SNM_MASK                           0x000f0000
#define AVR32_ERAY_GTUC2_SNM_OFFSET                                 16
#define AVR32_ERAY_GTUC2_SNM_SIZE                                    4
#define AVR32_ERAY_GTUC3                                    0x000000a8
#define AVR32_ERAY_GTUC3_MASK                               0x7f7fffff
#define AVR32_ERAY_GTUC3_MIOA                                       16
#define AVR32_ERAY_GTUC3_MIOA_MASK                          0x007f0000
#define AVR32_ERAY_GTUC3_MIOA_OFFSET                                16
#define AVR32_ERAY_GTUC3_MIOA_SIZE                                   7
#define AVR32_ERAY_GTUC3_MIOB                                       24
#define AVR32_ERAY_GTUC3_MIOB_MASK                          0x7f000000
#define AVR32_ERAY_GTUC3_MIOB_OFFSET                                24
#define AVR32_ERAY_GTUC3_MIOB_SIZE                                   7
#define AVR32_ERAY_GTUC3_RESETVALUE                         0x00000000
#define AVR32_ERAY_GTUC3_UIOA                                        0
#define AVR32_ERAY_GTUC3_UIOA_MASK                          0x000000ff
#define AVR32_ERAY_GTUC3_UIOA_OFFSET                                 0
#define AVR32_ERAY_GTUC3_UIOA_SIZE                                   8
#define AVR32_ERAY_GTUC3_UIOB                                        8
#define AVR32_ERAY_GTUC3_UIOB_MASK                          0x0000ff00
#define AVR32_ERAY_GTUC3_UIOB_OFFSET                                 8
#define AVR32_ERAY_GTUC3_UIOB_SIZE                                   8
#define AVR32_ERAY_GTUC4                                    0x000000ac
#define AVR32_ERAY_GTUC4_MASK                               0x3fff3fff
#define AVR32_ERAY_GTUC4_NIT                                         0
#define AVR32_ERAY_GTUC4_NIT_MASK                           0x00003fff
#define AVR32_ERAY_GTUC4_NIT_OFFSET                                  0
#define AVR32_ERAY_GTUC4_NIT_SIZE                                   14
#define AVR32_ERAY_GTUC4_OCS                                        16
#define AVR32_ERAY_GTUC4_OCS_MASK                           0x3fff0000
#define AVR32_ERAY_GTUC4_OCS_OFFSET                                 16
#define AVR32_ERAY_GTUC4_OCS_SIZE                                   14
#define AVR32_ERAY_GTUC4_RESETVALUE                         0x00000000
#define AVR32_ERAY_GTUC5                                    0x000000b0
#define AVR32_ERAY_GTUC5_CDD                                        16
#define AVR32_ERAY_GTUC5_CDD_MASK                           0x001f0000
#define AVR32_ERAY_GTUC5_CDD_OFFSET                                 16
#define AVR32_ERAY_GTUC5_CDD_SIZE                                    5
#define AVR32_ERAY_GTUC5_DCA                                         0
#define AVR32_ERAY_GTUC5_DCA_MASK                           0x000000ff
#define AVR32_ERAY_GTUC5_DCA_OFFSET                                  0
#define AVR32_ERAY_GTUC5_DCA_SIZE                                    8
#define AVR32_ERAY_GTUC5_DCB                                         8
#define AVR32_ERAY_GTUC5_DCB_MASK                           0x0000ff00
#define AVR32_ERAY_GTUC5_DCB_OFFSET                                  8
#define AVR32_ERAY_GTUC5_DCB_SIZE                                    8
#define AVR32_ERAY_GTUC5_DEC                                        24
#define AVR32_ERAY_GTUC5_DEC_MASK                           0xff000000
#define AVR32_ERAY_GTUC5_DEC_OFFSET                                 24
#define AVR32_ERAY_GTUC5_DEC_SIZE                                    8
#define AVR32_ERAY_GTUC5_MASK                               0xff1fffff
#define AVR32_ERAY_GTUC5_RESETVALUE                         0x00000000
#define AVR32_ERAY_GTUC6                                    0x000000b4
#define AVR32_ERAY_GTUC6_ASR                                         0
#define AVR32_ERAY_GTUC6_ASR_MASK                           0x000007ff
#define AVR32_ERAY_GTUC6_ASR_OFFSET                                  0
#define AVR32_ERAY_GTUC6_ASR_SIZE                                   11
#define AVR32_ERAY_GTUC6_MASK                               0x07ff07ff
#define AVR32_ERAY_GTUC6_MOD                                        16
#define AVR32_ERAY_GTUC6_MOD_MASK                           0x07ff0000
#define AVR32_ERAY_GTUC6_MOD_OFFSET                                 16
#define AVR32_ERAY_GTUC6_MOD_SIZE                                   11
#define AVR32_ERAY_GTUC6_RESETVALUE                         0x00000000
#define AVR32_ERAY_GTUC7                                    0x000000b8
#define AVR32_ERAY_GTUC7_MASK                               0x03ff03ff
#define AVR32_ERAY_GTUC7_NSS                                        16
#define AVR32_ERAY_GTUC7_NSS_MASK                           0x03ff0000
#define AVR32_ERAY_GTUC7_NSS_OFFSET                                 16
#define AVR32_ERAY_GTUC7_NSS_SIZE                                   10
#define AVR32_ERAY_GTUC7_RESETVALUE                         0x00000000
#define AVR32_ERAY_GTUC7_SSL                                         0
#define AVR32_ERAY_GTUC7_SSL_MASK                           0x000003ff
#define AVR32_ERAY_GTUC7_SSL_OFFSET                                  0
#define AVR32_ERAY_GTUC7_SSL_SIZE                                   10
#define AVR32_ERAY_GTUC8                                    0x000000bc
#define AVR32_ERAY_GTUC8_MASK                               0x1fff003f
#define AVR32_ERAY_GTUC8_MSL                                         0
#define AVR32_ERAY_GTUC8_MSL_MASK                           0x0000003f
#define AVR32_ERAY_GTUC8_MSL_OFFSET                                  0
#define AVR32_ERAY_GTUC8_MSL_SIZE                                    6
#define AVR32_ERAY_GTUC8_NMS                                        16
#define AVR32_ERAY_GTUC8_NMS_MASK                           0x1fff0000
#define AVR32_ERAY_GTUC8_NMS_OFFSET                                 16
#define AVR32_ERAY_GTUC8_NMS_SIZE                                   13
#define AVR32_ERAY_GTUC8_RESETVALUE                         0x00000000
#define AVR32_ERAY_GTUC9                                    0x000000c0
#define AVR32_ERAY_GTUC9_APO                                         0
#define AVR32_ERAY_GTUC9_APO_MASK                           0x0000003f
#define AVR32_ERAY_GTUC9_APO_OFFSET                                  0
#define AVR32_ERAY_GTUC9_APO_SIZE                                    6
#define AVR32_ERAY_GTUC9_DSI                                        16
#define AVR32_ERAY_GTUC9_DSI_MASK                           0x00030000
#define AVR32_ERAY_GTUC9_DSI_OFFSET                                 16
#define AVR32_ERAY_GTUC9_DSI_SIZE                                    2
#define AVR32_ERAY_GTUC9_MAPO                                        8
#define AVR32_ERAY_GTUC9_MAPO_MASK                          0x00001f00
#define AVR32_ERAY_GTUC9_MAPO_OFFSET                                 8
#define AVR32_ERAY_GTUC9_MAPO_SIZE                                   5
#define AVR32_ERAY_GTUC9_MASK                               0x00031f3f
#define AVR32_ERAY_GTUC9_RESETVALUE                         0x00000000
#define AVR32_ERAY_HCSE                                             23
#define AVR32_ERAY_HCSE_MASK                                0x00800000
#define AVR32_ERAY_HCSE_OFFSET                                      23
#define AVR32_ERAY_HCSE_SIZE                                         1
#define AVR32_ERAY_HRQ                                               7
#define AVR32_ERAY_HRQ_MASK                                 0x00000080
#define AVR32_ERAY_HRQ_OFFSET                                        7
#define AVR32_ERAY_HRQ_SIZE                                          1
#define AVR32_ERAY_IBCM                                     0x00000510
#define AVR32_ERAY_IBCM_LDSH                                         1
#define AVR32_ERAY_IBCM_LDSH_MASK                           0x00000002
#define AVR32_ERAY_IBCM_LDSH_OFFSET                                  1
#define AVR32_ERAY_IBCM_LDSH_SIZE                                    1
#define AVR32_ERAY_IBCM_LDSS                                        17
#define AVR32_ERAY_IBCM_LDSS_MASK                           0x00020000
#define AVR32_ERAY_IBCM_LDSS_OFFSET                                 17
#define AVR32_ERAY_IBCM_LDSS_SIZE                                    1
#define AVR32_ERAY_IBCM_LHSH                                         0
#define AVR32_ERAY_IBCM_LHSH_MASK                           0x00000001
#define AVR32_ERAY_IBCM_LHSH_OFFSET                                  0
#define AVR32_ERAY_IBCM_LHSH_SIZE                                    1
#define AVR32_ERAY_IBCM_LHSS                                        16
#define AVR32_ERAY_IBCM_LHSS_MASK                           0x00010000
#define AVR32_ERAY_IBCM_LHSS_OFFSET                                 16
#define AVR32_ERAY_IBCM_LHSS_SIZE                                    1
#define AVR32_ERAY_IBCM_MASK                                0x00070007
#define AVR32_ERAY_IBCM_RESETVALUE                          0x00000000
#define AVR32_ERAY_IBCM_STXRH                                        2
#define AVR32_ERAY_IBCM_STXRH_MASK                          0x00000004
#define AVR32_ERAY_IBCM_STXRH_OFFSET                                 2
#define AVR32_ERAY_IBCM_STXRH_SIZE                                   1
#define AVR32_ERAY_IBCM_STXRS                                       18
#define AVR32_ERAY_IBCM_STXRS_MASK                          0x00040000
#define AVR32_ERAY_IBCM_STXRS_OFFSET                                18
#define AVR32_ERAY_IBCM_STXRS_SIZE                                   1
#define AVR32_ERAY_IBCR                                     0x00000514
#define AVR32_ERAY_IBCR_IBRH                                         0
#define AVR32_ERAY_IBCR_IBRH_MASK                           0x0000007f
#define AVR32_ERAY_IBCR_IBRH_OFFSET                                  0
#define AVR32_ERAY_IBCR_IBRH_SIZE                                    7
#define AVR32_ERAY_IBCR_IBRS                                        16
#define AVR32_ERAY_IBCR_IBRS_MASK                           0x007f0000
#define AVR32_ERAY_IBCR_IBRS_OFFSET                                 16
#define AVR32_ERAY_IBCR_IBRS_SIZE                                    7
#define AVR32_ERAY_IBCR_IBSYH                                       15
#define AVR32_ERAY_IBCR_IBSYH_MASK                          0x00008000
#define AVR32_ERAY_IBCR_IBSYH_OFFSET                                15
#define AVR32_ERAY_IBCR_IBSYH_SIZE                                   1
#define AVR32_ERAY_IBCR_IBSYS                                       31
#define AVR32_ERAY_IBCR_IBSYS_MASK                          0x80000000
#define AVR32_ERAY_IBCR_IBSYS_OFFSET                                31
#define AVR32_ERAY_IBCR_IBSYS_SIZE                                   1
#define AVR32_ERAY_IBCR_MASK                                0x807f807f
#define AVR32_ERAY_IBCR_RESETVALUE                          0x00000000
#define AVR32_ERAY_IBRH                                              0
#define AVR32_ERAY_IBRH_MASK                                0x0000007f
#define AVR32_ERAY_IBRH_OFFSET                                       0
#define AVR32_ERAY_IBRH_SIZE                                         7
#define AVR32_ERAY_IBRS                                             16
#define AVR32_ERAY_IBRS_MASK                                0x007f0000
#define AVR32_ERAY_IBRS_OFFSET                                      16
#define AVR32_ERAY_IBRS_SIZE                                         7
#define AVR32_ERAY_IBSYH                                            15
#define AVR32_ERAY_IBSYH_MASK                               0x00008000
#define AVR32_ERAY_IBSYH_OFFSET                                     15
#define AVR32_ERAY_IBSYH_SIZE                                        1
#define AVR32_ERAY_IBSYS                                            31
#define AVR32_ERAY_IBSYS_MASK                               0x80000000
#define AVR32_ERAY_IBSYS_OFFSET                                     31
#define AVR32_ERAY_IBSYS_SIZE                                        1
#define AVR32_ERAY_IDR                                      0x00000820
#define AVR32_ERAY_IDR_MASK                                 0x00000003
#define AVR32_ERAY_IDR_RESETVALUE                           0x00000000
#define AVR32_ERAY_IDR_SAIM1                                         0
#define AVR32_ERAY_IDR_SAIM1_MASK                           0x00000001
#define AVR32_ERAY_IDR_SAIM1_OFFSET                                  0
#define AVR32_ERAY_IDR_SAIM1_SIZE                                    1
#define AVR32_ERAY_IDR_SAIM2                                         1
#define AVR32_ERAY_IDR_SAIM2_MASK                           0x00000002
#define AVR32_ERAY_IDR_SAIM2_OFFSET                                  1
#define AVR32_ERAY_IDR_SAIM2_SIZE                                    1
#define AVR32_ERAY_IER                                      0x0000081c
#define AVR32_ERAY_IER_MASK                                 0x00000003
#define AVR32_ERAY_IER_RESETVALUE                           0x00000000
#define AVR32_ERAY_IER_SAIM1                                         0
#define AVR32_ERAY_IER_SAIM1_MASK                           0x00000001
#define AVR32_ERAY_IER_SAIM1_OFFSET                                  0
#define AVR32_ERAY_IER_SAIM1_SIZE                                    1
#define AVR32_ERAY_IER_SAIM2                                         1
#define AVR32_ERAY_IER_SAIM2_MASK                           0x00000002
#define AVR32_ERAY_IER_SAIM2_OFFSET                                  1
#define AVR32_ERAY_IER_SAIM2_SIZE                                    1
#define AVR32_ERAY_IFVER                                            12
#define AVR32_ERAY_IFVER_MASK                               0x0000f000
#define AVR32_ERAY_IFVER_OFFSET                                     12
#define AVR32_ERAY_IFVER_SIZE                                        4
#define AVR32_ERAY_IIBA                                              9
#define AVR32_ERAY_IIBAE                                             9
#define AVR32_ERAY_IIBAE_MASK                               0x00000200
#define AVR32_ERAY_IIBAE_OFFSET                                      9
#define AVR32_ERAY_IIBAE_SIZE                                        1
#define AVR32_ERAY_IIBAL                                             9
#define AVR32_ERAY_IIBAL_MASK                               0x00000200
#define AVR32_ERAY_IIBAL_OFFSET                                      9
#define AVR32_ERAY_IIBAL_SIZE                                        1
#define AVR32_ERAY_IIBA_MASK                                0x00000200
#define AVR32_ERAY_IIBA_OFFSET                                       9
#define AVR32_ERAY_IIBA_SIZE                                         1
#define AVR32_ERAY_ILE                                      0x00000040
#define AVR32_ERAY_ILE_EINT0                                         0
#define AVR32_ERAY_ILE_EINT0_MASK                           0x00000001
#define AVR32_ERAY_ILE_EINT0_OFFSET                                  0
#define AVR32_ERAY_ILE_EINT0_SIZE                                    1
#define AVR32_ERAY_ILE_EINT1                                         1
#define AVR32_ERAY_ILE_EINT1_MASK                           0x00000002
#define AVR32_ERAY_ILE_EINT1_OFFSET                                  1
#define AVR32_ERAY_ILE_EINT1_SIZE                                    1
#define AVR32_ERAY_ILE_MASK                                 0x00000003
#define AVR32_ERAY_ILE_RESETVALUE                           0x00000000
#define AVR32_ERAY_IMR                                      0x00000818
#define AVR32_ERAY_IMR_MASK                                 0x00000003
#define AVR32_ERAY_IMR_RESETVALUE                           0x00000000
#define AVR32_ERAY_IMR_SAIM1                                         0
#define AVR32_ERAY_IMR_SAIM1_MASK                           0x00000001
#define AVR32_ERAY_IMR_SAIM1_OFFSET                                  0
#define AVR32_ERAY_IMR_SAIM1_SIZE                                    1
#define AVR32_ERAY_IMR_SAIM2                                         1
#define AVR32_ERAY_IMR_SAIM2_MASK                           0x00000002
#define AVR32_ERAY_IMR_SAIM2_OFFSET                                  1
#define AVR32_ERAY_IMR_SAIM2_SIZE                                    1
#define AVR32_ERAY_IOBA                                             10
#define AVR32_ERAY_IOBAE                                            10
#define AVR32_ERAY_IOBAE_MASK                               0x00000400
#define AVR32_ERAY_IOBAE_OFFSET                                     10
#define AVR32_ERAY_IOBAE_SIZE                                        1
#define AVR32_ERAY_IOBAL                                            10
#define AVR32_ERAY_IOBAL_MASK                               0x00000400
#define AVR32_ERAY_IOBAL_OFFSET                                     10
#define AVR32_ERAY_IOBAL_SIZE                                        1
#define AVR32_ERAY_IOBA_MASK                                0x00000400
#define AVR32_ERAY_IOBA_OFFSET                                      10
#define AVR32_ERAY_IOBA_SIZE                                         1
#define AVR32_ERAY_LCB                                              16
#define AVR32_ERAY_LCB_MASK                                 0x00ff0000
#define AVR32_ERAY_LCB_OFFSET                                       16
#define AVR32_ERAY_LCB_SIZE                                          8
#define AVR32_ERAY_LCK                                      0x0000001c
#define AVR32_ERAY_LCK_CLK                                           0
#define AVR32_ERAY_LCK_CLK_MASK                             0x000000ff
#define AVR32_ERAY_LCK_CLK_OFFSET                                    0
#define AVR32_ERAY_LCK_CLK_SIZE                                      8
#define AVR32_ERAY_LCK_MASK                                 0x0000ffff
#define AVR32_ERAY_LCK_RESETVALUE                           0x00000000
#define AVR32_ERAY_LCK_TMK                                           8
#define AVR32_ERAY_LCK_TMK_MASK                             0x0000ff00
#define AVR32_ERAY_LCK_TMK_OFFSET                                    8
#define AVR32_ERAY_LCK_TMK_SIZE                                      8
#define AVR32_ERAY_LDSH                                              1
#define AVR32_ERAY_LDSH_MASK                                0x00000002
#define AVR32_ERAY_LDSH_OFFSET                                       1
#define AVR32_ERAY_LDSH_SIZE                                         1
#define AVR32_ERAY_LDSS                                             17
#define AVR32_ERAY_LDSS_MASK                                0x00020000
#define AVR32_ERAY_LDSS_OFFSET                                      17
#define AVR32_ERAY_LDSS_SIZE                                         1
#define AVR32_ERAY_LDTA                                              0
#define AVR32_ERAY_LDTA_MASK                                0x000007ff
#define AVR32_ERAY_LDTA_OFFSET                                       0
#define AVR32_ERAY_LDTA_SIZE                                        11
#define AVR32_ERAY_LDTB                                             16
#define AVR32_ERAY_LDTB_MASK                                0x07ff0000
#define AVR32_ERAY_LDTB_OFFSET                                      16
#define AVR32_ERAY_LDTB_SIZE                                        11
#define AVR32_ERAY_LDTS                                     0x00000314
#define AVR32_ERAY_LDTS_LDTA                                         0
#define AVR32_ERAY_LDTS_LDTA_MASK                           0x000007ff
#define AVR32_ERAY_LDTS_LDTA_OFFSET                                  0
#define AVR32_ERAY_LDTS_LDTA_SIZE                                   11
#define AVR32_ERAY_LDTS_LDTB                                        16
#define AVR32_ERAY_LDTS_LDTB_MASK                           0x07ff0000
#define AVR32_ERAY_LDTS_LDTB_OFFSET                                 16
#define AVR32_ERAY_LDTS_LDTB_SIZE                                   11
#define AVR32_ERAY_LDTS_MASK                                0x07ff07ff
#define AVR32_ERAY_LDTS_RESETVALUE                          0x00000000
#define AVR32_ERAY_LHSH                                              0
#define AVR32_ERAY_LHSH_MASK                                0x00000001
#define AVR32_ERAY_LHSH_OFFSET                                       0
#define AVR32_ERAY_LHSH_SIZE                                         1
#define AVR32_ERAY_LHSS                                             16
#define AVR32_ERAY_LHSS_MASK                                0x00010000
#define AVR32_ERAY_LHSS_OFFSET                                      16
#define AVR32_ERAY_LHSS_SIZE                                         1
#define AVR32_ERAY_LT                                                0
#define AVR32_ERAY_LTN                                              24
#define AVR32_ERAY_LTN_MASK                                 0x0f000000
#define AVR32_ERAY_LTN_OFFSET                                       24
#define AVR32_ERAY_LTN_SIZE                                          4
#define AVR32_ERAY_LTVA                                             17
#define AVR32_ERAY_LTVAE                                            17
#define AVR32_ERAY_LTVAE_MASK                               0x00020000
#define AVR32_ERAY_LTVAE_OFFSET                                     17
#define AVR32_ERAY_LTVAE_SIZE                                        1
#define AVR32_ERAY_LTVAL                                            17
#define AVR32_ERAY_LTVAL_MASK                               0x00020000
#define AVR32_ERAY_LTVAL_OFFSET                                     17
#define AVR32_ERAY_LTVAL_SIZE                                        1
#define AVR32_ERAY_LTVA_MASK                                0x00020000
#define AVR32_ERAY_LTVA_OFFSET                                      17
#define AVR32_ERAY_LTVA_SIZE                                         1
#define AVR32_ERAY_LTVB                                             25
#define AVR32_ERAY_LTVBE                                            25
#define AVR32_ERAY_LTVBE_MASK                               0x02000000
#define AVR32_ERAY_LTVBE_OFFSET                                     25
#define AVR32_ERAY_LTVBE_SIZE                                        1
#define AVR32_ERAY_LTVBL                                            25
#define AVR32_ERAY_LTVBL_MASK                               0x02000000
#define AVR32_ERAY_LTVBL_OFFSET                                     25
#define AVR32_ERAY_LTVBL_SIZE                                        1
#define AVR32_ERAY_LTVB_MASK                                0x02000000
#define AVR32_ERAY_LTVB_OFFSET                                      25
#define AVR32_ERAY_LTVB_SIZE                                         1
#define AVR32_ERAY_LT_MASK                                  0x001fffff
#define AVR32_ERAY_LT_OFFSET                                         0
#define AVR32_ERAY_LT_SIZE                                          21
#define AVR32_ERAY_MAPO                                              8
#define AVR32_ERAY_MAPO_MASK                                0x00001f00
#define AVR32_ERAY_MAPO_OFFSET                                       8
#define AVR32_ERAY_MAPO_SIZE                                         5
#define AVR32_ERAY_MBC                                               0
#define AVR32_ERAY_MBC_MASK                                 0xffffffff
#define AVR32_ERAY_MBC_OFFSET                                        0
#define AVR32_ERAY_MBC_SIZE                                         32
#define AVR32_ERAY_MBI                                              29
#define AVR32_ERAY_MBI_MASK                                 0x20000000
#define AVR32_ERAY_MBI_OFFSET                                       29
#define AVR32_ERAY_MBI_SIZE                                          1
#define AVR32_ERAY_MBS                                      0x0000070c
#define AVR32_ERAY_MBSC1                                    0x00000340
#define AVR32_ERAY_MBSC1_MASK                               0xffffffff
#define AVR32_ERAY_MBSC1_MBC                                         0
#define AVR32_ERAY_MBSC1_MBC_MASK                           0xffffffff
#define AVR32_ERAY_MBSC1_MBC_OFFSET                                  0
#define AVR32_ERAY_MBSC1_MBC_SIZE                                   32
#define AVR32_ERAY_MBSC1_RESETVALUE                         0x00000000
#define AVR32_ERAY_MBSC2                                    0x00000344
#define AVR32_ERAY_MBSC2_MASK                               0xffffffff
#define AVR32_ERAY_MBSC2_MBC                                         0
#define AVR32_ERAY_MBSC2_MBC_MASK                           0xffffffff
#define AVR32_ERAY_MBSC2_MBC_OFFSET                                  0
#define AVR32_ERAY_MBSC2_MBC_SIZE                                   32
#define AVR32_ERAY_MBSC2_RESETVALUE                         0x00000000
#define AVR32_ERAY_MBSC3                                    0x00000348
#define AVR32_ERAY_MBSC3_MASK                               0xffffffff
#define AVR32_ERAY_MBSC3_MBC                                         0
#define AVR32_ERAY_MBSC3_MBC_MASK                           0xffffffff
#define AVR32_ERAY_MBSC3_MBC_OFFSET                                  0
#define AVR32_ERAY_MBSC3_MBC_SIZE                                   32
#define AVR32_ERAY_MBSC3_RESETVALUE                         0x00000000
#define AVR32_ERAY_MBSC4                                    0x0000034c
#define AVR32_ERAY_MBSC4_MASK                               0xffffffff
#define AVR32_ERAY_MBSC4_MBC                                         0
#define AVR32_ERAY_MBSC4_MBC_MASK                           0xffffffff
#define AVR32_ERAY_MBSC4_MBC_OFFSET                                  0
#define AVR32_ERAY_MBSC4_MBC_SIZE                                   32
#define AVR32_ERAY_MBSC4_RESETVALUE                         0x00000000
#define AVR32_ERAY_MBSI                                             14
#define AVR32_ERAY_MBSIE                                            14
#define AVR32_ERAY_MBSIE_MASK                               0x00004000
#define AVR32_ERAY_MBSIE_OFFSET                                     14
#define AVR32_ERAY_MBSIE_SIZE                                        1
#define AVR32_ERAY_MBSIL                                            14
#define AVR32_ERAY_MBSIL_MASK                               0x00004000
#define AVR32_ERAY_MBSIL_OFFSET                                     14
#define AVR32_ERAY_MBSIL_SIZE                                        1
#define AVR32_ERAY_MBSI_MASK                                0x00004000
#define AVR32_ERAY_MBSI_OFFSET                                      14
#define AVR32_ERAY_MBSI_SIZE                                         1
#define AVR32_ERAY_MBS_CCS                                          16
#define AVR32_ERAY_MBS_CCS_MASK                             0x003f0000
#define AVR32_ERAY_MBS_CCS_OFFSET                                   16
#define AVR32_ERAY_MBS_CCS_SIZE                                      6
#define AVR32_ERAY_MBS_CEOA                                          4
#define AVR32_ERAY_MBS_CEOA_MASK                            0x00000010
#define AVR32_ERAY_MBS_CEOA_OFFSET                                   4
#define AVR32_ERAY_MBS_CEOA_SIZE                                     1
#define AVR32_ERAY_MBS_CEOB                                          5
#define AVR32_ERAY_MBS_CEOB_MASK                            0x00000020
#define AVR32_ERAY_MBS_CEOB_OFFSET                                   5
#define AVR32_ERAY_MBS_CEOB_SIZE                                     1
#define AVR32_ERAY_MBS_ESA                                          10
#define AVR32_ERAY_MBS_ESA_MASK                             0x00000400
#define AVR32_ERAY_MBS_ESA_OFFSET                                   10
#define AVR32_ERAY_MBS_ESA_SIZE                                      1
#define AVR32_ERAY_MBS_ESB                                          11
#define AVR32_ERAY_MBS_ESB_MASK                             0x00000800
#define AVR32_ERAY_MBS_ESB_OFFSET                                   11
#define AVR32_ERAY_MBS_ESB_SIZE                                      1
#define AVR32_ERAY_MBS_FTA                                          14
#define AVR32_ERAY_MBS_FTA_MASK                             0x00004000
#define AVR32_ERAY_MBS_FTA_OFFSET                                   14
#define AVR32_ERAY_MBS_FTA_SIZE                                      1
#define AVR32_ERAY_MBS_FTB                                          15
#define AVR32_ERAY_MBS_FTB_MASK                             0x00008000
#define AVR32_ERAY_MBS_FTB_OFFSET                                   15
#define AVR32_ERAY_MBS_FTB_SIZE                                      1
#define AVR32_ERAY_MBS_MASK                                 0x3f3fdfff
#define AVR32_ERAY_MBS_MLST                                         12
#define AVR32_ERAY_MBS_MLST_MASK                            0x00001000
#define AVR32_ERAY_MBS_MLST_OFFSET                                  12
#define AVR32_ERAY_MBS_MLST_SIZE                                     1
#define AVR32_ERAY_MBS_NFIS                                         27
#define AVR32_ERAY_MBS_NFIS_MASK                            0x08000000
#define AVR32_ERAY_MBS_NFIS_OFFSET                                  27
#define AVR32_ERAY_MBS_NFIS_SIZE                                     1
#define AVR32_ERAY_MBS_PPIS                                         28
#define AVR32_ERAY_MBS_PPIS_MASK                            0x10000000
#define AVR32_ERAY_MBS_PPIS_OFFSET                                  28
#define AVR32_ERAY_MBS_PPIS_SIZE                                     1
#define AVR32_ERAY_MBS_RCIS                                         24
#define AVR32_ERAY_MBS_RCIS_MASK                            0x01000000
#define AVR32_ERAY_MBS_RCIS_OFFSET                                  24
#define AVR32_ERAY_MBS_RCIS_SIZE                                     1
#define AVR32_ERAY_MBS_RESETVALUE                           0x00000000
#define AVR32_ERAY_MBS_RESS                                         29
#define AVR32_ERAY_MBS_RESS_MASK                            0x20000000
#define AVR32_ERAY_MBS_RESS_OFFSET                                  29
#define AVR32_ERAY_MBS_RESS_SIZE                                     1
#define AVR32_ERAY_MBS_SEOA                                          2
#define AVR32_ERAY_MBS_SEOA_MASK                            0x00000004
#define AVR32_ERAY_MBS_SEOA_OFFSET                                   2
#define AVR32_ERAY_MBS_SEOA_SIZE                                     1
#define AVR32_ERAY_MBS_SEOB                                          3
#define AVR32_ERAY_MBS_SEOB_MASK                            0x00000008
#define AVR32_ERAY_MBS_SEOB_OFFSET                                   3
#define AVR32_ERAY_MBS_SEOB_SIZE                                     1
#define AVR32_ERAY_MBS_SFIS                                         25
#define AVR32_ERAY_MBS_SFIS_MASK                            0x02000000
#define AVR32_ERAY_MBS_SFIS_OFFSET                                  25
#define AVR32_ERAY_MBS_SFIS_SIZE                                     1
#define AVR32_ERAY_MBS_SVOA                                          6
#define AVR32_ERAY_MBS_SVOA_MASK                            0x00000040
#define AVR32_ERAY_MBS_SVOA_OFFSET                                   6
#define AVR32_ERAY_MBS_SVOA_SIZE                                     1
#define AVR32_ERAY_MBS_SVOB                                          7
#define AVR32_ERAY_MBS_SVOB_MASK                            0x00000080
#define AVR32_ERAY_MBS_SVOB_OFFSET                                   7
#define AVR32_ERAY_MBS_SVOB_SIZE                                     1
#define AVR32_ERAY_MBS_SYNS                                         26
#define AVR32_ERAY_MBS_SYNS_MASK                            0x04000000
#define AVR32_ERAY_MBS_SYNS_OFFSET                                  26
#define AVR32_ERAY_MBS_SYNS_SIZE                                     1
#define AVR32_ERAY_MBS_TCIA                                          8
#define AVR32_ERAY_MBS_TCIA_MASK                            0x00000100
#define AVR32_ERAY_MBS_TCIA_OFFSET                                   8
#define AVR32_ERAY_MBS_TCIA_SIZE                                     1
#define AVR32_ERAY_MBS_TCIB                                          9
#define AVR32_ERAY_MBS_TCIB_MASK                            0x00000200
#define AVR32_ERAY_MBS_TCIB_OFFSET                                   9
#define AVR32_ERAY_MBS_TCIB_SIZE                                     1
#define AVR32_ERAY_MBS_VFRA                                          0
#define AVR32_ERAY_MBS_VFRA_MASK                            0x00000001
#define AVR32_ERAY_MBS_VFRA_OFFSET                                   0
#define AVR32_ERAY_MBS_VFRA_SIZE                                     1
#define AVR32_ERAY_MBS_VFRB                                          1
#define AVR32_ERAY_MBS_VFRB_MASK                            0x00000002
#define AVR32_ERAY_MBS_VFRB_OFFSET                                   1
#define AVR32_ERAY_MBS_VFRB_SIZE                                     1
#define AVR32_ERAY_MBT                                              16
#define AVR32_ERAY_MBT_MASK                                 0x007f0000
#define AVR32_ERAY_MBT_OFFSET                                       16
#define AVR32_ERAY_MBT_SIZE                                          7
#define AVR32_ERAY_MBU                                              24
#define AVR32_ERAY_MBU_MASK                                 0x7f000000
#define AVR32_ERAY_MBU_OFFSET                                       24
#define AVR32_ERAY_MBU_SIZE                                          7
#define AVR32_ERAY_MFID                                              2
#define AVR32_ERAY_MFID_MASK                                0x00001ffc
#define AVR32_ERAY_MFID_OFFSET                                       2
#define AVR32_ERAY_MFID_SIZE                                        11
#define AVR32_ERAY_MFMB                                              6
#define AVR32_ERAY_MFMB_MASK                                0x00000040
#define AVR32_ERAY_MFMB_OFFSET                                       6
#define AVR32_ERAY_MFMB_SIZE                                         1
#define AVR32_ERAY_MHDC                                     0x00000098
#define AVR32_ERAY_MHDC_MASK                                0x1fff007f
#define AVR32_ERAY_MHDC_RESETVALUE                          0x00000000
#define AVR32_ERAY_MHDC_SFDL                                         0
#define AVR32_ERAY_MHDC_SFDL_MASK                           0x0000007f
#define AVR32_ERAY_MHDC_SFDL_OFFSET                                  0
#define AVR32_ERAY_MHDC_SFDL_SIZE                                    7
#define AVR32_ERAY_MHDC_SLT                                         16
#define AVR32_ERAY_MHDC_SLT_MASK                            0x1fff0000
#define AVR32_ERAY_MHDC_SLT_OFFSET                                  16
#define AVR32_ERAY_MHDC_SLT_SIZE                                    13
#define AVR32_ERAY_MHDF                                     0x0000031c
#define AVR32_ERAY_MHDF_FNFA                                         2
#define AVR32_ERAY_MHDF_FNFA_MASK                           0x00000004
#define AVR32_ERAY_MHDF_FNFA_OFFSET                                  2
#define AVR32_ERAY_MHDF_FNFA_SIZE                                    1
#define AVR32_ERAY_MHDF_FNFB                                         3
#define AVR32_ERAY_MHDF_FNFB_MASK                           0x00000008
#define AVR32_ERAY_MHDF_FNFB_OFFSET                                  3
#define AVR32_ERAY_MHDF_FNFB_SIZE                                    1
#define AVR32_ERAY_MHDF_MASK                                0x000001ff
#define AVR32_ERAY_MHDF_RESETVALUE                          0x00000000
#define AVR32_ERAY_MHDF_SNUA                                         0
#define AVR32_ERAY_MHDF_SNUA_MASK                           0x00000001
#define AVR32_ERAY_MHDF_SNUA_OFFSET                                  0
#define AVR32_ERAY_MHDF_SNUA_SIZE                                    1
#define AVR32_ERAY_MHDF_SNUB                                         1
#define AVR32_ERAY_MHDF_SNUB_MASK                           0x00000002
#define AVR32_ERAY_MHDF_SNUB_OFFSET                                  1
#define AVR32_ERAY_MHDF_SNUB_SIZE                                    1
#define AVR32_ERAY_MHDF_TBFA                                         4
#define AVR32_ERAY_MHDF_TBFA_MASK                           0x00000010
#define AVR32_ERAY_MHDF_TBFA_OFFSET                                  4
#define AVR32_ERAY_MHDF_TBFA_SIZE                                    1
#define AVR32_ERAY_MHDF_TBFB                                         5
#define AVR32_ERAY_MHDF_TBFB_MASK                           0x00000020
#define AVR32_ERAY_MHDF_TBFB_OFFSET                                  5
#define AVR32_ERAY_MHDF_TBFB_SIZE                                    1
#define AVR32_ERAY_MHDF_TNSA                                         6
#define AVR32_ERAY_MHDF_TNSA_MASK                           0x00000040
#define AVR32_ERAY_MHDF_TNSA_OFFSET                                  6
#define AVR32_ERAY_MHDF_TNSA_SIZE                                    1
#define AVR32_ERAY_MHDF_TNSB                                         7
#define AVR32_ERAY_MHDF_TNSB_MASK                           0x00000080
#define AVR32_ERAY_MHDF_TNSB_OFFSET                                  7
#define AVR32_ERAY_MHDF_TNSB_SIZE                                    1
#define AVR32_ERAY_MHDF_WAHP                                         8
#define AVR32_ERAY_MHDF_WAHP_MASK                           0x00000100
#define AVR32_ERAY_MHDF_WAHP_OFFSET                                  8
#define AVR32_ERAY_MHDF_WAHP_SIZE                                    1
#define AVR32_ERAY_MHDS                                     0x00000310
#define AVR32_ERAY_MHDS_CRAM                                         7
#define AVR32_ERAY_MHDS_CRAM_MASK                           0x00000080
#define AVR32_ERAY_MHDS_CRAM_OFFSET                                  7
#define AVR32_ERAY_MHDS_CRAM_SIZE                                    1
#define AVR32_ERAY_MHDS_FMB                                          8
#define AVR32_ERAY_MHDS_FMBD                                         5
#define AVR32_ERAY_MHDS_FMBD_MASK                           0x00000020
#define AVR32_ERAY_MHDS_FMBD_OFFSET                                  5
#define AVR32_ERAY_MHDS_FMBD_SIZE                                    1
#define AVR32_ERAY_MHDS_FMB_MASK                            0x00007f00
#define AVR32_ERAY_MHDS_FMB_OFFSET                                   8
#define AVR32_ERAY_MHDS_FMB_SIZE                                     7
#define AVR32_ERAY_MHDS_MASK                                0x7f7f7fff
#define AVR32_ERAY_MHDS_MBT                                         16
#define AVR32_ERAY_MHDS_MBT_MASK                            0x007f0000
#define AVR32_ERAY_MHDS_MBT_OFFSET                                  16
#define AVR32_ERAY_MHDS_MBT_SIZE                                     7
#define AVR32_ERAY_MHDS_MBU                                         24
#define AVR32_ERAY_MHDS_MBU_MASK                            0x7f000000
#define AVR32_ERAY_MHDS_MBU_OFFSET                                  24
#define AVR32_ERAY_MHDS_MBU_SIZE                                     7
#define AVR32_ERAY_MHDS_MFMB                                         6
#define AVR32_ERAY_MHDS_MFMB_MASK                           0x00000040
#define AVR32_ERAY_MHDS_MFMB_OFFSET                                  6
#define AVR32_ERAY_MHDS_MFMB_SIZE                                    1
#define AVR32_ERAY_MHDS_PIBF                                         0
#define AVR32_ERAY_MHDS_PIBF_MASK                           0x00000001
#define AVR32_ERAY_MHDS_PIBF_OFFSET                                  0
#define AVR32_ERAY_MHDS_PIBF_SIZE                                    1
#define AVR32_ERAY_MHDS_PMR                                          2
#define AVR32_ERAY_MHDS_PMR_MASK                            0x00000004
#define AVR32_ERAY_MHDS_PMR_OFFSET                                   2
#define AVR32_ERAY_MHDS_PMR_SIZE                                     1
#define AVR32_ERAY_MHDS_POBF                                         1
#define AVR32_ERAY_MHDS_POBF_MASK                           0x00000002
#define AVR32_ERAY_MHDS_POBF_OFFSET                                  1
#define AVR32_ERAY_MHDS_POBF_SIZE                                    1
#define AVR32_ERAY_MHDS_PTBF1                                        3
#define AVR32_ERAY_MHDS_PTBF1_MASK                          0x00000008
#define AVR32_ERAY_MHDS_PTBF1_OFFSET                                 3
#define AVR32_ERAY_MHDS_PTBF1_SIZE                                   1
#define AVR32_ERAY_MHDS_PTBF2                                        4
#define AVR32_ERAY_MHDS_PTBF2_MASK                          0x00000010
#define AVR32_ERAY_MHDS_PTBF2_OFFSET                                 4
#define AVR32_ERAY_MHDS_PTBF2_SIZE                                   1
#define AVR32_ERAY_MHDS_RESETVALUE                          0x00000000
#define AVR32_ERAY_MHF                                              11
#define AVR32_ERAY_MHFE                                             11
#define AVR32_ERAY_MHFE_MASK                                0x00000800
#define AVR32_ERAY_MHFE_OFFSET                                      11
#define AVR32_ERAY_MHFE_SIZE                                         1
#define AVR32_ERAY_MHFL                                             11
#define AVR32_ERAY_MHFL_MASK                                0x00000800
#define AVR32_ERAY_MHFL_OFFSET                                      11
#define AVR32_ERAY_MHFL_SIZE                                         1
#define AVR32_ERAY_MHF_MASK                                 0x00000800
#define AVR32_ERAY_MHF_OFFSET                                       11
#define AVR32_ERAY_MHF_SIZE                                          1
#define AVR32_ERAY_MIOA                                             16
#define AVR32_ERAY_MIOA_MASK                                0x007f0000
#define AVR32_ERAY_MIOA_OFFSET                                      16
#define AVR32_ERAY_MIOA_SIZE                                         7
#define AVR32_ERAY_MIOB                                             24
#define AVR32_ERAY_MIOB_MASK                                0x7f000000
#define AVR32_ERAY_MIOB_OFFSET                                      24
#define AVR32_ERAY_MIOB_SIZE                                         7
#define AVR32_ERAY_MLST                                             12
#define AVR32_ERAY_MLST_MASK                                0x00001000
#define AVR32_ERAY_MLST_OFFSET                                      12
#define AVR32_ERAY_MLST_SIZE                                         1
#define AVR32_ERAY_MOC                                               0
#define AVR32_ERAY_MOCS                                             16
#define AVR32_ERAY_MOCS_MASK                                0x00010000
#define AVR32_ERAY_MOCS_OFFSET                                      16
#define AVR32_ERAY_MOCS_SIZE                                         1
#define AVR32_ERAY_MOC_MASK                                 0x00003fff
#define AVR32_ERAY_MOC_OFFSET                                        0
#define AVR32_ERAY_MOC_SIZE                                         14
#define AVR32_ERAY_MOD                                              16
#define AVR32_ERAY_MOD_MASK                                 0x07ff0000
#define AVR32_ERAY_MOD_OFFSET                                       16
#define AVR32_ERAY_MOD_SIZE                                         11
#define AVR32_ERAY_MON                                               8
#define AVR32_ERAY_MON_MASK                                 0x0000ff00
#define AVR32_ERAY_MON_OFFSET                                        8
#define AVR32_ERAY_MON_SIZE                                          8
#define AVR32_ERAY_MPC                                               0
#define AVR32_ERAY_MPC_MASK                                 0x00003fff
#define AVR32_ERAY_MPC_OFFSET                                        0
#define AVR32_ERAY_MPC_SIZE                                         14
#define AVR32_ERAY_MRC                                      0x00000300
#define AVR32_ERAY_MRCS                                             18
#define AVR32_ERAY_MRCS_MASK                                0x00040000
#define AVR32_ERAY_MRCS_OFFSET                                      18
#define AVR32_ERAY_MRCS_SIZE                                         1
#define AVR32_ERAY_MRC_FDB                                           0
#define AVR32_ERAY_MRC_FDB_MASK                             0x000000ff
#define AVR32_ERAY_MRC_FDB_OFFSET                                    0
#define AVR32_ERAY_MRC_FDB_SIZE                                      8
#define AVR32_ERAY_MRC_FFB                                           8
#define AVR32_ERAY_MRC_FFB_MASK                             0x0000ff00
#define AVR32_ERAY_MRC_FFB_OFFSET                                    8
#define AVR32_ERAY_MRC_FFB_SIZE                                      8
#define AVR32_ERAY_MRC_LCB                                          16
#define AVR32_ERAY_MRC_LCB_MASK                             0x00ff0000
#define AVR32_ERAY_MRC_LCB_OFFSET                                   16
#define AVR32_ERAY_MRC_LCB_SIZE                                      8
#define AVR32_ERAY_MRC_MASK                                 0x07ffffff
#define AVR32_ERAY_MRC_OFFSET                                       16
#define AVR32_ERAY_MRC_RESETVALUE                           0x00000000
#define AVR32_ERAY_MRC_SEC                                          24
#define AVR32_ERAY_MRC_SEC_MASK                             0x03000000
#define AVR32_ERAY_MRC_SEC_OFFSET                                   24
#define AVR32_ERAY_MRC_SEC_SIZE                                      2
#define AVR32_ERAY_MRC_SIZE                                         11
#define AVR32_ERAY_MRC_SPLM                                         26
#define AVR32_ERAY_MRC_SPLM_MASK                            0x04000000
#define AVR32_ERAY_MRC_SPLM_OFFSET                                  26
#define AVR32_ERAY_MRC_SPLM_SIZE                                     1
#define AVR32_ERAY_MSL                                               0
#define AVR32_ERAY_MSL_MASK                                 0x0000003f
#define AVR32_ERAY_MSL_OFFSET                                        0
#define AVR32_ERAY_MSL_SIZE                                          6
#define AVR32_ERAY_MTCCV                                    0x00000114
#define AVR32_ERAY_MTCCV_CCV                                        16
#define AVR32_ERAY_MTCCV_CCV_MASK                           0x003f0000
#define AVR32_ERAY_MTCCV_CCV_OFFSET                                 16
#define AVR32_ERAY_MTCCV_CCV_SIZE                                    6
#define AVR32_ERAY_MTCCV_MASK                               0x003f3fff
#define AVR32_ERAY_MTCCV_MTV                                         0
#define AVR32_ERAY_MTCCV_MTV_MASK                           0x00003fff
#define AVR32_ERAY_MTCCV_MTV_OFFSET                                  0
#define AVR32_ERAY_MTCCV_MTV_SIZE                                   14
#define AVR32_ERAY_MTCCV_RESETVALUE                         0x00000000
#define AVR32_ERAY_MTSAE                                            17
#define AVR32_ERAY_MTSAE_MASK                               0x00020000
#define AVR32_ERAY_MTSAE_OFFSET                                     17
#define AVR32_ERAY_MTSAE_SIZE                                        1
#define AVR32_ERAY_MTSAL                                            17
#define AVR32_ERAY_MTSAL_MASK                               0x00020000
#define AVR32_ERAY_MTSAL_OFFSET                                     17
#define AVR32_ERAY_MTSAL_SIZE                                        1
#define AVR32_ERAY_MTSA_SIZE                                         1
#define AVR32_ERAY_MTSBE                                            25
#define AVR32_ERAY_MTSBE_MASK                               0x02000000
#define AVR32_ERAY_MTSBE_OFFSET                                     25
#define AVR32_ERAY_MTSBE_SIZE                                        1
#define AVR32_ERAY_MTSBL                                            25
#define AVR32_ERAY_MTSBL_MASK                               0x02000000
#define AVR32_ERAY_MTSBL_OFFSET                                     25
#define AVR32_ERAY_MTSBL_SIZE                                        1
#define AVR32_ERAY_MTSB_SIZE                                         1
#define AVR32_ERAY_MTV                                               0
#define AVR32_ERAY_MTV_MASK                                 0x00003fff
#define AVR32_ERAY_MTV_OFFSET                                        0
#define AVR32_ERAY_MTV_SIZE                                         14
#define AVR32_ERAY_ND                                                0
#define AVR32_ERAY_NDAT1                                    0x00000330
#define AVR32_ERAY_NDAT1_MASK                               0xffffffff
#define AVR32_ERAY_NDAT1_ND                                          0
#define AVR32_ERAY_NDAT1_ND_MASK                            0xffffffff
#define AVR32_ERAY_NDAT1_ND_OFFSET                                   0
#define AVR32_ERAY_NDAT1_ND_SIZE                                    32
#define AVR32_ERAY_NDAT1_RESETVALUE                         0x00000000
#define AVR32_ERAY_NDAT2                                    0x00000334
#define AVR32_ERAY_NDAT2_MASK                               0xffffffff
#define AVR32_ERAY_NDAT2_ND                                          0
#define AVR32_ERAY_NDAT2_ND_MASK                            0xffffffff
#define AVR32_ERAY_NDAT2_ND_OFFSET                                   0
#define AVR32_ERAY_NDAT2_ND_SIZE                                    32
#define AVR32_ERAY_NDAT2_RESETVALUE                         0x00000000
#define AVR32_ERAY_NDAT3                                    0x00000338
#define AVR32_ERAY_NDAT3_MASK                               0xffffffff
#define AVR32_ERAY_NDAT3_ND                                          0
#define AVR32_ERAY_NDAT3_ND_MASK                            0xffffffff
#define AVR32_ERAY_NDAT3_ND_OFFSET                                   0
#define AVR32_ERAY_NDAT3_ND_SIZE                                    32
#define AVR32_ERAY_NDAT3_RESETVALUE                         0x00000000
#define AVR32_ERAY_NDAT4                                    0x0000033c
#define AVR32_ERAY_NDAT4_MASK                               0xffffffff
#define AVR32_ERAY_NDAT4_ND                                          0
#define AVR32_ERAY_NDAT4_ND_MASK                            0xffffffff
#define AVR32_ERAY_NDAT4_ND_OFFSET                                   0
#define AVR32_ERAY_NDAT4_ND_SIZE                                    32
#define AVR32_ERAY_NDAT4_RESETVALUE                         0x00000000
#define AVR32_ERAY_ND_MASK                                  0xffffffff
#define AVR32_ERAY_ND_OFFSET                                         0
#define AVR32_ERAY_ND_SIZE                                          32
#define AVR32_ERAY_NEMC                                     0x0000008c
#define AVR32_ERAY_NEMC_MASK                                0x0000000f
#define AVR32_ERAY_NEMC_NML                                          0
#define AVR32_ERAY_NEMC_NML_MASK                            0x0000000f
#define AVR32_ERAY_NEMC_NML_OFFSET                                   0
#define AVR32_ERAY_NEMC_NML_SIZE                                     4
#define AVR32_ERAY_NEMC_RESETVALUE                          0x00000000
#define AVR32_ERAY_NFI                                              27
#define AVR32_ERAY_NFIS                                             27
#define AVR32_ERAY_NFIS_MASK                                0x08000000
#define AVR32_ERAY_NFIS_OFFSET                                      27
#define AVR32_ERAY_NFIS_SIZE                                         1
#define AVR32_ERAY_NFI_MASK                                 0x08000000
#define AVR32_ERAY_NFI_OFFSET                                       27
#define AVR32_ERAY_NFI_SIZE                                          1
#define AVR32_ERAY_NIT                                               0
#define AVR32_ERAY_NIT_MASK                                 0x00003fff
#define AVR32_ERAY_NIT_OFFSET                                        0
#define AVR32_ERAY_NIT_SIZE                                         14
#define AVR32_ERAY_NM                                                0
#define AVR32_ERAY_NML                                               0
#define AVR32_ERAY_NML_MASK                                 0x0000000f
#define AVR32_ERAY_NML_OFFSET                                        0
#define AVR32_ERAY_NML_SIZE                                          4
#define AVR32_ERAY_NMS                                              16
#define AVR32_ERAY_NMS_MASK                                 0x1fff0000
#define AVR32_ERAY_NMS_OFFSET                                       16
#define AVR32_ERAY_NMS_SIZE                                         13
#define AVR32_ERAY_NMV1                                     0x000001b0
#define AVR32_ERAY_NMV1_MASK                                0xffffffff
#define AVR32_ERAY_NMV1_NM                                           0
#define AVR32_ERAY_NMV1_NM_MASK                             0xffffffff
#define AVR32_ERAY_NMV1_NM_OFFSET                                    0
#define AVR32_ERAY_NMV1_NM_SIZE                                     32
#define AVR32_ERAY_NMV1_RESETVALUE                          0x00000000
#define AVR32_ERAY_NMV2                                     0x000001b4
#define AVR32_ERAY_NMV2_MASK                                0xffffffff
#define AVR32_ERAY_NMV2_NM                                           0
#define AVR32_ERAY_NMV2_NM_MASK                             0xffffffff
#define AVR32_ERAY_NMV2_NM_OFFSET                                    0
#define AVR32_ERAY_NMV2_NM_SIZE                                     32
#define AVR32_ERAY_NMV2_RESETVALUE                          0x00000000
#define AVR32_ERAY_NMV3                                     0x000001b8
#define AVR32_ERAY_NMV3_MASK                                0xffffffff
#define AVR32_ERAY_NMV3_NM                                           0
#define AVR32_ERAY_NMV3_NM_MASK                             0xffffffff
#define AVR32_ERAY_NMV3_NM_OFFSET                                    0
#define AVR32_ERAY_NMV3_NM_SIZE                                     32
#define AVR32_ERAY_NMV3_RESETVALUE                          0x00000000
#define AVR32_ERAY_NMVC                                              7
#define AVR32_ERAY_NMVCE                                             7
#define AVR32_ERAY_NMVCE_MASK                               0x00000080
#define AVR32_ERAY_NMVCE_OFFSET                                      7
#define AVR32_ERAY_NMVCE_SIZE                                        1
#define AVR32_ERAY_NMVCL                                             7
#define AVR32_ERAY_NMVCL_MASK                               0x00000080
#define AVR32_ERAY_NMVCL_OFFSET                                      7
#define AVR32_ERAY_NMVCL_SIZE                                        1
#define AVR32_ERAY_NMVC_MASK                                0x00000080
#define AVR32_ERAY_NMVC_OFFSET                                       7
#define AVR32_ERAY_NMVC_SIZE                                         1
#define AVR32_ERAY_NM_MASK                                  0xffffffff
#define AVR32_ERAY_NM_OFFSET                                         0
#define AVR32_ERAY_NM_SIZE                                          32
#define AVR32_ERAY_NSS                                              16
#define AVR32_ERAY_NSS_MASK                                 0x03ff0000
#define AVR32_ERAY_NSS_OFFSET                                       16
#define AVR32_ERAY_NSS_SIZE                                         10
#define AVR32_ERAY_OBCM                                     0x00000710
#define AVR32_ERAY_OBCM_MASK                                0x00030003
#define AVR32_ERAY_OBCM_RDSH                                        17
#define AVR32_ERAY_OBCM_RDSH_MASK                           0x00020000
#define AVR32_ERAY_OBCM_RDSH_OFFSET                                 17
#define AVR32_ERAY_OBCM_RDSH_SIZE                                    1
#define AVR32_ERAY_OBCM_RDSS                                         1
#define AVR32_ERAY_OBCM_RDSS_MASK                           0x00000002
#define AVR32_ERAY_OBCM_RDSS_OFFSET                                  1
#define AVR32_ERAY_OBCM_RDSS_SIZE                                    1
#define AVR32_ERAY_OBCM_RESETVALUE                          0x00000000
#define AVR32_ERAY_OBCM_RHSH                                        16
#define AVR32_ERAY_OBCM_RHSH_MASK                           0x00010000
#define AVR32_ERAY_OBCM_RHSH_OFFSET                                 16
#define AVR32_ERAY_OBCM_RHSH_SIZE                                    1
#define AVR32_ERAY_OBCM_RHSS                                         0
#define AVR32_ERAY_OBCM_RHSS_MASK                           0x00000001
#define AVR32_ERAY_OBCM_RHSS_OFFSET                                  0
#define AVR32_ERAY_OBCM_RHSS_SIZE                                    1
#define AVR32_ERAY_OBCR                                     0x00000714
#define AVR32_ERAY_OBCR_MASK                                0x007f837f
#define AVR32_ERAY_OBCR_OBRH                                        16
#define AVR32_ERAY_OBCR_OBRH_MASK                           0x007f0000
#define AVR32_ERAY_OBCR_OBRH_OFFSET                                 16
#define AVR32_ERAY_OBCR_OBRH_SIZE                                    7
#define AVR32_ERAY_OBCR_OBRS                                         0
#define AVR32_ERAY_OBCR_OBRS_MASK                           0x0000007f
#define AVR32_ERAY_OBCR_OBRS_OFFSET                                  0
#define AVR32_ERAY_OBCR_OBRS_SIZE                                    7
#define AVR32_ERAY_OBCR_OBSYS                                       15
#define AVR32_ERAY_OBCR_OBSYS_MASK                          0x00008000
#define AVR32_ERAY_OBCR_OBSYS_OFFSET                                15
#define AVR32_ERAY_OBCR_OBSYS_SIZE                                   1
#define AVR32_ERAY_OBCR_REQ                                          9
#define AVR32_ERAY_OBCR_REQ_MASK                            0x00000200
#define AVR32_ERAY_OBCR_REQ_OFFSET                                   9
#define AVR32_ERAY_OBCR_REQ_SIZE                                     1
#define AVR32_ERAY_OBCR_RESETVALUE                          0x00000000
#define AVR32_ERAY_OBCR_VIEW                                         8
#define AVR32_ERAY_OBCR_VIEW_MASK                           0x00000100
#define AVR32_ERAY_OBCR_VIEW_OFFSET                                  8
#define AVR32_ERAY_OBCR_VIEW_SIZE                                    1
#define AVR32_ERAY_OBRH                                             16
#define AVR32_ERAY_OBRH_MASK                                0x007f0000
#define AVR32_ERAY_OBRH_OFFSET                                      16
#define AVR32_ERAY_OBRH_SIZE                                         7
#define AVR32_ERAY_OBRS                                              0
#define AVR32_ERAY_OBRS_MASK                                0x0000007f
#define AVR32_ERAY_OBRS_OFFSET                                       0
#define AVR32_ERAY_OBRS_SIZE                                         7
#define AVR32_ERAY_OBSYS                                            15
#define AVR32_ERAY_OBSYS_MASK                               0x00008000
#define AVR32_ERAY_OBSYS_OFFSET                                     15
#define AVR32_ERAY_OBSYS_SIZE                                        1
#define AVR32_ERAY_OCLR                                             17
#define AVR32_ERAY_OCLR_MASK                                0x00020000
#define AVR32_ERAY_OCLR_OFFSET                                      17
#define AVR32_ERAY_OCLR_SIZE                                         1
#define AVR32_ERAY_OCS                                              16
#define AVR32_ERAY_OCS_MASK                                 0x3fff0000
#define AVR32_ERAY_OCS_OFFSET                                       16
#define AVR32_ERAY_OCS_SIZE                                         14
#define AVR32_ERAY_OCV                                      0x0000011c
#define AVR32_ERAY_OCV_MASK                                 0x0007ffff
#define AVR32_ERAY_OCV_OCV                                           0
#define AVR32_ERAY_OCV_OCV_MASK                             0x0007ffff
#define AVR32_ERAY_OCV_OCV_OFFSET                                    0
#define AVR32_ERAY_OCV_OCV_SIZE                                     19
#define AVR32_ERAY_OCV_OFFSET                                        0
#define AVR32_ERAY_OCV_RESETVALUE                           0x00000000
#define AVR32_ERAY_OCV_SIZE                                         19
#define AVR32_ERAY_OID                                               0
#define AVR32_ERAY_OID_MASK                                 0x000003ff
#define AVR32_ERAY_OID_OFFSET                                        0
#define AVR32_ERAY_OID_SIZE                                         10
#define AVR32_ERAY_OR                                       0x00000800
#define AVR32_ERAY_OR_MASK                                  0x00000003
#define AVR32_ERAY_OR_RESETVALUE                            0x00000000
#define AVR32_ERAY_OR_SDIAG1                                         0
#define AVR32_ERAY_OR_SDIAG1_MASK                           0x00000001
#define AVR32_ERAY_OR_SDIAG1_OFFSET                                  0
#define AVR32_ERAY_OR_SDIAG1_SIZE                                    1
#define AVR32_ERAY_OR_SDIAG2                                         1
#define AVR32_ERAY_OR_SDIAG2_MASK                           0x00000002
#define AVR32_ERAY_OR_SDIAG2_OFFSET                                  1
#define AVR32_ERAY_OR_SDIAG2_SIZE                                    1
#define AVR32_ERAY_OSID1                                    0x00000170
#define AVR32_ERAY_OSID10                                   0x00000194
#define AVR32_ERAY_OSID10_MASK                              0x0000c3ff
#define AVR32_ERAY_OSID10_OID                                        0
#define AVR32_ERAY_OSID10_OID_MASK                          0x000003ff
#define AVR32_ERAY_OSID10_OID_OFFSET                                 0
#define AVR32_ERAY_OSID10_OID_SIZE                                  10
#define AVR32_ERAY_OSID10_RESETVALUE                        0x00000000
#define AVR32_ERAY_OSID10_RXOA                                      14
#define AVR32_ERAY_OSID10_RXOA_MASK                         0x00004000
#define AVR32_ERAY_OSID10_RXOA_OFFSET                               14
#define AVR32_ERAY_OSID10_RXOA_SIZE                                  1
#define AVR32_ERAY_OSID10_RXOB                                      15
#define AVR32_ERAY_OSID10_RXOB_MASK                         0x00008000
#define AVR32_ERAY_OSID10_RXOB_OFFSET                               15
#define AVR32_ERAY_OSID10_RXOB_SIZE                                  1
#define AVR32_ERAY_OSID11                                   0x00000198
#define AVR32_ERAY_OSID11_MASK                              0x0000c3ff
#define AVR32_ERAY_OSID11_OID                                        0
#define AVR32_ERAY_OSID11_OID_MASK                          0x000003ff
#define AVR32_ERAY_OSID11_OID_OFFSET                                 0
#define AVR32_ERAY_OSID11_OID_SIZE                                  10
#define AVR32_ERAY_OSID11_RESETVALUE                        0x00000000
#define AVR32_ERAY_OSID11_RXOA                                      14
#define AVR32_ERAY_OSID11_RXOA_MASK                         0x00004000
#define AVR32_ERAY_OSID11_RXOA_OFFSET                               14
#define AVR32_ERAY_OSID11_RXOA_SIZE                                  1
#define AVR32_ERAY_OSID11_RXOB                                      15
#define AVR32_ERAY_OSID11_RXOB_MASK                         0x00008000
#define AVR32_ERAY_OSID11_RXOB_OFFSET                               15
#define AVR32_ERAY_OSID11_RXOB_SIZE                                  1
#define AVR32_ERAY_OSID12                                   0x0000019c
#define AVR32_ERAY_OSID12_MASK                              0x0000c3ff
#define AVR32_ERAY_OSID12_OID                                        0
#define AVR32_ERAY_OSID12_OID_MASK                          0x000003ff
#define AVR32_ERAY_OSID12_OID_OFFSET                                 0
#define AVR32_ERAY_OSID12_OID_SIZE                                  10
#define AVR32_ERAY_OSID12_RESETVALUE                        0x00000000
#define AVR32_ERAY_OSID12_RXOA                                      14
#define AVR32_ERAY_OSID12_RXOA_MASK                         0x00004000
#define AVR32_ERAY_OSID12_RXOA_OFFSET                               14
#define AVR32_ERAY_OSID12_RXOA_SIZE                                  1
#define AVR32_ERAY_OSID12_RXOB                                      15
#define AVR32_ERAY_OSID12_RXOB_MASK                         0x00008000
#define AVR32_ERAY_OSID12_RXOB_OFFSET                               15
#define AVR32_ERAY_OSID12_RXOB_SIZE                                  1
#define AVR32_ERAY_OSID13                                   0x000001a0
#define AVR32_ERAY_OSID13_MASK                              0x0000c3ff
#define AVR32_ERAY_OSID13_OID                                        0
#define AVR32_ERAY_OSID13_OID_MASK                          0x000003ff
#define AVR32_ERAY_OSID13_OID_OFFSET                                 0
#define AVR32_ERAY_OSID13_OID_SIZE                                  10
#define AVR32_ERAY_OSID13_RESETVALUE                        0x00000000
#define AVR32_ERAY_OSID13_RXOA                                      14
#define AVR32_ERAY_OSID13_RXOA_MASK                         0x00004000
#define AVR32_ERAY_OSID13_RXOA_OFFSET                               14
#define AVR32_ERAY_OSID13_RXOA_SIZE                                  1
#define AVR32_ERAY_OSID13_RXOB                                      15
#define AVR32_ERAY_OSID13_RXOB_MASK                         0x00008000
#define AVR32_ERAY_OSID13_RXOB_OFFSET                               15
#define AVR32_ERAY_OSID13_RXOB_SIZE                                  1
#define AVR32_ERAY_OSID14                                   0x000001a4
#define AVR32_ERAY_OSID14_MASK                              0x0000c3ff
#define AVR32_ERAY_OSID14_OID                                        0
#define AVR32_ERAY_OSID14_OID_MASK                          0x000003ff
#define AVR32_ERAY_OSID14_OID_OFFSET                                 0
#define AVR32_ERAY_OSID14_OID_SIZE                                  10
#define AVR32_ERAY_OSID14_RESETVALUE                        0x00000000
#define AVR32_ERAY_OSID14_RXOA                                      14
#define AVR32_ERAY_OSID14_RXOA_MASK                         0x00004000
#define AVR32_ERAY_OSID14_RXOA_OFFSET                               14
#define AVR32_ERAY_OSID14_RXOA_SIZE                                  1
#define AVR32_ERAY_OSID14_RXOB                                      15
#define AVR32_ERAY_OSID14_RXOB_MASK                         0x00008000
#define AVR32_ERAY_OSID14_RXOB_OFFSET                               15
#define AVR32_ERAY_OSID14_RXOB_SIZE                                  1
#define AVR32_ERAY_OSID15                                   0x000001a8
#define AVR32_ERAY_OSID15_MASK                              0x0000c3ff
#define AVR32_ERAY_OSID15_OID                                        0
#define AVR32_ERAY_OSID15_OID_MASK                          0x000003ff
#define AVR32_ERAY_OSID15_OID_OFFSET                                 0
#define AVR32_ERAY_OSID15_OID_SIZE                                  10
#define AVR32_ERAY_OSID15_RESETVALUE                        0x00000000
#define AVR32_ERAY_OSID15_RXOA                                      14
#define AVR32_ERAY_OSID15_RXOA_MASK                         0x00004000
#define AVR32_ERAY_OSID15_RXOA_OFFSET                               14
#define AVR32_ERAY_OSID15_RXOA_SIZE                                  1
#define AVR32_ERAY_OSID15_RXOB                                      15
#define AVR32_ERAY_OSID15_RXOB_MASK                         0x00008000
#define AVR32_ERAY_OSID15_RXOB_OFFSET                               15
#define AVR32_ERAY_OSID15_RXOB_SIZE                                  1
#define AVR32_ERAY_OSID1_MASK                               0x0000c3ff
#define AVR32_ERAY_OSID1_OID                                         0
#define AVR32_ERAY_OSID1_OID_MASK                           0x000003ff
#define AVR32_ERAY_OSID1_OID_OFFSET                                  0
#define AVR32_ERAY_OSID1_OID_SIZE                                   10
#define AVR32_ERAY_OSID1_RESETVALUE                         0x00000000
#define AVR32_ERAY_OSID1_RXOA                                       14
#define AVR32_ERAY_OSID1_RXOA_MASK                          0x00004000
#define AVR32_ERAY_OSID1_RXOA_OFFSET                                14
#define AVR32_ERAY_OSID1_RXOA_SIZE                                   1
#define AVR32_ERAY_OSID1_RXOB                                       15
#define AVR32_ERAY_OSID1_RXOB_MASK                          0x00008000
#define AVR32_ERAY_OSID1_RXOB_OFFSET                                15
#define AVR32_ERAY_OSID1_RXOB_SIZE                                   1
#define AVR32_ERAY_OSID2                                    0x00000174
#define AVR32_ERAY_OSID2_MASK                               0x0000c3ff
#define AVR32_ERAY_OSID2_OID                                         0
#define AVR32_ERAY_OSID2_OID_MASK                           0x000003ff
#define AVR32_ERAY_OSID2_OID_OFFSET                                  0
#define AVR32_ERAY_OSID2_OID_SIZE                                   10
#define AVR32_ERAY_OSID2_RESETVALUE                         0x00000000
#define AVR32_ERAY_OSID2_RXOA                                       14
#define AVR32_ERAY_OSID2_RXOA_MASK                          0x00004000
#define AVR32_ERAY_OSID2_RXOA_OFFSET                                14
#define AVR32_ERAY_OSID2_RXOA_SIZE                                   1
#define AVR32_ERAY_OSID2_RXOB                                       15
#define AVR32_ERAY_OSID2_RXOB_MASK                          0x00008000
#define AVR32_ERAY_OSID2_RXOB_OFFSET                                15
#define AVR32_ERAY_OSID2_RXOB_SIZE                                   1
#define AVR32_ERAY_OSID3                                    0x00000178
#define AVR32_ERAY_OSID3_MASK                               0x0000c3ff
#define AVR32_ERAY_OSID3_OID                                         0
#define AVR32_ERAY_OSID3_OID_MASK                           0x000003ff
#define AVR32_ERAY_OSID3_OID_OFFSET                                  0
#define AVR32_ERAY_OSID3_OID_SIZE                                   10
#define AVR32_ERAY_OSID3_RESETVALUE                         0x00000000
#define AVR32_ERAY_OSID3_RXOA                                       14
#define AVR32_ERAY_OSID3_RXOA_MASK                          0x00004000
#define AVR32_ERAY_OSID3_RXOA_OFFSET                                14
#define AVR32_ERAY_OSID3_RXOA_SIZE                                   1
#define AVR32_ERAY_OSID3_RXOB                                       15
#define AVR32_ERAY_OSID3_RXOB_MASK                          0x00008000
#define AVR32_ERAY_OSID3_RXOB_OFFSET                                15
#define AVR32_ERAY_OSID3_RXOB_SIZE                                   1
#define AVR32_ERAY_OSID4                                    0x0000017c
#define AVR32_ERAY_OSID4_MASK                               0x0000c3ff
#define AVR32_ERAY_OSID4_OID                                         0
#define AVR32_ERAY_OSID4_OID_MASK                           0x000003ff
#define AVR32_ERAY_OSID4_OID_OFFSET                                  0
#define AVR32_ERAY_OSID4_OID_SIZE                                   10
#define AVR32_ERAY_OSID4_RESETVALUE                         0x00000000
#define AVR32_ERAY_OSID4_RXOA                                       14
#define AVR32_ERAY_OSID4_RXOA_MASK                          0x00004000
#define AVR32_ERAY_OSID4_RXOA_OFFSET                                14
#define AVR32_ERAY_OSID4_RXOA_SIZE                                   1
#define AVR32_ERAY_OSID4_RXOB                                       15
#define AVR32_ERAY_OSID4_RXOB_MASK                          0x00008000
#define AVR32_ERAY_OSID4_RXOB_OFFSET                                15
#define AVR32_ERAY_OSID4_RXOB_SIZE                                   1
#define AVR32_ERAY_OSID5                                    0x00000180
#define AVR32_ERAY_OSID5_MASK                               0x0000c3ff
#define AVR32_ERAY_OSID5_OID                                         0
#define AVR32_ERAY_OSID5_OID_MASK                           0x000003ff
#define AVR32_ERAY_OSID5_OID_OFFSET                                  0
#define AVR32_ERAY_OSID5_OID_SIZE                                   10
#define AVR32_ERAY_OSID5_RESETVALUE                         0x00000000
#define AVR32_ERAY_OSID5_RXOA                                       14
#define AVR32_ERAY_OSID5_RXOA_MASK                          0x00004000
#define AVR32_ERAY_OSID5_RXOA_OFFSET                                14
#define AVR32_ERAY_OSID5_RXOA_SIZE                                   1
#define AVR32_ERAY_OSID5_RXOB                                       15
#define AVR32_ERAY_OSID5_RXOB_MASK                          0x00008000
#define AVR32_ERAY_OSID5_RXOB_OFFSET                                15
#define AVR32_ERAY_OSID5_RXOB_SIZE                                   1
#define AVR32_ERAY_OSID6                                    0x00000184
#define AVR32_ERAY_OSID6_MASK                               0x0000c3ff
#define AVR32_ERAY_OSID6_OID                                         0
#define AVR32_ERAY_OSID6_OID_MASK                           0x000003ff
#define AVR32_ERAY_OSID6_OID_OFFSET                                  0
#define AVR32_ERAY_OSID6_OID_SIZE                                   10
#define AVR32_ERAY_OSID6_RESETVALUE                         0x00000000
#define AVR32_ERAY_OSID6_RXOA                                       14
#define AVR32_ERAY_OSID6_RXOA_MASK                          0x00004000
#define AVR32_ERAY_OSID6_RXOA_OFFSET                                14
#define AVR32_ERAY_OSID6_RXOA_SIZE                                   1
#define AVR32_ERAY_OSID6_RXOB                                       15
#define AVR32_ERAY_OSID6_RXOB_MASK                          0x00008000
#define AVR32_ERAY_OSID6_RXOB_OFFSET                                15
#define AVR32_ERAY_OSID6_RXOB_SIZE                                   1
#define AVR32_ERAY_OSID7                                    0x00000188
#define AVR32_ERAY_OSID7_MASK                               0x0000c3ff
#define AVR32_ERAY_OSID7_OID                                         0
#define AVR32_ERAY_OSID7_OID_MASK                           0x000003ff
#define AVR32_ERAY_OSID7_OID_OFFSET                                  0
#define AVR32_ERAY_OSID7_OID_SIZE                                   10
#define AVR32_ERAY_OSID7_RESETVALUE                         0x00000000
#define AVR32_ERAY_OSID7_RXOA                                       14
#define AVR32_ERAY_OSID7_RXOA_MASK                          0x00004000
#define AVR32_ERAY_OSID7_RXOA_OFFSET                                14
#define AVR32_ERAY_OSID7_RXOA_SIZE                                   1
#define AVR32_ERAY_OSID7_RXOB                                       15
#define AVR32_ERAY_OSID7_RXOB_MASK                          0x00008000
#define AVR32_ERAY_OSID7_RXOB_OFFSET                                15
#define AVR32_ERAY_OSID7_RXOB_SIZE                                   1
#define AVR32_ERAY_OSID8                                    0x0000018c
#define AVR32_ERAY_OSID8_MASK                               0x0000c3ff
#define AVR32_ERAY_OSID8_OID                                         0
#define AVR32_ERAY_OSID8_OID_MASK                           0x000003ff
#define AVR32_ERAY_OSID8_OID_OFFSET                                  0
#define AVR32_ERAY_OSID8_OID_SIZE                                   10
#define AVR32_ERAY_OSID8_RESETVALUE                         0x00000000
#define AVR32_ERAY_OSID8_RXOA                                       14
#define AVR32_ERAY_OSID8_RXOA_MASK                          0x00004000
#define AVR32_ERAY_OSID8_RXOA_OFFSET                                14
#define AVR32_ERAY_OSID8_RXOA_SIZE                                   1
#define AVR32_ERAY_OSID8_RXOB                                       15
#define AVR32_ERAY_OSID8_RXOB_MASK                          0x00008000
#define AVR32_ERAY_OSID8_RXOB_OFFSET                                15
#define AVR32_ERAY_OSID8_RXOB_SIZE                                   1
#define AVR32_ERAY_OSID9                                    0x00000190
#define AVR32_ERAY_OSID9_MASK                               0x0000c3ff
#define AVR32_ERAY_OSID9_OID                                         0
#define AVR32_ERAY_OSID9_OID_MASK                           0x000003ff
#define AVR32_ERAY_OSID9_OID_OFFSET                                  0
#define AVR32_ERAY_OSID9_OID_SIZE                                   10
#define AVR32_ERAY_OSID9_RESETVALUE                         0x00000000
#define AVR32_ERAY_OSID9_RXOA                                       14
#define AVR32_ERAY_OSID9_RXOA_MASK                          0x00004000
#define AVR32_ERAY_OSID9_RXOA_OFFSET                                14
#define AVR32_ERAY_OSID9_RXOA_SIZE                                   1
#define AVR32_ERAY_OSID9_RXOB                                       15
#define AVR32_ERAY_OSID9_RXOB_MASK                          0x00008000
#define AVR32_ERAY_OSID9_RXOB_OFFSET                                15
#define AVR32_ERAY_OSID9_RXOB_SIZE                                   1
#define AVR32_ERAY_OVR                                      0x00000808
#define AVR32_ERAY_OVR_EN1                                           0
#define AVR32_ERAY_OVR_EN1_MASK                             0x00000001
#define AVR32_ERAY_OVR_EN1_OFFSET                                    0
#define AVR32_ERAY_OVR_EN1_SIZE                                      1
#define AVR32_ERAY_OVR_EN2                                           1
#define AVR32_ERAY_OVR_EN2_MASK                             0x00000002
#define AVR32_ERAY_OVR_EN2_OFFSET                                    1
#define AVR32_ERAY_OVR_EN2_SIZE                                      1
#define AVR32_ERAY_OVR_MASK                                 0x00000003
#define AVR32_ERAY_OVR_RESETVALUE                           0x00000000
#define AVR32_ERAY_PBSY                                              7
#define AVR32_ERAY_PBSY_MASK                                0x00000080
#define AVR32_ERAY_PBSY_OFFSET                                       7
#define AVR32_ERAY_PBSY_SIZE                                         1
#define AVR32_ERAY_PEMC                                              0
#define AVR32_ERAY_PEMCE                                             0
#define AVR32_ERAY_PEMCE_MASK                               0x00000001
#define AVR32_ERAY_PEMCE_OFFSET                                      0
#define AVR32_ERAY_PEMCE_SIZE                                        1
#define AVR32_ERAY_PEMCL                                             0
#define AVR32_ERAY_PEMCL_MASK                               0x00000001
#define AVR32_ERAY_PEMCL_OFFSET                                      0
#define AVR32_ERAY_PEMCL_SIZE                                        1
#define AVR32_ERAY_PEMC_MASK                                0x00000001
#define AVR32_ERAY_PEMC_OFFSET                                       0
#define AVR32_ERAY_PEMC_SIZE                                         1
#define AVR32_ERAY_PERR                                              6
#define AVR32_ERAY_PERRE                                             6
#define AVR32_ERAY_PERRE_MASK                               0x00000040
#define AVR32_ERAY_PERRE_OFFSET                                      6
#define AVR32_ERAY_PERRE_SIZE                                        1
#define AVR32_ERAY_PERRL                                             6
#define AVR32_ERAY_PERRL_MASK                               0x00000040
#define AVR32_ERAY_PERRL_OFFSET                                      6
#define AVR32_ERAY_PERRL_SIZE                                        1
#define AVR32_ERAY_PERR_MASK                                0x00000040
#define AVR32_ERAY_PERR_OFFSET                                       6
#define AVR32_ERAY_PERR_SIZE                                         1
#define AVR32_ERAY_PIBF                                              0
#define AVR32_ERAY_PIBF_MASK                                0x00000001
#define AVR32_ERAY_PIBF_OFFSET                                       0
#define AVR32_ERAY_PIBF_SIZE                                         1
#define AVR32_ERAY_PLC                                              16
#define AVR32_ERAY_PLC_MASK                                 0x007f0000
#define AVR32_ERAY_PLC_OFFSET                                       16
#define AVR32_ERAY_PLC_SIZE                                          7
#define AVR32_ERAY_PLR                                              24
#define AVR32_ERAY_PLR_MASK                                 0x7f000000
#define AVR32_ERAY_PLR_OFFSET                                       24
#define AVR32_ERAY_PLR_SIZE                                          7
#define AVR32_ERAY_PMR                                               2
#define AVR32_ERAY_PMR_MASK                                 0x00000004
#define AVR32_ERAY_PMR_OFFSET                                        2
#define AVR32_ERAY_PMR_SIZE                                          1
#define AVR32_ERAY_POBF                                              1
#define AVR32_ERAY_POBF_MASK                                0x00000002
#define AVR32_ERAY_POBF_OFFSET                                       1
#define AVR32_ERAY_POBF_SIZE                                         1
#define AVR32_ERAY_POCS                                              0
#define AVR32_ERAY_POCS_MASK                                0x0000003f
#define AVR32_ERAY_POCS_OFFSET                                       0
#define AVR32_ERAY_POCS_SIZE                                         6
#define AVR32_ERAY_PPI                                              28
#define AVR32_ERAY_PPIS                                             28
#define AVR32_ERAY_PPIS_MASK                                0x10000000
#define AVR32_ERAY_PPIS_OFFSET                                      28
#define AVR32_ERAY_PPIS_SIZE                                         1
#define AVR32_ERAY_PPIT                                             27
#define AVR32_ERAY_PPIT_MASK                                0x08000000
#define AVR32_ERAY_PPIT_OFFSET                                      27
#define AVR32_ERAY_PPIT_SIZE                                         1
#define AVR32_ERAY_PPI_MASK                                 0x10000000
#define AVR32_ERAY_PPI_OFFSET                                       28
#define AVR32_ERAY_PPI_SIZE                                          1
#define AVR32_ERAY_PRTC1                                    0x00000090
#define AVR32_ERAY_PRTC1_BRP                                        14
#define AVR32_ERAY_PRTC1_BRP_MASK                           0x0000c000
#define AVR32_ERAY_PRTC1_BRP_OFFSET                                 14
#define AVR32_ERAY_PRTC1_BRP_SIZE                                    2
#define AVR32_ERAY_PRTC1_CASM                                        4
#define AVR32_ERAY_PRTC1_CASM_MASK                          0x000007f0
#define AVR32_ERAY_PRTC1_CASM_OFFSET                                 4
#define AVR32_ERAY_PRTC1_CASM_SIZE                                   7
#define AVR32_ERAY_PRTC1_MASK                               0xfdfff7ff
#define AVR32_ERAY_PRTC1_RESETVALUE                         0x00000000
#define AVR32_ERAY_PRTC1_RWP                                        26
#define AVR32_ERAY_PRTC1_RWP_MASK                           0xfc000000
#define AVR32_ERAY_PRTC1_RWP_OFFSET                                 26
#define AVR32_ERAY_PRTC1_RWP_SIZE                                    6
#define AVR32_ERAY_PRTC1_RXW                                        16
#define AVR32_ERAY_PRTC1_RXW_MASK                           0x01ff0000
#define AVR32_ERAY_PRTC1_RXW_OFFSET                                 16
#define AVR32_ERAY_PRTC1_RXW_SIZE                                    9
#define AVR32_ERAY_PRTC1_SPP                                        12
#define AVR32_ERAY_PRTC1_SPP_MASK                           0x00003000
#define AVR32_ERAY_PRTC1_SPP_OFFSET                                 12
#define AVR32_ERAY_PRTC1_SPP_SIZE                                    2
#define AVR32_ERAY_PRTC1_TSST                                        0
#define AVR32_ERAY_PRTC1_TSST_MASK                          0x0000000f
#define AVR32_ERAY_PRTC1_TSST_OFFSET                                 0
#define AVR32_ERAY_PRTC1_TSST_SIZE                                   4
#define AVR32_ERAY_PRTC2                                    0x00000094
#define AVR32_ERAY_PRTC2_MASK                               0x3fff3f3f
#define AVR32_ERAY_PRTC2_RESETVALUE                         0x00000000
#define AVR32_ERAY_PRTC2_RXI                                         0
#define AVR32_ERAY_PRTC2_RXI_MASK                           0x0000003f
#define AVR32_ERAY_PRTC2_RXI_OFFSET                                  0
#define AVR32_ERAY_PRTC2_RXI_SIZE                                    6
#define AVR32_ERAY_PRTC2_RXL                                         8
#define AVR32_ERAY_PRTC2_RXL_MASK                           0x00003f00
#define AVR32_ERAY_PRTC2_RXL_OFFSET                                  8
#define AVR32_ERAY_PRTC2_RXL_SIZE                                    6
#define AVR32_ERAY_PRTC2_TXI                                        16
#define AVR32_ERAY_PRTC2_TXI_MASK                           0x00ff0000
#define AVR32_ERAY_PRTC2_TXI_OFFSET                                 16
#define AVR32_ERAY_PRTC2_TXI_SIZE                                    8
#define AVR32_ERAY_PRTC2_TXL                                        24
#define AVR32_ERAY_PRTC2_TXL_MASK                           0x3f000000
#define AVR32_ERAY_PRTC2_TXL_OFFSET                                 24
#define AVR32_ERAY_PRTC2_TXL_SIZE                                    6
#define AVR32_ERAY_PSL                                              24
#define AVR32_ERAY_PSL_MASK                                 0x3f000000
#define AVR32_ERAY_PSL_OFFSET                                       24
#define AVR32_ERAY_PSL_SIZE                                          6
#define AVR32_ERAY_PTA                                              16
#define AVR32_ERAY_PTAC                                              8
#define AVR32_ERAY_PTAC_MASK                                0x00001f00
#define AVR32_ERAY_PTAC_OFFSET                                       8
#define AVR32_ERAY_PTAC_SIZE                                         5
#define AVR32_ERAY_PTA_MASK                                 0x001f0000
#define AVR32_ERAY_PTA_OFFSET                                       16
#define AVR32_ERAY_PTA_SIZE                                          5
#define AVR32_ERAY_PTBF1                                             3
#define AVR32_ERAY_PTBF1_MASK                               0x00000008
#define AVR32_ERAY_PTBF1_OFFSET                                      3
#define AVR32_ERAY_PTBF1_SIZE                                        1
#define AVR32_ERAY_PTBF2                                             4
#define AVR32_ERAY_PTBF2_MASK                               0x00000010
#define AVR32_ERAY_PTBF2_OFFSET                                      4
#define AVR32_ERAY_PTBF2_SIZE                                        1
#define AVR32_ERAY_RCA                                              19
#define AVR32_ERAY_RCA_MASK                                 0x00f80000
#define AVR32_ERAY_RCA_OFFSET                                       19
#define AVR32_ERAY_RCA_SIZE                                          5
#define AVR32_ERAY_RCC                                              16
#define AVR32_ERAY_RCC_MASK                                 0x003f0000
#define AVR32_ERAY_RCC_OFFSET                                       16
#define AVR32_ERAY_RCC_SIZE                                          6
#define AVR32_ERAY_RCI                                              24
#define AVR32_ERAY_RCIS                                             24
#define AVR32_ERAY_RCIS_MASK                                0x01000000
#define AVR32_ERAY_RCIS_OFFSET                                      24
#define AVR32_ERAY_RCIS_SIZE                                         1
#define AVR32_ERAY_RCI_MASK                                 0x01000000
#define AVR32_ERAY_RCI_OFFSET                                       24
#define AVR32_ERAY_RCI_SIZE                                          1
#define AVR32_ERAY_RCLR                                             19
#define AVR32_ERAY_RCLR_MASK                                0x00080000
#define AVR32_ERAY_RCLR_OFFSET                                      19
#define AVR32_ERAY_RCLR_SIZE                                         1
#define AVR32_ERAY_RCV                                      0x00000118
#define AVR32_ERAY_RCV_MASK                                 0x00000fff
#define AVR32_ERAY_RCV_OFFSET                                        0
#define AVR32_ERAY_RCV_RCV                                           0
#define AVR32_ERAY_RCV_RCV_MASK                             0x00000fff
#define AVR32_ERAY_RCV_RCV_OFFSET                                    0
#define AVR32_ERAY_RCV_RCV_SIZE                                     12
#define AVR32_ERAY_RCV_RESETVALUE                           0x00000000
#define AVR32_ERAY_RCV_SIZE                                         12
#define AVR32_ERAY_RDDS                                     0x00000600
#define AVR32_ERAY_RDDS_MASK                                0x00000000
#define AVR32_ERAY_RDDS_RESETVALUE                          0x00000000
#define AVR32_ERAY_RDHS1                                    0x00000700
#define AVR32_ERAY_RDHS1_CFG                                        26
#define AVR32_ERAY_RDHS1_CFG_MASK                           0x04000000
#define AVR32_ERAY_RDHS1_CFG_OFFSET                                 26
#define AVR32_ERAY_RDHS1_CFG_SIZE                                    1
#define AVR32_ERAY_RDHS1_CHA                                        24
#define AVR32_ERAY_RDHS1_CHA_MASK                           0x01000000
#define AVR32_ERAY_RDHS1_CHA_OFFSET                                 24
#define AVR32_ERAY_RDHS1_CHA_SIZE                                    1
#define AVR32_ERAY_RDHS1_CHB                                        25
#define AVR32_ERAY_RDHS1_CHB_MASK                           0x02000000
#define AVR32_ERAY_RDHS1_CHB_OFFSET                                 25
#define AVR32_ERAY_RDHS1_CHB_SIZE                                    1
#define AVR32_ERAY_RDHS1_CYC                                        16
#define AVR32_ERAY_RDHS1_CYC_MASK                           0x007f0000
#define AVR32_ERAY_RDHS1_CYC_OFFSET                                 16
#define AVR32_ERAY_RDHS1_CYC_SIZE                                    7
#define AVR32_ERAY_RDHS1_FID                                         0
#define AVR32_ERAY_RDHS1_FID_MASK                           0x000007ff
#define AVR32_ERAY_RDHS1_FID_OFFSET                                  0
#define AVR32_ERAY_RDHS1_FID_SIZE                                   11
#define AVR32_ERAY_RDHS1_MASK                               0x3f7f07ff
#define AVR32_ERAY_RDHS1_MBI                                        29
#define AVR32_ERAY_RDHS1_MBI_MASK                           0x20000000
#define AVR32_ERAY_RDHS1_MBI_OFFSET                                 29
#define AVR32_ERAY_RDHS1_MBI_SIZE                                    1
#define AVR32_ERAY_RDHS1_PPIT                                       27
#define AVR32_ERAY_RDHS1_PPIT_MASK                          0x08000000
#define AVR32_ERAY_RDHS1_PPIT_OFFSET                                27
#define AVR32_ERAY_RDHS1_PPIT_SIZE                                   1
#define AVR32_ERAY_RDHS1_RESETVALUE                         0x00000000
#define AVR32_ERAY_RDHS1_TXM                                        28
#define AVR32_ERAY_RDHS1_TXM_MASK                           0x10000000
#define AVR32_ERAY_RDHS1_TXM_OFFSET                                 28
#define AVR32_ERAY_RDHS1_TXM_SIZE                                    1
#define AVR32_ERAY_RDHS2                                    0x00000704
#define AVR32_ERAY_RDHS2_CRC                                         0
#define AVR32_ERAY_RDHS2_CRC_MASK                           0x000007ff
#define AVR32_ERAY_RDHS2_CRC_OFFSET                                  0
#define AVR32_ERAY_RDHS2_CRC_SIZE                                   11
#define AVR32_ERAY_RDHS2_MASK                               0x7f7f07ff
#define AVR32_ERAY_RDHS2_PLC                                        16
#define AVR32_ERAY_RDHS2_PLC_MASK                           0x007f0000
#define AVR32_ERAY_RDHS2_PLC_OFFSET                                 16
#define AVR32_ERAY_RDHS2_PLC_SIZE                                    7
#define AVR32_ERAY_RDHS2_PLR                                        24
#define AVR32_ERAY_RDHS2_PLR_MASK                           0x7f000000
#define AVR32_ERAY_RDHS2_PLR_OFFSET                                 24
#define AVR32_ERAY_RDHS2_PLR_SIZE                                    7
#define AVR32_ERAY_RDHS2_RESETVALUE                         0x00000000
#define AVR32_ERAY_RDHS3                                    0x00000708
#define AVR32_ERAY_RDHS3_DP                                          0
#define AVR32_ERAY_RDHS3_DP_MASK                            0x000007ff
#define AVR32_ERAY_RDHS3_DP_OFFSET                                   0
#define AVR32_ERAY_RDHS3_DP_SIZE                                    11
#define AVR32_ERAY_RDHS3_MASK                               0x3f3f07ff
#define AVR32_ERAY_RDHS3_NFI                                        27
#define AVR32_ERAY_RDHS3_NFI_MASK                           0x08000000
#define AVR32_ERAY_RDHS3_NFI_OFFSET                                 27
#define AVR32_ERAY_RDHS3_NFI_SIZE                                    1
#define AVR32_ERAY_RDHS3_PPI                                        28
#define AVR32_ERAY_RDHS3_PPI_MASK                           0x10000000
#define AVR32_ERAY_RDHS3_PPI_OFFSET                                 28
#define AVR32_ERAY_RDHS3_PPI_SIZE                                    1
#define AVR32_ERAY_RDHS3_RCC                                        16
#define AVR32_ERAY_RDHS3_RCC_MASK                           0x003f0000
#define AVR32_ERAY_RDHS3_RCC_OFFSET                                 16
#define AVR32_ERAY_RDHS3_RCC_SIZE                                    6
#define AVR32_ERAY_RDHS3_RCI                                        24
#define AVR32_ERAY_RDHS3_RCI_MASK                           0x01000000
#define AVR32_ERAY_RDHS3_RCI_OFFSET                                 24
#define AVR32_ERAY_RDHS3_RCI_SIZE                                    1
#define AVR32_ERAY_RDHS3_RES                                        29
#define AVR32_ERAY_RDHS3_RESETVALUE                         0x00000000
#define AVR32_ERAY_RDHS3_RES_MASK                           0x20000000
#define AVR32_ERAY_RDHS3_RES_OFFSET                                 29
#define AVR32_ERAY_RDHS3_RES_SIZE                                    1
#define AVR32_ERAY_RDHS3_SFI                                        25
#define AVR32_ERAY_RDHS3_SFI_MASK                           0x02000000
#define AVR32_ERAY_RDHS3_SFI_OFFSET                                 25
#define AVR32_ERAY_RDHS3_SFI_SIZE                                    1
#define AVR32_ERAY_RDHS3_SYN                                        26
#define AVR32_ERAY_RDHS3_SYN_MASK                           0x04000000
#define AVR32_ERAY_RDHS3_SYN_OFFSET                                 26
#define AVR32_ERAY_RDHS3_SYN_SIZE                                    1
#define AVR32_ERAY_RDPB                                             15
#define AVR32_ERAY_RDPB_MASK                                0x00008000
#define AVR32_ERAY_RDPB_OFFSET                                      15
#define AVR32_ERAY_RDPB_SIZE                                         1
#define AVR32_ERAY_RDSH                                             17
#define AVR32_ERAY_RDSH_MASK                                0x00020000
#define AVR32_ERAY_RDSH_OFFSET                                      17
#define AVR32_ERAY_RDSH_SIZE                                         1
#define AVR32_ERAY_RDSS                                              1
#define AVR32_ERAY_RDSS_MASK                                0x00000002
#define AVR32_ERAY_RDSS_OFFSET                                       1
#define AVR32_ERAY_RDSS_SIZE                                         1
#define AVR32_ERAY_REL                                              28
#define AVR32_ERAY_REL_MASK                                 0xf0000000
#define AVR32_ERAY_REL_OFFSET                                       28
#define AVR32_ERAY_REL_SIZE                                          4
#define AVR32_ERAY_REQ                                               9
#define AVR32_ERAY_REQ_MASK                                 0x00000200
#define AVR32_ERAY_REQ_OFFSET                                        9
#define AVR32_ERAY_REQ_SIZE                                          1
#define AVR32_ERAY_RES                                              29
#define AVR32_ERAY_RESS                                             29
#define AVR32_ERAY_RESS_MASK                                0x20000000
#define AVR32_ERAY_RESS_OFFSET                                      29
#define AVR32_ERAY_RESS_SIZE                                         1
#define AVR32_ERAY_RES_MASK                                 0x20000000
#define AVR32_ERAY_RES_OFFSET                                       29
#define AVR32_ERAY_RES_SIZE                                          1
#define AVR32_ERAY_RFCLE                                             6
#define AVR32_ERAY_RFCLE_MASK                               0x00000040
#define AVR32_ERAY_RFCLE_OFFSET                                      6
#define AVR32_ERAY_RFCLE_SIZE                                        1
#define AVR32_ERAY_RFCLL                                             6
#define AVR32_ERAY_RFCLL_MASK                               0x00000040
#define AVR32_ERAY_RFCLL_OFFSET                                      6
#define AVR32_ERAY_RFCLL_SIZE                                        1
#define AVR32_ERAY_RFCL_SIZE                                         1
#define AVR32_ERAY_RFFL                                              8
#define AVR32_ERAY_RFFL_MASK                                0x0000ff00
#define AVR32_ERAY_RFFL_OFFSET                                       8
#define AVR32_ERAY_RFFL_SIZE                                         8
#define AVR32_ERAY_RFNEE                                             5
#define AVR32_ERAY_RFNEE_MASK                               0x00000020
#define AVR32_ERAY_RFNEE_OFFSET                                      5
#define AVR32_ERAY_RFNEE_SIZE                                        1
#define AVR32_ERAY_RFNEL                                             5
#define AVR32_ERAY_RFNEL_MASK                               0x00000020
#define AVR32_ERAY_RFNEL_OFFSET                                      5
#define AVR32_ERAY_RFNEL_SIZE                                        1
#define AVR32_ERAY_RFNE_SIZE                                         1
#define AVR32_ERAY_RFOE                                              7
#define AVR32_ERAY_RFOE_MASK                                0x00000080
#define AVR32_ERAY_RFOE_OFFSET                                       7
#define AVR32_ERAY_RFOE_SIZE                                         1
#define AVR32_ERAY_RFOL                                              7
#define AVR32_ERAY_RFOL_MASK                                0x00000080
#define AVR32_ERAY_RFOL_OFFSET                                       7
#define AVR32_ERAY_RFOL_SIZE                                         1
#define AVR32_ERAY_RFO_SIZE                                          1
#define AVR32_ERAY_RHSH                                             16
#define AVR32_ERAY_RHSH_MASK                                0x00010000
#define AVR32_ERAY_RHSH_OFFSET                                      16
#define AVR32_ERAY_RHSH_SIZE                                         1
#define AVR32_ERAY_RHSS                                              0
#define AVR32_ERAY_RHSS_MASK                                0x00000001
#define AVR32_ERAY_RHSS_OFFSET                                       0
#define AVR32_ERAY_RHSS_SIZE                                         1
#define AVR32_ERAY_RNF                                              24
#define AVR32_ERAY_RNF_MASK                                 0x01000000
#define AVR32_ERAY_RNF_OFFSET                                       24
#define AVR32_ERAY_RNF_SIZE                                          1
#define AVR32_ERAY_RS                                                0
#define AVR32_ERAY_RSS                                              23
#define AVR32_ERAY_RSS_MASK                                 0x00800000
#define AVR32_ERAY_RSS_OFFSET                                       23
#define AVR32_ERAY_RSS_SIZE                                          1
#define AVR32_ERAY_RS_MASK                                  0x00000007
#define AVR32_ERAY_RS_OFFSET                                         0
#define AVR32_ERAY_RS_SIZE                                           3
#define AVR32_ERAY_RWP                                              26
#define AVR32_ERAY_RWP_MASK                                 0xfc000000
#define AVR32_ERAY_RWP_OFFSET                                       26
#define AVR32_ERAY_RWP_SIZE                                          6
#define AVR32_ERAY_RXA                                              16
#define AVR32_ERAY_RXA_MASK                                 0x00010000
#define AVR32_ERAY_RXA_OFFSET                                       16
#define AVR32_ERAY_RXA_SIZE                                          1
#define AVR32_ERAY_RXB                                              17
#define AVR32_ERAY_RXB_MASK                                 0x00020000
#define AVR32_ERAY_RXB_OFFSET                                       17
#define AVR32_ERAY_RXB_SIZE                                          1
#define AVR32_ERAY_RXEA                                             14
#define AVR32_ERAY_RXEA_MASK                                0x00004000
#define AVR32_ERAY_RXEA_OFFSET                                      14
#define AVR32_ERAY_RXEA_SIZE                                         1
#define AVR32_ERAY_RXEB                                             15
#define AVR32_ERAY_RXEB_MASK                                0x00008000
#define AVR32_ERAY_RXEB_OFFSET                                      15
#define AVR32_ERAY_RXEB_SIZE                                         1
#define AVR32_ERAY_RXIE                                              4
#define AVR32_ERAY_RXIE_MASK                                0x00000010
#define AVR32_ERAY_RXIE_OFFSET                                       4
#define AVR32_ERAY_RXIE_SIZE                                         1
#define AVR32_ERAY_RXIL                                              4
#define AVR32_ERAY_RXIL_MASK                                0x00000010
#define AVR32_ERAY_RXIL_OFFSET                                       4
#define AVR32_ERAY_RXIL_SIZE                                         1
#define AVR32_ERAY_RXL                                               8
#define AVR32_ERAY_RXL_MASK                                 0x00003f00
#define AVR32_ERAY_RXL_OFFSET                                        8
#define AVR32_ERAY_RXL_SIZE                                          6
#define AVR32_ERAY_RXOA                                             14
#define AVR32_ERAY_RXOA_MASK                                0x00004000
#define AVR32_ERAY_RXOA_OFFSET                                      14
#define AVR32_ERAY_RXOA_SIZE                                         1
#define AVR32_ERAY_RXOB                                             15
#define AVR32_ERAY_RXOB_MASK                                0x00008000
#define AVR32_ERAY_RXOB_OFFSET                                      15
#define AVR32_ERAY_RXOB_SIZE                                         1
#define AVR32_ERAY_RXW                                              16
#define AVR32_ERAY_RXW_MASK                                 0x01ff0000
#define AVR32_ERAY_RXW_OFFSET                                       16
#define AVR32_ERAY_RXW_SIZE                                          9
#define AVR32_ERAY_SA1                                               0
#define AVR32_ERAY_SA1_MASK                                 0x00000001
#define AVR32_ERAY_SA1_OFFSET                                        0
#define AVR32_ERAY_SA1_SIZE                                          1
#define AVR32_ERAY_SA2                                               1
#define AVR32_ERAY_SA2_MASK                                 0x00000002
#define AVR32_ERAY_SA2_OFFSET                                        1
#define AVR32_ERAY_SA2_SIZE                                          1
#define AVR32_ERAY_SAIM1                                             0
#define AVR32_ERAY_SAIM1_MASK                               0x00000001
#define AVR32_ERAY_SAIM1_OFFSET                                      0
#define AVR32_ERAY_SAIM1_SIZE                                        1
#define AVR32_ERAY_SAIM2                                             1
#define AVR32_ERAY_SAIM2_MASK                               0x00000002
#define AVR32_ERAY_SAIM2_OFFSET                                      1
#define AVR32_ERAY_SAIM2_SIZE                                        1
#define AVR32_ERAY_SBNA                                              9
#define AVR32_ERAY_SBNA_MASK                                0x00000200
#define AVR32_ERAY_SBNA_OFFSET                                       9
#define AVR32_ERAY_SBNA_SIZE                                         1
#define AVR32_ERAY_SBNB                                             11
#define AVR32_ERAY_SBNB_MASK                                0x00000800
#define AVR32_ERAY_SBNB_OFFSET                                      11
#define AVR32_ERAY_SBNB_SIZE                                         1
#define AVR32_ERAY_SBSA                                              1
#define AVR32_ERAY_SBSA_MASK                                0x00000002
#define AVR32_ERAY_SBSA_OFFSET                                       1
#define AVR32_ERAY_SBSA_SIZE                                         1
#define AVR32_ERAY_SBSB                                              4
#define AVR32_ERAY_SBSB_MASK                                0x00000010
#define AVR32_ERAY_SBSB_OFFSET                                       4
#define AVR32_ERAY_SBSB_SIZE                                         1
#define AVR32_ERAY_SBVA                                              4
#define AVR32_ERAY_SBVA_MASK                                0x00000010
#define AVR32_ERAY_SBVA_OFFSET                                       4
#define AVR32_ERAY_SBVA_SIZE                                         1
#define AVR32_ERAY_SBVB                                             12
#define AVR32_ERAY_SBVB_MASK                                0x00001000
#define AVR32_ERAY_SBVB_OFFSET                                      12
#define AVR32_ERAY_SBVB_SIZE                                         1
#define AVR32_ERAY_SCCA                                              0
#define AVR32_ERAY_SCCA_MASK                                0x000007ff
#define AVR32_ERAY_SCCA_OFFSET                                       0
#define AVR32_ERAY_SCCA_SIZE                                        11
#define AVR32_ERAY_SCCB                                             16
#define AVR32_ERAY_SCCB_MASK                                0x07ff0000
#define AVR32_ERAY_SCCB_OFFSET                                      16
#define AVR32_ERAY_SCCB_SIZE                                        11
#define AVR32_ERAY_SCCV                                              8
#define AVR32_ERAY_SCCV_MASK                                0x00003f00
#define AVR32_ERAY_SCCV_OFFSET                                       8
#define AVR32_ERAY_SCCV_SIZE                                         6
#define AVR32_ERAY_SCR                                      0x00000814
#define AVR32_ERAY_SCR_MASK                                 0x00000003
#define AVR32_ERAY_SCR_RESETVALUE                           0x00000000
#define AVR32_ERAY_SCR_SA1                                           0
#define AVR32_ERAY_SCR_SA1_MASK                             0x00000001
#define AVR32_ERAY_SCR_SA1_OFFSET                                    0
#define AVR32_ERAY_SCR_SA1_SIZE                                      1
#define AVR32_ERAY_SCR_SA2                                           1
#define AVR32_ERAY_SCR_SA2_MASK                             0x00000002
#define AVR32_ERAY_SCR_SA2_OFFSET                                    1
#define AVR32_ERAY_SCR_SA2_SIZE                                      1
#define AVR32_ERAY_SCV                                      0x00000110
#define AVR32_ERAY_SCV_MASK                                 0x07ff07ff
#define AVR32_ERAY_SCV_RESETVALUE                           0x00000000
#define AVR32_ERAY_SCV_SCCA                                          0
#define AVR32_ERAY_SCV_SCCA_MASK                            0x000007ff
#define AVR32_ERAY_SCV_SCCA_OFFSET                                   0
#define AVR32_ERAY_SCV_SCCA_SIZE                                    11
#define AVR32_ERAY_SCV_SCCB                                         16
#define AVR32_ERAY_SCV_SCCB_MASK                            0x07ff0000
#define AVR32_ERAY_SCV_SCCB_OFFSET                                  16
#define AVR32_ERAY_SCV_SCCB_SIZE                                    11
#define AVR32_ERAY_SDIAG1                                            0
#define AVR32_ERAY_SDIAG1_MASK                              0x00000001
#define AVR32_ERAY_SDIAG1_OFFSET                                     0
#define AVR32_ERAY_SDIAG1_SIZE                                       1
#define AVR32_ERAY_SDIAG2                                            1
#define AVR32_ERAY_SDIAG2_MASK                              0x00000002
#define AVR32_ERAY_SDIAG2_OFFSET                                     1
#define AVR32_ERAY_SDIAG2_SIZE                                       1
#define AVR32_ERAY_SDS                                              15
#define AVR32_ERAY_SDSE                                             15
#define AVR32_ERAY_SDSE_MASK                                0x00008000
#define AVR32_ERAY_SDSE_OFFSET                                      15
#define AVR32_ERAY_SDSE_SIZE                                         1
#define AVR32_ERAY_SDSL                                             15
#define AVR32_ERAY_SDSL_MASK                                0x00008000
#define AVR32_ERAY_SDSL_OFFSET                                      15
#define AVR32_ERAY_SDSL_SIZE                                         1
#define AVR32_ERAY_SDS_MASK                                 0x00008000
#define AVR32_ERAY_SDS_OFFSET                                       15
#define AVR32_ERAY_SDS_SIZE                                          1
#define AVR32_ERAY_SEC                                              24
#define AVR32_ERAY_SEC_MASK                                 0x03000000
#define AVR32_ERAY_SEC_OFFSET                                       24
#define AVR32_ERAY_SEC_SIZE                                          2
#define AVR32_ERAY_SEDA                                              1
#define AVR32_ERAY_SEDA_MASK                                0x00000002
#define AVR32_ERAY_SEDA_OFFSET                                       1
#define AVR32_ERAY_SEDA_SIZE                                         1
#define AVR32_ERAY_SEDB                                              9
#define AVR32_ERAY_SEDB_MASK                                0x00000200
#define AVR32_ERAY_SEDB_OFFSET                                       9
#define AVR32_ERAY_SEDB_SIZE                                         1
#define AVR32_ERAY_SENA                                              8
#define AVR32_ERAY_SENA_MASK                                0x00000100
#define AVR32_ERAY_SENA_OFFSET                                       8
#define AVR32_ERAY_SENA_SIZE                                         1
#define AVR32_ERAY_SENB                                             10
#define AVR32_ERAY_SENB_MASK                                0x00000400
#define AVR32_ERAY_SENB_OFFSET                                      10
#define AVR32_ERAY_SENB_SIZE                                         1
#define AVR32_ERAY_SEOA                                              2
#define AVR32_ERAY_SEOA_MASK                                0x00000004
#define AVR32_ERAY_SEOA_OFFSET                                       2
#define AVR32_ERAY_SEOA_SIZE                                         1
#define AVR32_ERAY_SEOB                                              3
#define AVR32_ERAY_SEOB_MASK                                0x00000008
#define AVR32_ERAY_SEOB_OFFSET                                       3
#define AVR32_ERAY_SEOB_SIZE                                         1
#define AVR32_ERAY_SESA                                              0
#define AVR32_ERAY_SESA_MASK                                0x00000001
#define AVR32_ERAY_SESA_OFFSET                                       0
#define AVR32_ERAY_SESA_SIZE                                         1
#define AVR32_ERAY_SESB                                              3
#define AVR32_ERAY_SESB_MASK                                0x00000008
#define AVR32_ERAY_SESB_OFFSET                                       3
#define AVR32_ERAY_SESB_SIZE                                         1
#define AVR32_ERAY_SFBM                                              2
#define AVR32_ERAY_SFBME                                             2
#define AVR32_ERAY_SFBME_MASK                               0x00000004
#define AVR32_ERAY_SFBME_OFFSET                                      2
#define AVR32_ERAY_SFBME_SIZE                                        1
#define AVR32_ERAY_SFBML                                             2
#define AVR32_ERAY_SFBML_MASK                               0x00000004
#define AVR32_ERAY_SFBML_OFFSET                                      2
#define AVR32_ERAY_SFBML_SIZE                                        1
#define AVR32_ERAY_SFBM_MASK                                0x00000004
#define AVR32_ERAY_SFBM_OFFSET                                       2
#define AVR32_ERAY_SFBM_SIZE                                         1
#define AVR32_ERAY_SFDL                                              0
#define AVR32_ERAY_SFDL_MASK                                0x0000007f
#define AVR32_ERAY_SFDL_OFFSET                                       0
#define AVR32_ERAY_SFDL_SIZE                                         7
#define AVR32_ERAY_SFI                                              25
#define AVR32_ERAY_SFIS                                             25
#define AVR32_ERAY_SFIS_MASK                                0x02000000
#define AVR32_ERAY_SFIS_OFFSET                                      25
#define AVR32_ERAY_SFIS_SIZE                                         1
#define AVR32_ERAY_SFI_MASK                                 0x02000000
#define AVR32_ERAY_SFI_OFFSET                                       25
#define AVR32_ERAY_SFI_SIZE                                          1
#define AVR32_ERAY_SFO                                               3
#define AVR32_ERAY_SFOE                                              3
#define AVR32_ERAY_SFOE_MASK                                0x00000008
#define AVR32_ERAY_SFOE_OFFSET                                       3
#define AVR32_ERAY_SFOE_SIZE                                         1
#define AVR32_ERAY_SFOL                                              3
#define AVR32_ERAY_SFOL_MASK                                0x00000008
#define AVR32_ERAY_SFOL_OFFSET                                       3
#define AVR32_ERAY_SFOL_SIZE                                         1
#define AVR32_ERAY_SFO_MASK                                 0x00000008
#define AVR32_ERAY_SFO_OFFSET                                        3
#define AVR32_ERAY_SFO_SIZE                                          1
#define AVR32_ERAY_SFS                                      0x00000120
#define AVR32_ERAY_SFS_MASK                                 0x000fffff
#define AVR32_ERAY_SFS_MOCS                                         16
#define AVR32_ERAY_SFS_MOCS_MASK                            0x00010000
#define AVR32_ERAY_SFS_MOCS_OFFSET                                  16
#define AVR32_ERAY_SFS_MOCS_SIZE                                     1
#define AVR32_ERAY_SFS_MRCS                                         18
#define AVR32_ERAY_SFS_MRCS_MASK                            0x00040000
#define AVR32_ERAY_SFS_MRCS_OFFSET                                  18
#define AVR32_ERAY_SFS_MRCS_SIZE                                     1
#define AVR32_ERAY_SFS_OCLR                                         17
#define AVR32_ERAY_SFS_OCLR_MASK                            0x00020000
#define AVR32_ERAY_SFS_OCLR_OFFSET                                  17
#define AVR32_ERAY_SFS_OCLR_SIZE                                     1
#define AVR32_ERAY_SFS_RCLR                                         19
#define AVR32_ERAY_SFS_RCLR_MASK                            0x00080000
#define AVR32_ERAY_SFS_RCLR_OFFSET                                  19
#define AVR32_ERAY_SFS_RCLR_SIZE                                     1
#define AVR32_ERAY_SFS_RESETVALUE                           0x00000000
#define AVR32_ERAY_SFS_VSAE                                          0
#define AVR32_ERAY_SFS_VSAE_MASK                            0x0000000f
#define AVR32_ERAY_SFS_VSAE_OFFSET                                   0
#define AVR32_ERAY_SFS_VSAE_SIZE                                     4
#define AVR32_ERAY_SFS_VSAO                                          4
#define AVR32_ERAY_SFS_VSAO_MASK                            0x000000f0
#define AVR32_ERAY_SFS_VSAO_OFFSET                                   4
#define AVR32_ERAY_SFS_VSAO_SIZE                                     4
#define AVR32_ERAY_SFS_VSBE                                          8
#define AVR32_ERAY_SFS_VSBE_MASK                            0x00000f00
#define AVR32_ERAY_SFS_VSBE_OFFSET                                   8
#define AVR32_ERAY_SFS_VSBE_SIZE                                     4
#define AVR32_ERAY_SFS_VSBO                                         12
#define AVR32_ERAY_SFS_VSBO_MASK                            0x0000f000
#define AVR32_ERAY_SFS_VSBO_OFFSET                                  12
#define AVR32_ERAY_SFS_VSBO_SIZE                                     4
#define AVR32_ERAY_SIER                                     0x0000003c
#define AVR32_ERAY_SIER_CASE                                         1
#define AVR32_ERAY_SIER_CASE_MASK                           0x00000002
#define AVR32_ERAY_SIER_CASE_OFFSET                                  1
#define AVR32_ERAY_SIER_CASE_SIZE                                    1
#define AVR32_ERAY_SIER_CYCSE                                        2
#define AVR32_ERAY_SIER_CYCSE_MASK                          0x00000004
#define AVR32_ERAY_SIER_CYCSE_OFFSET                                 2
#define AVR32_ERAY_SIER_CYCSE_SIZE                                   1
#define AVR32_ERAY_SIER_MASK                                0x0303ffff
#define AVR32_ERAY_SIER_MBSIE                                       14
#define AVR32_ERAY_SIER_MBSIE_MASK                          0x00004000
#define AVR32_ERAY_SIER_MBSIE_OFFSET                                14
#define AVR32_ERAY_SIER_MBSIE_SIZE                                   1
#define AVR32_ERAY_SIER_MTSAE                                       17
#define AVR32_ERAY_SIER_MTSAE_MASK                          0x00020000
#define AVR32_ERAY_SIER_MTSAE_OFFSET                                17
#define AVR32_ERAY_SIER_MTSAE_SIZE                                   1
#define AVR32_ERAY_SIER_MTSBE                                       25
#define AVR32_ERAY_SIER_MTSBE_MASK                          0x02000000
#define AVR32_ERAY_SIER_MTSBE_OFFSET                                25
#define AVR32_ERAY_SIER_MTSBE_SIZE                                   1
#define AVR32_ERAY_SIER_NMVCE                                        7
#define AVR32_ERAY_SIER_NMVCE_MASK                          0x00000080
#define AVR32_ERAY_SIER_NMVCE_OFFSET                                 7
#define AVR32_ERAY_SIER_NMVCE_SIZE                                   1
#define AVR32_ERAY_SIER_RESETVALUE                          0x00000000
#define AVR32_ERAY_SIER_RFCLE                                        6
#define AVR32_ERAY_SIER_RFCLE_MASK                          0x00000040
#define AVR32_ERAY_SIER_RFCLE_OFFSET                                 6
#define AVR32_ERAY_SIER_RFCLE_SIZE                                   1
#define AVR32_ERAY_SIER_RFNEE                                        5
#define AVR32_ERAY_SIER_RFNEE_MASK                          0x00000020
#define AVR32_ERAY_SIER_RFNEE_OFFSET                                 5
#define AVR32_ERAY_SIER_RFNEE_SIZE                                   1
#define AVR32_ERAY_SIER_RXIE                                         4
#define AVR32_ERAY_SIER_RXIE_MASK                           0x00000010
#define AVR32_ERAY_SIER_RXIE_OFFSET                                  4
#define AVR32_ERAY_SIER_RXIE_SIZE                                    1
#define AVR32_ERAY_SIER_SDSE                                        15
#define AVR32_ERAY_SIER_SDSE_MASK                           0x00008000
#define AVR32_ERAY_SIER_SDSE_OFFSET                                 15
#define AVR32_ERAY_SIER_SDSE_SIZE                                    1
#define AVR32_ERAY_SIER_SUCSE                                       13
#define AVR32_ERAY_SIER_SUCSE_MASK                          0x00002000
#define AVR32_ERAY_SIER_SUCSE_OFFSET                                13
#define AVR32_ERAY_SIER_SUCSE_SIZE                                   1
#define AVR32_ERAY_SIER_SWEE                                        12
#define AVR32_ERAY_SIER_SWEE_MASK                           0x00001000
#define AVR32_ERAY_SIER_SWEE_OFFSET                                 12
#define AVR32_ERAY_SIER_SWEE_SIZE                                    1
#define AVR32_ERAY_SIER_TI0E                                         8
#define AVR32_ERAY_SIER_TI0E_MASK                           0x00000100
#define AVR32_ERAY_SIER_TI0E_OFFSET                                  8
#define AVR32_ERAY_SIER_TI0E_SIZE                                    1
#define AVR32_ERAY_SIER_TI1E                                         9
#define AVR32_ERAY_SIER_TI1E_MASK                           0x00000200
#define AVR32_ERAY_SIER_TI1E_OFFSET                                  9
#define AVR32_ERAY_SIER_TI1E_SIZE                                    1
#define AVR32_ERAY_SIER_TIBCE                                       10
#define AVR32_ERAY_SIER_TIBCE_MASK                          0x00000400
#define AVR32_ERAY_SIER_TIBCE_OFFSET                                10
#define AVR32_ERAY_SIER_TIBCE_SIZE                                   1
#define AVR32_ERAY_SIER_TOBCE                                       11
#define AVR32_ERAY_SIER_TOBCE_MASK                          0x00000800
#define AVR32_ERAY_SIER_TOBCE_OFFSET                                11
#define AVR32_ERAY_SIER_TOBCE_SIZE                                   1
#define AVR32_ERAY_SIER_TXIE                                         3
#define AVR32_ERAY_SIER_TXIE_MASK                           0x00000008
#define AVR32_ERAY_SIER_TXIE_OFFSET                                  3
#define AVR32_ERAY_SIER_TXIE_SIZE                                    1
#define AVR32_ERAY_SIER_WSTE                                         0
#define AVR32_ERAY_SIER_WSTE_MASK                           0x00000001
#define AVR32_ERAY_SIER_WSTE_OFFSET                                  0
#define AVR32_ERAY_SIER_WSTE_SIZE                                    1
#define AVR32_ERAY_SIER_WUPAE                                       16
#define AVR32_ERAY_SIER_WUPAE_MASK                          0x00010000
#define AVR32_ERAY_SIER_WUPAE_OFFSET                                16
#define AVR32_ERAY_SIER_WUPAE_SIZE                                   1
#define AVR32_ERAY_SIER_WUPBE                                       24
#define AVR32_ERAY_SIER_WUPBE_MASK                          0x01000000
#define AVR32_ERAY_SIER_WUPBE_OFFSET                                24
#define AVR32_ERAY_SIER_WUPBE_SIZE                                   1
#define AVR32_ERAY_SIES                                     0x00000038
#define AVR32_ERAY_SIES_CASE                                         1
#define AVR32_ERAY_SIES_CASE_MASK                           0x00000002
#define AVR32_ERAY_SIES_CASE_OFFSET                                  1
#define AVR32_ERAY_SIES_CASE_SIZE                                    1
#define AVR32_ERAY_SIES_CYCSE                                        2
#define AVR32_ERAY_SIES_CYCSE_MASK                          0x00000004
#define AVR32_ERAY_SIES_CYCSE_OFFSET                                 2
#define AVR32_ERAY_SIES_CYCSE_SIZE                                   1
#define AVR32_ERAY_SIES_MASK                                0x0303ffff
#define AVR32_ERAY_SIES_MBSIE                                       14
#define AVR32_ERAY_SIES_MBSIE_MASK                          0x00004000
#define AVR32_ERAY_SIES_MBSIE_OFFSET                                14
#define AVR32_ERAY_SIES_MBSIE_SIZE                                   1
#define AVR32_ERAY_SIES_MTSAE                                       17
#define AVR32_ERAY_SIES_MTSAE_MASK                          0x00020000
#define AVR32_ERAY_SIES_MTSAE_OFFSET                                17
#define AVR32_ERAY_SIES_MTSAE_SIZE                                   1
#define AVR32_ERAY_SIES_MTSBE                                       25
#define AVR32_ERAY_SIES_MTSBE_MASK                          0x02000000
#define AVR32_ERAY_SIES_MTSBE_OFFSET                                25
#define AVR32_ERAY_SIES_MTSBE_SIZE                                   1
#define AVR32_ERAY_SIES_NMVCE                                        7
#define AVR32_ERAY_SIES_NMVCE_MASK                          0x00000080
#define AVR32_ERAY_SIES_NMVCE_OFFSET                                 7
#define AVR32_ERAY_SIES_NMVCE_SIZE                                   1
#define AVR32_ERAY_SIES_RESETVALUE                          0x00000000
#define AVR32_ERAY_SIES_RFCLE                                        6
#define AVR32_ERAY_SIES_RFCLE_MASK                          0x00000040
#define AVR32_ERAY_SIES_RFCLE_OFFSET                                 6
#define AVR32_ERAY_SIES_RFCLE_SIZE                                   1
#define AVR32_ERAY_SIES_RFNEE                                        5
#define AVR32_ERAY_SIES_RFNEE_MASK                          0x00000020
#define AVR32_ERAY_SIES_RFNEE_OFFSET                                 5
#define AVR32_ERAY_SIES_RFNEE_SIZE                                   1
#define AVR32_ERAY_SIES_RXIE                                         4
#define AVR32_ERAY_SIES_RXIE_MASK                           0x00000010
#define AVR32_ERAY_SIES_RXIE_OFFSET                                  4
#define AVR32_ERAY_SIES_RXIE_SIZE                                    1
#define AVR32_ERAY_SIES_SDSE                                        15
#define AVR32_ERAY_SIES_SDSE_MASK                           0x00008000
#define AVR32_ERAY_SIES_SDSE_OFFSET                                 15
#define AVR32_ERAY_SIES_SDSE_SIZE                                    1
#define AVR32_ERAY_SIES_SUCSE                                       13
#define AVR32_ERAY_SIES_SUCSE_MASK                          0x00002000
#define AVR32_ERAY_SIES_SUCSE_OFFSET                                13
#define AVR32_ERAY_SIES_SUCSE_SIZE                                   1
#define AVR32_ERAY_SIES_SWEE                                        12
#define AVR32_ERAY_SIES_SWEE_MASK                           0x00001000
#define AVR32_ERAY_SIES_SWEE_OFFSET                                 12
#define AVR32_ERAY_SIES_SWEE_SIZE                                    1
#define AVR32_ERAY_SIES_TI0E                                         8
#define AVR32_ERAY_SIES_TI0E_MASK                           0x00000100
#define AVR32_ERAY_SIES_TI0E_OFFSET                                  8
#define AVR32_ERAY_SIES_TI0E_SIZE                                    1
#define AVR32_ERAY_SIES_TI1E                                         9
#define AVR32_ERAY_SIES_TI1E_MASK                           0x00000200
#define AVR32_ERAY_SIES_TI1E_OFFSET                                  9
#define AVR32_ERAY_SIES_TI1E_SIZE                                    1
#define AVR32_ERAY_SIES_TIBCE                                       10
#define AVR32_ERAY_SIES_TIBCE_MASK                          0x00000400
#define AVR32_ERAY_SIES_TIBCE_OFFSET                                10
#define AVR32_ERAY_SIES_TIBCE_SIZE                                   1
#define AVR32_ERAY_SIES_TOBCE                                       11
#define AVR32_ERAY_SIES_TOBCE_MASK                          0x00000800
#define AVR32_ERAY_SIES_TOBCE_OFFSET                                11
#define AVR32_ERAY_SIES_TOBCE_SIZE                                   1
#define AVR32_ERAY_SIES_TXIE                                         3
#define AVR32_ERAY_SIES_TXIE_MASK                           0x00000008
#define AVR32_ERAY_SIES_TXIE_OFFSET                                  3
#define AVR32_ERAY_SIES_TXIE_SIZE                                    1
#define AVR32_ERAY_SIES_WSTE                                         0
#define AVR32_ERAY_SIES_WSTE_MASK                           0x00000001
#define AVR32_ERAY_SIES_WSTE_OFFSET                                  0
#define AVR32_ERAY_SIES_WSTE_SIZE                                    1
#define AVR32_ERAY_SIES_WUPAE                                       16
#define AVR32_ERAY_SIES_WUPAE_MASK                          0x00010000
#define AVR32_ERAY_SIES_WUPAE_OFFSET                                16
#define AVR32_ERAY_SIES_WUPAE_SIZE                                   1
#define AVR32_ERAY_SIES_WUPBE                                       24
#define AVR32_ERAY_SIES_WUPBE_MASK                          0x01000000
#define AVR32_ERAY_SIES_WUPBE_OFFSET                                24
#define AVR32_ERAY_SIES_WUPBE_SIZE                                   1
#define AVR32_ERAY_SILS                                     0x0000002c
#define AVR32_ERAY_SILS_CASL                                         1
#define AVR32_ERAY_SILS_CASL_MASK                           0x00000002
#define AVR32_ERAY_SILS_CASL_OFFSET                                  1
#define AVR32_ERAY_SILS_CASL_SIZE                                    1
#define AVR32_ERAY_SILS_CYCSL                                        2
#define AVR32_ERAY_SILS_CYCSL_MASK                          0x00000004
#define AVR32_ERAY_SILS_CYCSL_OFFSET                                 2
#define AVR32_ERAY_SILS_CYCSL_SIZE                                   1
#define AVR32_ERAY_SILS_MASK                                0x0303ffff
#define AVR32_ERAY_SILS_MBSIL                                       14
#define AVR32_ERAY_SILS_MBSIL_MASK                          0x00004000
#define AVR32_ERAY_SILS_MBSIL_OFFSET                                14
#define AVR32_ERAY_SILS_MBSIL_SIZE                                   1
#define AVR32_ERAY_SILS_MTSAL                                       17
#define AVR32_ERAY_SILS_MTSAL_MASK                          0x00020000
#define AVR32_ERAY_SILS_MTSAL_OFFSET                                17
#define AVR32_ERAY_SILS_MTSAL_SIZE                                   1
#define AVR32_ERAY_SILS_MTSBL                                       25
#define AVR32_ERAY_SILS_MTSBL_MASK                          0x02000000
#define AVR32_ERAY_SILS_MTSBL_OFFSET                                25
#define AVR32_ERAY_SILS_MTSBL_SIZE                                   1
#define AVR32_ERAY_SILS_NMVCL                                        7
#define AVR32_ERAY_SILS_NMVCL_MASK                          0x00000080
#define AVR32_ERAY_SILS_NMVCL_OFFSET                                 7
#define AVR32_ERAY_SILS_NMVCL_SIZE                                   1
#define AVR32_ERAY_SILS_RESETVALUE                          0x00000000
#define AVR32_ERAY_SILS_RFCLL                                        6
#define AVR32_ERAY_SILS_RFCLL_MASK                          0x00000040
#define AVR32_ERAY_SILS_RFCLL_OFFSET                                 6
#define AVR32_ERAY_SILS_RFCLL_SIZE                                   1
#define AVR32_ERAY_SILS_RFNEL                                        5
#define AVR32_ERAY_SILS_RFNEL_MASK                          0x00000020
#define AVR32_ERAY_SILS_RFNEL_OFFSET                                 5
#define AVR32_ERAY_SILS_RFNEL_SIZE                                   1
#define AVR32_ERAY_SILS_RXIL                                         4
#define AVR32_ERAY_SILS_RXIL_MASK                           0x00000010
#define AVR32_ERAY_SILS_RXIL_OFFSET                                  4
#define AVR32_ERAY_SILS_RXIL_SIZE                                    1
#define AVR32_ERAY_SILS_SDSL                                        15
#define AVR32_ERAY_SILS_SDSL_MASK                           0x00008000
#define AVR32_ERAY_SILS_SDSL_OFFSET                                 15
#define AVR32_ERAY_SILS_SDSL_SIZE                                    1
#define AVR32_ERAY_SILS_SUCSL                                       13
#define AVR32_ERAY_SILS_SUCSL_MASK                          0x00002000
#define AVR32_ERAY_SILS_SUCSL_OFFSET                                13
#define AVR32_ERAY_SILS_SUCSL_SIZE                                   1
#define AVR32_ERAY_SILS_SWEL                                        12
#define AVR32_ERAY_SILS_SWEL_MASK                           0x00001000
#define AVR32_ERAY_SILS_SWEL_OFFSET                                 12
#define AVR32_ERAY_SILS_SWEL_SIZE                                    1
#define AVR32_ERAY_SILS_TI0L                                         8
#define AVR32_ERAY_SILS_TI0L_MASK                           0x00000100
#define AVR32_ERAY_SILS_TI0L_OFFSET                                  8
#define AVR32_ERAY_SILS_TI0L_SIZE                                    1
#define AVR32_ERAY_SILS_TI1L                                         9
#define AVR32_ERAY_SILS_TI1L_MASK                           0x00000200
#define AVR32_ERAY_SILS_TI1L_OFFSET                                  9
#define AVR32_ERAY_SILS_TI1L_SIZE                                    1
#define AVR32_ERAY_SILS_TIBCL                                       10
#define AVR32_ERAY_SILS_TIBCL_MASK                          0x00000400
#define AVR32_ERAY_SILS_TIBCL_OFFSET                                10
#define AVR32_ERAY_SILS_TIBCL_SIZE                                   1
#define AVR32_ERAY_SILS_TOBCL                                       11
#define AVR32_ERAY_SILS_TOBCL_MASK                          0x00000800
#define AVR32_ERAY_SILS_TOBCL_OFFSET                                11
#define AVR32_ERAY_SILS_TOBCL_SIZE                                   1
#define AVR32_ERAY_SILS_TXIL                                         3
#define AVR32_ERAY_SILS_TXIL_MASK                           0x00000008
#define AVR32_ERAY_SILS_TXIL_OFFSET                                  3
#define AVR32_ERAY_SILS_TXIL_SIZE                                    1
#define AVR32_ERAY_SILS_WSTL                                         0
#define AVR32_ERAY_SILS_WSTL_MASK                           0x00000001
#define AVR32_ERAY_SILS_WSTL_OFFSET                                  0
#define AVR32_ERAY_SILS_WSTL_SIZE                                    1
#define AVR32_ERAY_SILS_WUPAL                                       16
#define AVR32_ERAY_SILS_WUPAL_MASK                          0x00010000
#define AVR32_ERAY_SILS_WUPAL_OFFSET                                16
#define AVR32_ERAY_SILS_WUPAL_SIZE                                   1
#define AVR32_ERAY_SILS_WUPBL                                       24
#define AVR32_ERAY_SILS_WUPBL_MASK                          0x01000000
#define AVR32_ERAY_SILS_WUPBL_OFFSET                                24
#define AVR32_ERAY_SILS_WUPBL_SIZE                                   1
#define AVR32_ERAY_SIR                                      0x00000024
#define AVR32_ERAY_SIR_CAS                                           1
#define AVR32_ERAY_SIR_CAS_MASK                             0x00000002
#define AVR32_ERAY_SIR_CAS_OFFSET                                    1
#define AVR32_ERAY_SIR_CAS_SIZE                                      1
#define AVR32_ERAY_SIR_CYCS                                          2
#define AVR32_ERAY_SIR_CYCS_MASK                            0x00000004
#define AVR32_ERAY_SIR_CYCS_OFFSET                                   2
#define AVR32_ERAY_SIR_CYCS_SIZE                                     1
#define AVR32_ERAY_SIR_MASK                                 0x0303ffff
#define AVR32_ERAY_SIR_MBSI                                         14
#define AVR32_ERAY_SIR_MBSI_MASK                            0x00004000
#define AVR32_ERAY_SIR_MBSI_OFFSET                                  14
#define AVR32_ERAY_SIR_MBSI_SIZE                                     1
#define AVR32_ERAY_SIR_MTSA                                         17
#define AVR32_ERAY_SIR_MTSA_MASK                            0x00020000
#define AVR32_ERAY_SIR_MTSA_OFFSET                                  17
#define AVR32_ERAY_SIR_MTSA_SIZE                                     1
#define AVR32_ERAY_SIR_MTSB                                         25
#define AVR32_ERAY_SIR_MTSB_MASK                            0x02000000
#define AVR32_ERAY_SIR_MTSB_OFFSET                                  25
#define AVR32_ERAY_SIR_MTSB_SIZE                                     1
#define AVR32_ERAY_SIR_NMVC                                          7
#define AVR32_ERAY_SIR_NMVC_MASK                            0x00000080
#define AVR32_ERAY_SIR_NMVC_OFFSET                                   7
#define AVR32_ERAY_SIR_NMVC_SIZE                                     1
#define AVR32_ERAY_SIR_RESETVALUE                           0x00000000
#define AVR32_ERAY_SIR_RFCL                                          6
#define AVR32_ERAY_SIR_RFCL_MASK                            0x00000040
#define AVR32_ERAY_SIR_RFCL_OFFSET                                   6
#define AVR32_ERAY_SIR_RFCL_SIZE                                     1
#define AVR32_ERAY_SIR_RFNE                                          5
#define AVR32_ERAY_SIR_RFNE_MASK                            0x00000020
#define AVR32_ERAY_SIR_RFNE_OFFSET                                   5
#define AVR32_ERAY_SIR_RFNE_SIZE                                     1
#define AVR32_ERAY_SIR_RXI                                           4
#define AVR32_ERAY_SIR_RXI_MASK                             0x00000010
#define AVR32_ERAY_SIR_RXI_OFFSET                                    4
#define AVR32_ERAY_SIR_RXI_SIZE                                      1
#define AVR32_ERAY_SIR_SDS                                          15
#define AVR32_ERAY_SIR_SDS_MASK                             0x00008000
#define AVR32_ERAY_SIR_SDS_OFFSET                                   15
#define AVR32_ERAY_SIR_SDS_SIZE                                      1
#define AVR32_ERAY_SIR_SUCS                                         13
#define AVR32_ERAY_SIR_SUCS_MASK                            0x00002000
#define AVR32_ERAY_SIR_SUCS_OFFSET                                  13
#define AVR32_ERAY_SIR_SUCS_SIZE                                     1
#define AVR32_ERAY_SIR_SWE                                          12
#define AVR32_ERAY_SIR_SWE_MASK                             0x00001000
#define AVR32_ERAY_SIR_SWE_OFFSET                                   12
#define AVR32_ERAY_SIR_SWE_SIZE                                      1
#define AVR32_ERAY_SIR_TI0                                           8
#define AVR32_ERAY_SIR_TI0_MASK                             0x00000100
#define AVR32_ERAY_SIR_TI0_OFFSET                                    8
#define AVR32_ERAY_SIR_TI0_SIZE                                      1
#define AVR32_ERAY_SIR_TI1                                           9
#define AVR32_ERAY_SIR_TI1_MASK                             0x00000200
#define AVR32_ERAY_SIR_TI1_OFFSET                                    9
#define AVR32_ERAY_SIR_TI1_SIZE                                      1
#define AVR32_ERAY_SIR_TIBC                                         10
#define AVR32_ERAY_SIR_TIBC_MASK                            0x00000400
#define AVR32_ERAY_SIR_TIBC_OFFSET                                  10
#define AVR32_ERAY_SIR_TIBC_SIZE                                     1
#define AVR32_ERAY_SIR_TOBC                                         11
#define AVR32_ERAY_SIR_TOBC_MASK                            0x00000800
#define AVR32_ERAY_SIR_TOBC_OFFSET                                  11
#define AVR32_ERAY_SIR_TOBC_SIZE                                     1
#define AVR32_ERAY_SIR_TXI                                           3
#define AVR32_ERAY_SIR_TXI_MASK                             0x00000008
#define AVR32_ERAY_SIR_TXI_OFFSET                                    3
#define AVR32_ERAY_SIR_TXI_SIZE                                      1
#define AVR32_ERAY_SIR_WST                                           0
#define AVR32_ERAY_SIR_WST_MASK                             0x00000001
#define AVR32_ERAY_SIR_WST_OFFSET                                    0
#define AVR32_ERAY_SIR_WST_SIZE                                      1
#define AVR32_ERAY_SIR_WUPA                                         16
#define AVR32_ERAY_SIR_WUPA_MASK                            0x00010000
#define AVR32_ERAY_SIR_WUPA_OFFSET                                  16
#define AVR32_ERAY_SIR_WUPA_SIZE                                     1
#define AVR32_ERAY_SIR_WUPB                                         24
#define AVR32_ERAY_SIR_WUPB_MASK                            0x01000000
#define AVR32_ERAY_SIR_WUPB_OFFSET                                  24
#define AVR32_ERAY_SIR_WUPB_SIZE                                     1
#define AVR32_ERAY_SLM                                               8
#define AVR32_ERAY_SLM_MASK                                 0x00000300
#define AVR32_ERAY_SLM_OFFSET                                        8
#define AVR32_ERAY_SLM_SIZE                                          2
#define AVR32_ERAY_SLT                                              16
#define AVR32_ERAY_SLT_MASK                                 0x1fff0000
#define AVR32_ERAY_SLT_OFFSET                                       16
#define AVR32_ERAY_SLT_SIZE                                         13
#define AVR32_ERAY_SMTV                                             16
#define AVR32_ERAY_SMTV_MASK                                0x3fff0000
#define AVR32_ERAY_SMTV_OFFSET                                      16
#define AVR32_ERAY_SMTV_SIZE                                        14
#define AVR32_ERAY_SNM                                              16
#define AVR32_ERAY_SNM_MASK                                 0x000f0000
#define AVR32_ERAY_SNM_OFFSET                                       16
#define AVR32_ERAY_SNM_SIZE                                          4
#define AVR32_ERAY_SNUA                                              0
#define AVR32_ERAY_SNUA_MASK                                0x00000001
#define AVR32_ERAY_SNUA_OFFSET                                       0
#define AVR32_ERAY_SNUA_SIZE                                         1
#define AVR32_ERAY_SNUB                                              1
#define AVR32_ERAY_SNUB_MASK                                0x00000002
#define AVR32_ERAY_SNUB_OFFSET                                       1
#define AVR32_ERAY_SNUB_SIZE                                         1
#define AVR32_ERAY_SPLM                                             26
#define AVR32_ERAY_SPLM_MASK                                0x04000000
#define AVR32_ERAY_SPLM_OFFSET                                      26
#define AVR32_ERAY_SPLM_SIZE                                         1
#define AVR32_ERAY_SPP                                              12
#define AVR32_ERAY_SPP_MASK                                 0x00003000
#define AVR32_ERAY_SPP_OFFSET                                       12
#define AVR32_ERAY_SPP_SIZE                                          2
#define AVR32_ERAY_SR                                       0x00000810
#define AVR32_ERAY_SR_DIAGR1                                         8
#define AVR32_ERAY_SR_DIAGR1_MASK                           0x00000100
#define AVR32_ERAY_SR_DIAGR1_OFFSET                                  8
#define AVR32_ERAY_SR_DIAGR1_SIZE                                    1
#define AVR32_ERAY_SR_DIAGR2                                         9
#define AVR32_ERAY_SR_DIAGR2_MASK                           0x00000200
#define AVR32_ERAY_SR_DIAGR2_OFFSET                                  9
#define AVR32_ERAY_SR_DIAGR2_SIZE                                    1
#define AVR32_ERAY_SR_MASK                                  0x00000303
#define AVR32_ERAY_SR_RESETVALUE                            0x00000000
#define AVR32_ERAY_SR_SA1                                            0
#define AVR32_ERAY_SR_SA1_MASK                              0x00000001
#define AVR32_ERAY_SR_SA1_OFFSET                                     0
#define AVR32_ERAY_SR_SA1_SIZE                                       1
#define AVR32_ERAY_SR_SA2                                            1
#define AVR32_ERAY_SR_SA2_MASK                              0x00000002
#define AVR32_ERAY_SR_SA2_OFFSET                                     1
#define AVR32_ERAY_SR_SA2_SIZE                                       1
#define AVR32_ERAY_SSCVA                                             0
#define AVR32_ERAY_SSCVA_MASK                               0x000007ff
#define AVR32_ERAY_SSCVA_OFFSET                                      0
#define AVR32_ERAY_SSCVA_SIZE                                       11
#define AVR32_ERAY_SSCVB                                            16
#define AVR32_ERAY_SSCVB_MASK                               0x07ff0000
#define AVR32_ERAY_SSCVB_OFFSET                                     16
#define AVR32_ERAY_SSCVB_SIZE                                       11
#define AVR32_ERAY_SSEL                                              4
#define AVR32_ERAY_SSEL_MASK                                0x00000070
#define AVR32_ERAY_SSEL_OFFSET                                       4
#define AVR32_ERAY_SSEL_SIZE                                         3
#define AVR32_ERAY_SSL                                               0
#define AVR32_ERAY_SSL_MASK                                 0x000003ff
#define AVR32_ERAY_SSL_OFFSET                                        0
#define AVR32_ERAY_SSL_SIZE                                         10
#define AVR32_ERAY_SSWT                                              3
#define AVR32_ERAY_SSWT_MASK                                0x00000008
#define AVR32_ERAY_SSWT_OFFSET                                       3
#define AVR32_ERAY_SSWT_SIZE                                         1
#define AVR32_ERAY_STAT1                                             0
#define AVR32_ERAY_STAT1_MASK                               0x0000ffff
#define AVR32_ERAY_STAT1_OFFSET                                      0
#define AVR32_ERAY_STAT1_SIZE                                       16
#define AVR32_ERAY_STAT2                                            16
#define AVR32_ERAY_STAT2_MASK                               0xffff0000
#define AVR32_ERAY_STAT2_OFFSET                                     16
#define AVR32_ERAY_STAT2_SIZE                                       16
#define AVR32_ERAY_STEP                                             20
#define AVR32_ERAY_STEP_MASK                                0x0ff00000
#define AVR32_ERAY_STEP_OFFSET                                      20
#define AVR32_ERAY_STEP_SIZE                                         8
#define AVR32_ERAY_STPW1                                    0x0000004c
#define AVR32_ERAY_STPW1_EDGE                                        2
#define AVR32_ERAY_STPW1_EDGE_MASK                          0x00000004
#define AVR32_ERAY_STPW1_EDGE_OFFSET                                 2
#define AVR32_ERAY_STPW1_EDGE_SIZE                                   1
#define AVR32_ERAY_STPW1_EETP                                        4
#define AVR32_ERAY_STPW1_EETP_MASK                          0x00000010
#define AVR32_ERAY_STPW1_EETP_OFFSET                                 4
#define AVR32_ERAY_STPW1_EETP_SIZE                                   1
#define AVR32_ERAY_STPW1_EINT0                                       5
#define AVR32_ERAY_STPW1_EINT0_MASK                         0x00000020
#define AVR32_ERAY_STPW1_EINT0_OFFSET                                5
#define AVR32_ERAY_STPW1_EINT0_SIZE                                  1
#define AVR32_ERAY_STPW1_EINT1                                       6
#define AVR32_ERAY_STPW1_EINT1_MASK                         0x00000040
#define AVR32_ERAY_STPW1_EINT1_OFFSET                                6
#define AVR32_ERAY_STPW1_EINT1_SIZE                                  1
#define AVR32_ERAY_STPW1_ESWT                                        0
#define AVR32_ERAY_STPW1_ESWT_MASK                          0x00000001
#define AVR32_ERAY_STPW1_ESWT_OFFSET                                 0
#define AVR32_ERAY_STPW1_ESWT_SIZE                                   1
#define AVR32_ERAY_STPW1_MASK                               0x3fff3f7f
#define AVR32_ERAY_STPW1_RESETVALUE                         0x00000000
#define AVR32_ERAY_STPW1_SCCV                                        8
#define AVR32_ERAY_STPW1_SCCV_MASK                          0x00003f00
#define AVR32_ERAY_STPW1_SCCV_OFFSET                                 8
#define AVR32_ERAY_STPW1_SCCV_SIZE                                   6
#define AVR32_ERAY_STPW1_SMTV                                       16
#define AVR32_ERAY_STPW1_SMTV_MASK                          0x3fff0000
#define AVR32_ERAY_STPW1_SMTV_OFFSET                                16
#define AVR32_ERAY_STPW1_SMTV_SIZE                                  14
#define AVR32_ERAY_STPW1_SSWT                                        3
#define AVR32_ERAY_STPW1_SSWT_MASK                          0x00000008
#define AVR32_ERAY_STPW1_SSWT_OFFSET                                 3
#define AVR32_ERAY_STPW1_SSWT_SIZE                                   1
#define AVR32_ERAY_STPW1_SWMS                                        1
#define AVR32_ERAY_STPW1_SWMS_MASK                          0x00000002
#define AVR32_ERAY_STPW1_SWMS_OFFSET                                 1
#define AVR32_ERAY_STPW1_SWMS_SIZE                                   1
#define AVR32_ERAY_STPW2                                    0x00000050
#define AVR32_ERAY_STPW2_MASK                               0x07ff07ff
#define AVR32_ERAY_STPW2_RESETVALUE                         0x00000000
#define AVR32_ERAY_STPW2_SSCVA                                       0
#define AVR32_ERAY_STPW2_SSCVA_MASK                         0x000007ff
#define AVR32_ERAY_STPW2_SSCVA_OFFSET                                0
#define AVR32_ERAY_STPW2_SSCVA_SIZE                                 11
#define AVR32_ERAY_STPW2_SSCVB                                      16
#define AVR32_ERAY_STPW2_SSCVB_MASK                         0x07ff0000
#define AVR32_ERAY_STPW2_SSCVB_OFFSET                               16
#define AVR32_ERAY_STPW2_SSCVB_SIZE                                 11
#define AVR32_ERAY_STXRH                                             2
#define AVR32_ERAY_STXRH_MASK                               0x00000004
#define AVR32_ERAY_STXRH_OFFSET                                      2
#define AVR32_ERAY_STXRH_SIZE                                        1
#define AVR32_ERAY_STXRS                                            18
#define AVR32_ERAY_STXRS_MASK                               0x00040000
#define AVR32_ERAY_STXRS_OFFSET                                     18
#define AVR32_ERAY_STXRS_SIZE                                        1
#define AVR32_ERAY_SUCC1                                    0x00000080
#define AVR32_ERAY_SUCC1_CCHA                                       26
#define AVR32_ERAY_SUCC1_CCHA_MASK                          0x04000000
#define AVR32_ERAY_SUCC1_CCHA_OFFSET                                26
#define AVR32_ERAY_SUCC1_CCHA_SIZE                                   1
#define AVR32_ERAY_SUCC1_CCHB                                       27
#define AVR32_ERAY_SUCC1_CCHB_MASK                          0x08000000
#define AVR32_ERAY_SUCC1_CCHB_OFFSET                                27
#define AVR32_ERAY_SUCC1_CCHB_SIZE                                   1
#define AVR32_ERAY_SUCC1_CMD                                         0
#define AVR32_ERAY_SUCC1_CMD_MASK                           0x0000000f
#define AVR32_ERAY_SUCC1_CMD_OFFSET                                  0
#define AVR32_ERAY_SUCC1_CMD_SIZE                                    4
#define AVR32_ERAY_SUCC1_CSA                                        11
#define AVR32_ERAY_SUCC1_CSA_MASK                           0x0000f800
#define AVR32_ERAY_SUCC1_CSA_OFFSET                                 11
#define AVR32_ERAY_SUCC1_CSA_SIZE                                    5
#define AVR32_ERAY_SUCC1_HCSE                                       23
#define AVR32_ERAY_SUCC1_HCSE_MASK                          0x00800000
#define AVR32_ERAY_SUCC1_HCSE_OFFSET                                23
#define AVR32_ERAY_SUCC1_HCSE_SIZE                                   1
#define AVR32_ERAY_SUCC1_MASK                               0x0ffffb8f
#define AVR32_ERAY_SUCC1_MTSA                                       24
#define AVR32_ERAY_SUCC1_MTSA_MASK                          0x01000000
#define AVR32_ERAY_SUCC1_MTSA_OFFSET                                24
#define AVR32_ERAY_SUCC1_MTSA_SIZE                                   1
#define AVR32_ERAY_SUCC1_MTSB                                       25
#define AVR32_ERAY_SUCC1_MTSB_MASK                          0x02000000
#define AVR32_ERAY_SUCC1_MTSB_OFFSET                                25
#define AVR32_ERAY_SUCC1_MTSB_SIZE                                   1
#define AVR32_ERAY_SUCC1_PBSY                                        7
#define AVR32_ERAY_SUCC1_PBSY_MASK                          0x00000080
#define AVR32_ERAY_SUCC1_PBSY_OFFSET                                 7
#define AVR32_ERAY_SUCC1_PBSY_SIZE                                   1
#define AVR32_ERAY_SUCC1_PTA                                        16
#define AVR32_ERAY_SUCC1_PTA_MASK                           0x001f0000
#define AVR32_ERAY_SUCC1_PTA_OFFSET                                 16
#define AVR32_ERAY_SUCC1_PTA_SIZE                                    5
#define AVR32_ERAY_SUCC1_RESETVALUE                         0x00000000
#define AVR32_ERAY_SUCC1_TSM                                        22
#define AVR32_ERAY_SUCC1_TSM_MASK                           0x00400000
#define AVR32_ERAY_SUCC1_TSM_OFFSET                                 22
#define AVR32_ERAY_SUCC1_TSM_SIZE                                    1
#define AVR32_ERAY_SUCC1_TXST                                        8
#define AVR32_ERAY_SUCC1_TXST_MASK                          0x00000100
#define AVR32_ERAY_SUCC1_TXST_OFFSET                                 8
#define AVR32_ERAY_SUCC1_TXST_SIZE                                   1
#define AVR32_ERAY_SUCC1_TXSY                                        9
#define AVR32_ERAY_SUCC1_TXSY_MASK                          0x00000200
#define AVR32_ERAY_SUCC1_TXSY_OFFSET                                 9
#define AVR32_ERAY_SUCC1_TXSY_SIZE                                   1
#define AVR32_ERAY_SUCC1_WUCS                                       21
#define AVR32_ERAY_SUCC1_WUCS_MASK                          0x00200000
#define AVR32_ERAY_SUCC1_WUCS_OFFSET                                21
#define AVR32_ERAY_SUCC1_WUCS_SIZE                                   1
#define AVR32_ERAY_SUCC2                                    0x00000084
#define AVR32_ERAY_SUCC2_LT                                          0
#define AVR32_ERAY_SUCC2_LTN                                        24
#define AVR32_ERAY_SUCC2_LTN_MASK                           0x0f000000
#define AVR32_ERAY_SUCC2_LTN_OFFSET                                 24
#define AVR32_ERAY_SUCC2_LTN_SIZE                                    4
#define AVR32_ERAY_SUCC2_LT_MASK                            0x001fffff
#define AVR32_ERAY_SUCC2_LT_OFFSET                                   0
#define AVR32_ERAY_SUCC2_LT_SIZE                                    21
#define AVR32_ERAY_SUCC2_MASK                               0x0f1fffff
#define AVR32_ERAY_SUCC2_RESETVALUE                         0x00000000
#define AVR32_ERAY_SUCC3                                    0x00000088
#define AVR32_ERAY_SUCC3_MASK                               0x000000ff
#define AVR32_ERAY_SUCC3_RESETVALUE                         0x00000000
#define AVR32_ERAY_SUCC3_WCF                                         4
#define AVR32_ERAY_SUCC3_WCF_MASK                           0x000000f0
#define AVR32_ERAY_SUCC3_WCF_OFFSET                                  4
#define AVR32_ERAY_SUCC3_WCF_SIZE                                    4
#define AVR32_ERAY_SUCC3_WCP                                         0
#define AVR32_ERAY_SUCC3_WCP_MASK                           0x0000000f
#define AVR32_ERAY_SUCC3_WCP_OFFSET                                  0
#define AVR32_ERAY_SUCC3_WCP_SIZE                                    4
#define AVR32_ERAY_SUCS                                             13
#define AVR32_ERAY_SUCSE                                            13
#define AVR32_ERAY_SUCSE_MASK                               0x00002000
#define AVR32_ERAY_SUCSE_OFFSET                                     13
#define AVR32_ERAY_SUCSE_SIZE                                        1
#define AVR32_ERAY_SUCSL                                            13
#define AVR32_ERAY_SUCSL_MASK                               0x00002000
#define AVR32_ERAY_SUCSL_OFFSET                                     13
#define AVR32_ERAY_SUCSL_SIZE                                        1
#define AVR32_ERAY_SUCS_MASK                                0x00002000
#define AVR32_ERAY_SUCS_OFFSET                                      13
#define AVR32_ERAY_SUCS_SIZE                                         1
#define AVR32_ERAY_SVOA                                              6
#define AVR32_ERAY_SVOA_MASK                                0x00000040
#define AVR32_ERAY_SVOA_OFFSET                                       6
#define AVR32_ERAY_SVOA_SIZE                                         1
#define AVR32_ERAY_SVOB                                              7
#define AVR32_ERAY_SVOB_MASK                                0x00000080
#define AVR32_ERAY_SVOB_OFFSET                                       7
#define AVR32_ERAY_SVOB_SIZE                                         1
#define AVR32_ERAY_SWE                                              12
#define AVR32_ERAY_SWEE                                             12
#define AVR32_ERAY_SWEE_MASK                                0x00001000
#define AVR32_ERAY_SWEE_OFFSET                                      12
#define AVR32_ERAY_SWEE_SIZE                                         1
#define AVR32_ERAY_SWEL                                             12
#define AVR32_ERAY_SWEL_MASK                                0x00001000
#define AVR32_ERAY_SWEL_OFFSET                                      12
#define AVR32_ERAY_SWEL_SIZE                                         1
#define AVR32_ERAY_SWE_MASK                                 0x00001000
#define AVR32_ERAY_SWE_OFFSET                                       12
#define AVR32_ERAY_SWE_SIZE                                          1
#define AVR32_ERAY_SWMS                                              1
#define AVR32_ERAY_SWMS_MASK                                0x00000002
#define AVR32_ERAY_SWMS_OFFSET                                       1
#define AVR32_ERAY_SWMS_SIZE                                         1
#define AVR32_ERAY_SWNIT                                    0x00000124
#define AVR32_ERAY_SWNIT_MASK                               0x00000fff
#define AVR32_ERAY_SWNIT_MTSA                                        6
#define AVR32_ERAY_SWNIT_MTSA_MASK                          0x00000040
#define AVR32_ERAY_SWNIT_MTSA_OFFSET                                 6
#define AVR32_ERAY_SWNIT_MTSA_SIZE                                   1
#define AVR32_ERAY_SWNIT_MTSB                                        7
#define AVR32_ERAY_SWNIT_MTSB_MASK                          0x00000080
#define AVR32_ERAY_SWNIT_MTSB_OFFSET                                 7
#define AVR32_ERAY_SWNIT_MTSB_SIZE                                   1
#define AVR32_ERAY_SWNIT_RESETVALUE                         0x00000000
#define AVR32_ERAY_SWNIT_SBNA                                        9
#define AVR32_ERAY_SWNIT_SBNA_MASK                          0x00000200
#define AVR32_ERAY_SWNIT_SBNA_OFFSET                                 9
#define AVR32_ERAY_SWNIT_SBNA_SIZE                                   1
#define AVR32_ERAY_SWNIT_SBNB                                       11
#define AVR32_ERAY_SWNIT_SBNB_MASK                          0x00000800
#define AVR32_ERAY_SWNIT_SBNB_OFFSET                                11
#define AVR32_ERAY_SWNIT_SBNB_SIZE                                   1
#define AVR32_ERAY_SWNIT_SBSA                                        1
#define AVR32_ERAY_SWNIT_SBSA_MASK                          0x00000002
#define AVR32_ERAY_SWNIT_SBSA_OFFSET                                 1
#define AVR32_ERAY_SWNIT_SBSA_SIZE                                   1
#define AVR32_ERAY_SWNIT_SBSB                                        4
#define AVR32_ERAY_SWNIT_SBSB_MASK                          0x00000010
#define AVR32_ERAY_SWNIT_SBSB_OFFSET                                 4
#define AVR32_ERAY_SWNIT_SBSB_SIZE                                   1
#define AVR32_ERAY_SWNIT_SENA                                        8
#define AVR32_ERAY_SWNIT_SENA_MASK                          0x00000100
#define AVR32_ERAY_SWNIT_SENA_OFFSET                                 8
#define AVR32_ERAY_SWNIT_SENA_SIZE                                   1
#define AVR32_ERAY_SWNIT_SENB                                       10
#define AVR32_ERAY_SWNIT_SENB_MASK                          0x00000400
#define AVR32_ERAY_SWNIT_SENB_OFFSET                                10
#define AVR32_ERAY_SWNIT_SENB_SIZE                                   1
#define AVR32_ERAY_SWNIT_SESA                                        0
#define AVR32_ERAY_SWNIT_SESA_MASK                          0x00000001
#define AVR32_ERAY_SWNIT_SESA_OFFSET                                 0
#define AVR32_ERAY_SWNIT_SESA_SIZE                                   1
#define AVR32_ERAY_SWNIT_SESB                                        3
#define AVR32_ERAY_SWNIT_SESB_MASK                          0x00000008
#define AVR32_ERAY_SWNIT_SESB_OFFSET                                 3
#define AVR32_ERAY_SWNIT_SESB_SIZE                                   1
#define AVR32_ERAY_SWNIT_TCSA                                        2
#define AVR32_ERAY_SWNIT_TCSA_MASK                          0x00000004
#define AVR32_ERAY_SWNIT_TCSA_OFFSET                                 2
#define AVR32_ERAY_SWNIT_TCSA_SIZE                                   1
#define AVR32_ERAY_SWNIT_TCSB                                        5
#define AVR32_ERAY_SWNIT_TCSB_MASK                          0x00000020
#define AVR32_ERAY_SWNIT_TCSB_OFFSET                                 5
#define AVR32_ERAY_SWNIT_TCSB_SIZE                                   1
#define AVR32_ERAY_SYN                                              26
#define AVR32_ERAY_SYNS                                             26
#define AVR32_ERAY_SYNS_MASK                                0x04000000
#define AVR32_ERAY_SYNS_OFFSET                                      26
#define AVR32_ERAY_SYNS_SIZE                                         1
#define AVR32_ERAY_SYN_MASK                                 0x04000000
#define AVR32_ERAY_SYN_OFFSET                                       26
#define AVR32_ERAY_SYN_SIZE                                          1
#define AVR32_ERAY_T0C                                      0x00000044
#define AVR32_ERAY_T0CC                                              8
#define AVR32_ERAY_T0CC_MASK                                0x00007f00
#define AVR32_ERAY_T0CC_OFFSET                                       8
#define AVR32_ERAY_T0CC_SIZE                                         7
#define AVR32_ERAY_T0C_MASK                                 0x3fff7f03
#define AVR32_ERAY_T0C_RESETVALUE                           0x00000000
#define AVR32_ERAY_T0C_T0CC                                          8
#define AVR32_ERAY_T0C_T0CC_MASK                            0x00007f00
#define AVR32_ERAY_T0C_T0CC_OFFSET                                   8
#define AVR32_ERAY_T0C_T0CC_SIZE                                     7
#define AVR32_ERAY_T0C_T0MO                                         16
#define AVR32_ERAY_T0C_T0MO_MASK                            0x3fff0000
#define AVR32_ERAY_T0C_T0MO_OFFSET                                  16
#define AVR32_ERAY_T0C_T0MO_SIZE                                    14
#define AVR32_ERAY_T0C_T0MS                                          1
#define AVR32_ERAY_T0C_T0MS_MASK                            0x00000002
#define AVR32_ERAY_T0C_T0MS_OFFSET                                   1
#define AVR32_ERAY_T0C_T0MS_SIZE                                     1
#define AVR32_ERAY_T0C_T0RC                                          0
#define AVR32_ERAY_T0C_T0RC_MASK                            0x00000001
#define AVR32_ERAY_T0C_T0RC_OFFSET                                   0
#define AVR32_ERAY_T0C_T0RC_SIZE                                     1
#define AVR32_ERAY_T0MO                                             16
#define AVR32_ERAY_T0MO_MASK                                0x3fff0000
#define AVR32_ERAY_T0MO_OFFSET                                      16
#define AVR32_ERAY_T0MO_SIZE                                        14
#define AVR32_ERAY_T0MS                                              1
#define AVR32_ERAY_T0MS_MASK                                0x00000002
#define AVR32_ERAY_T0MS_OFFSET                                       1
#define AVR32_ERAY_T0MS_SIZE                                         1
#define AVR32_ERAY_T0RC                                              0
#define AVR32_ERAY_T0RC_MASK                                0x00000001
#define AVR32_ERAY_T0RC_OFFSET                                       0
#define AVR32_ERAY_T0RC_SIZE                                         1
#define AVR32_ERAY_T1C                                      0x00000048
#define AVR32_ERAY_T1C_MASK                                 0x3fff0003
#define AVR32_ERAY_T1C_RESETVALUE                           0x00000000
#define AVR32_ERAY_T1C_T1MC                                         16
#define AVR32_ERAY_T1C_T1MC_MASK                            0x3fff0000
#define AVR32_ERAY_T1C_T1MC_OFFSET                                  16
#define AVR32_ERAY_T1C_T1MC_SIZE                                    14
#define AVR32_ERAY_T1C_T1MS                                          1
#define AVR32_ERAY_T1C_T1MS_MASK                            0x00000002
#define AVR32_ERAY_T1C_T1MS_OFFSET                                   1
#define AVR32_ERAY_T1C_T1MS_SIZE                                     1
#define AVR32_ERAY_T1C_T1RC                                          0
#define AVR32_ERAY_T1C_T1RC_MASK                            0x00000001
#define AVR32_ERAY_T1C_T1RC_OFFSET                                   0
#define AVR32_ERAY_T1C_T1RC_SIZE                                     1
#define AVR32_ERAY_T1MC                                             16
#define AVR32_ERAY_T1MC_MASK                                0x3fff0000
#define AVR32_ERAY_T1MC_OFFSET                                      16
#define AVR32_ERAY_T1MC_SIZE                                        14
#define AVR32_ERAY_T1MS                                              1
#define AVR32_ERAY_T1MS_MASK                                0x00000002
#define AVR32_ERAY_T1MS_OFFSET                                       1
#define AVR32_ERAY_T1MS_SIZE                                         1
#define AVR32_ERAY_T1RC                                              0
#define AVR32_ERAY_T1RC_MASK                                0x00000001
#define AVR32_ERAY_T1RC_OFFSET                                       0
#define AVR32_ERAY_T1RC_SIZE                                         1
#define AVR32_ERAY_TABA                                             18
#define AVR32_ERAY_TABAE                                            18
#define AVR32_ERAY_TABAE_MASK                               0x00040000
#define AVR32_ERAY_TABAE_OFFSET                                     18
#define AVR32_ERAY_TABAE_SIZE                                        1
#define AVR32_ERAY_TABAL                                            18
#define AVR32_ERAY_TABAL_MASK                               0x00040000
#define AVR32_ERAY_TABAL_OFFSET                                     18
#define AVR32_ERAY_TABAL_SIZE                                        1
#define AVR32_ERAY_TABA_MASK                                0x00040000
#define AVR32_ERAY_TABA_OFFSET                                      18
#define AVR32_ERAY_TABA_SIZE                                         1
#define AVR32_ERAY_TABB                                             26
#define AVR32_ERAY_TABBE                                            26
#define AVR32_ERAY_TABBE_MASK                               0x04000000
#define AVR32_ERAY_TABBE_OFFSET                                     26
#define AVR32_ERAY_TABBE_SIZE                                        1
#define AVR32_ERAY_TABBL                                            26
#define AVR32_ERAY_TABBL_MASK                               0x04000000
#define AVR32_ERAY_TABBL_OFFSET                                     26
#define AVR32_ERAY_TABBL_SIZE                                        1
#define AVR32_ERAY_TABB_MASK                                0x04000000
#define AVR32_ERAY_TABB_OFFSET                                      26
#define AVR32_ERAY_TABB_SIZE                                         1
#define AVR32_ERAY_TBFA                                              4
#define AVR32_ERAY_TBFA_MASK                                0x00000010
#define AVR32_ERAY_TBFA_OFFSET                                       4
#define AVR32_ERAY_TBFA_SIZE                                         1
#define AVR32_ERAY_TBFB                                              5
#define AVR32_ERAY_TBFB_MASK                                0x00000020
#define AVR32_ERAY_TBFB_OFFSET                                       5
#define AVR32_ERAY_TBFB_SIZE                                         1
#define AVR32_ERAY_TCIA                                              8
#define AVR32_ERAY_TCIA_MASK                                0x00000100
#define AVR32_ERAY_TCIA_OFFSET                                       8
#define AVR32_ERAY_TCIA_SIZE                                         1
#define AVR32_ERAY_TCIB                                              9
#define AVR32_ERAY_TCIB_MASK                                0x00000200
#define AVR32_ERAY_TCIB_OFFSET                                       9
#define AVR32_ERAY_TCIB_SIZE                                         1
#define AVR32_ERAY_TCSA                                              2
#define AVR32_ERAY_TCSA_MASK                                0x00000004
#define AVR32_ERAY_TCSA_OFFSET                                       2
#define AVR32_ERAY_TCSA_SIZE                                         1
#define AVR32_ERAY_TCSB                                              5
#define AVR32_ERAY_TCSB_MASK                                0x00000020
#define AVR32_ERAY_TCSB_OFFSET                                       5
#define AVR32_ERAY_TCSB_SIZE                                         1
#define AVR32_ERAY_TEST1                                    0x00000010
#define AVR32_ERAY_TEST1_AOA                                         8
#define AVR32_ERAY_TEST1_AOA_MASK                           0x00000100
#define AVR32_ERAY_TEST1_AOA_OFFSET                                  8
#define AVR32_ERAY_TEST1_AOA_SIZE                                    1
#define AVR32_ERAY_TEST1_AOB                                         9
#define AVR32_ERAY_TEST1_AOB_MASK                           0x00000200
#define AVR32_ERAY_TEST1_AOB_OFFSET                                  9
#define AVR32_ERAY_TEST1_AOB_SIZE                                    1
#define AVR32_ERAY_TEST1_CERA                                       24
#define AVR32_ERAY_TEST1_CERA_MASK                          0x0f000000
#define AVR32_ERAY_TEST1_CERA_OFFSET                                24
#define AVR32_ERAY_TEST1_CERA_SIZE                                   4
#define AVR32_ERAY_TEST1_CERB                                       28
#define AVR32_ERAY_TEST1_CERB_MASK                          0xf0000000
#define AVR32_ERAY_TEST1_CERB_OFFSET                                28
#define AVR32_ERAY_TEST1_CERB_SIZE                                   4
#define AVR32_ERAY_TEST1_ELBE                                        1
#define AVR32_ERAY_TEST1_ELBE_MASK                          0x00000002
#define AVR32_ERAY_TEST1_ELBE_OFFSET                                 1
#define AVR32_ERAY_TEST1_ELBE_SIZE                                   1
#define AVR32_ERAY_TEST1_MASK                               0xff3f0333
#define AVR32_ERAY_TEST1_RESETVALUE                         0x00000000
#define AVR32_ERAY_TEST1_RXA                                        16
#define AVR32_ERAY_TEST1_RXA_MASK                           0x00010000
#define AVR32_ERAY_TEST1_RXA_OFFSET                                 16
#define AVR32_ERAY_TEST1_RXA_SIZE                                    1
#define AVR32_ERAY_TEST1_RXB                                        17
#define AVR32_ERAY_TEST1_RXB_MASK                           0x00020000
#define AVR32_ERAY_TEST1_RXB_OFFSET                                 17
#define AVR32_ERAY_TEST1_RXB_SIZE                                    1
#define AVR32_ERAY_TEST1_TMC                                         4
#define AVR32_ERAY_TEST1_TMC_MASK                           0x00000030
#define AVR32_ERAY_TEST1_TMC_OFFSET                                  4
#define AVR32_ERAY_TEST1_TMC_SIZE                                    2
#define AVR32_ERAY_TEST1_TXA                                        18
#define AVR32_ERAY_TEST1_TXA_MASK                           0x00040000
#define AVR32_ERAY_TEST1_TXA_OFFSET                                 18
#define AVR32_ERAY_TEST1_TXA_SIZE                                    1
#define AVR32_ERAY_TEST1_TXB                                        19
#define AVR32_ERAY_TEST1_TXB_MASK                           0x00080000
#define AVR32_ERAY_TEST1_TXB_OFFSET                                 19
#define AVR32_ERAY_TEST1_TXB_SIZE                                    1
#define AVR32_ERAY_TEST1_TXENA                                      20
#define AVR32_ERAY_TEST1_TXENA_MASK                         0x00100000
#define AVR32_ERAY_TEST1_TXENA_OFFSET                               20
#define AVR32_ERAY_TEST1_TXENA_SIZE                                  1
#define AVR32_ERAY_TEST1_TXENB                                      21
#define AVR32_ERAY_TEST1_TXENB_MASK                         0x00200000
#define AVR32_ERAY_TEST1_TXENB_OFFSET                               21
#define AVR32_ERAY_TEST1_TXENB_SIZE                                  1
#define AVR32_ERAY_TEST1_WRTEN                                       0
#define AVR32_ERAY_TEST1_WRTEN_MASK                         0x00000001
#define AVR32_ERAY_TEST1_WRTEN_OFFSET                                0
#define AVR32_ERAY_TEST1_WRTEN_SIZE                                  1
#define AVR32_ERAY_TEST2                                    0x00000014
#define AVR32_ERAY_TEST2_MASK                               0x0000c077
#define AVR32_ERAY_TEST2_RDPB                                       15
#define AVR32_ERAY_TEST2_RDPB_MASK                          0x00008000
#define AVR32_ERAY_TEST2_RDPB_OFFSET                                15
#define AVR32_ERAY_TEST2_RDPB_SIZE                                   1
#define AVR32_ERAY_TEST2_RESETVALUE                         0x00000000
#define AVR32_ERAY_TEST2_RS                                          0
#define AVR32_ERAY_TEST2_RS_MASK                            0x00000007
#define AVR32_ERAY_TEST2_RS_OFFSET                                   0
#define AVR32_ERAY_TEST2_RS_SIZE                                     3
#define AVR32_ERAY_TEST2_SSEL                                        4
#define AVR32_ERAY_TEST2_SSEL_MASK                          0x00000070
#define AVR32_ERAY_TEST2_SSEL_OFFSET                                 4
#define AVR32_ERAY_TEST2_SSEL_SIZE                                   3
#define AVR32_ERAY_TEST2_WRPB                                       14
#define AVR32_ERAY_TEST2_WRPB_MASK                          0x00004000
#define AVR32_ERAY_TEST2_WRPB_OFFSET                                14
#define AVR32_ERAY_TEST2_WRPB_SIZE                                   1
#define AVR32_ERAY_TI0                                               8
#define AVR32_ERAY_TI0E                                              8
#define AVR32_ERAY_TI0E_MASK                                0x00000100
#define AVR32_ERAY_TI0E_OFFSET                                       8
#define AVR32_ERAY_TI0E_SIZE                                         1
#define AVR32_ERAY_TI0L                                              8
#define AVR32_ERAY_TI0L_MASK                                0x00000100
#define AVR32_ERAY_TI0L_OFFSET                                       8
#define AVR32_ERAY_TI0L_SIZE                                         1
#define AVR32_ERAY_TI0_MASK                                 0x00000100
#define AVR32_ERAY_TI0_OFFSET                                        8
#define AVR32_ERAY_TI0_SIZE                                          1
#define AVR32_ERAY_TI1                                               9
#define AVR32_ERAY_TI1E                                              9
#define AVR32_ERAY_TI1E_MASK                                0x00000200
#define AVR32_ERAY_TI1E_OFFSET                                       9
#define AVR32_ERAY_TI1E_SIZE                                         1
#define AVR32_ERAY_TI1L                                              9
#define AVR32_ERAY_TI1L_MASK                                0x00000200
#define AVR32_ERAY_TI1L_OFFSET                                       9
#define AVR32_ERAY_TI1L_SIZE                                         1
#define AVR32_ERAY_TI1_MASK                                 0x00000200
#define AVR32_ERAY_TI1_OFFSET                                        9
#define AVR32_ERAY_TI1_SIZE                                          1
#define AVR32_ERAY_TIBC                                             10
#define AVR32_ERAY_TIBCE                                            10
#define AVR32_ERAY_TIBCE_MASK                               0x00000400
#define AVR32_ERAY_TIBCE_OFFSET                                     10
#define AVR32_ERAY_TIBCE_SIZE                                        1
#define AVR32_ERAY_TIBCL                                            10
#define AVR32_ERAY_TIBCL_MASK                               0x00000400
#define AVR32_ERAY_TIBCL_OFFSET                                     10
#define AVR32_ERAY_TIBCL_SIZE                                        1
#define AVR32_ERAY_TIBC_MASK                                0x00000400
#define AVR32_ERAY_TIBC_OFFSET                                      10
#define AVR32_ERAY_TIBC_SIZE                                         1
#define AVR32_ERAY_TMC                                               4
#define AVR32_ERAY_TMC_MASK                                 0x00000030
#define AVR32_ERAY_TMC_OFFSET                                        4
#define AVR32_ERAY_TMC_SIZE                                          2
#define AVR32_ERAY_TMK                                               8
#define AVR32_ERAY_TMK_MASK                                 0x0000ff00
#define AVR32_ERAY_TMK_OFFSET                                        8
#define AVR32_ERAY_TMK_SIZE                                          8
#define AVR32_ERAY_TNSA                                              6
#define AVR32_ERAY_TNSA_MASK                                0x00000040
#define AVR32_ERAY_TNSA_OFFSET                                       6
#define AVR32_ERAY_TNSA_SIZE                                         1
#define AVR32_ERAY_TNSB                                              7
#define AVR32_ERAY_TNSB_MASK                                0x00000080
#define AVR32_ERAY_TNSB_OFFSET                                       7
#define AVR32_ERAY_TNSB_SIZE                                         1
#define AVR32_ERAY_TOBC                                             11
#define AVR32_ERAY_TOBCE                                            11
#define AVR32_ERAY_TOBCE_MASK                               0x00000800
#define AVR32_ERAY_TOBCE_OFFSET                                     11
#define AVR32_ERAY_TOBCE_SIZE                                        1
#define AVR32_ERAY_TOBCL                                            11
#define AVR32_ERAY_TOBCL_MASK                               0x00000800
#define AVR32_ERAY_TOBCL_OFFSET                                     11
#define AVR32_ERAY_TOBCL_SIZE                                        1
#define AVR32_ERAY_TOBC_MASK                                0x00000800
#define AVR32_ERAY_TOBC_OFFSET                                      11
#define AVR32_ERAY_TOBC_SIZE                                         1
#define AVR32_ERAY_TSM                                              22
#define AVR32_ERAY_TSM_MASK                                 0x00400000
#define AVR32_ERAY_TSM_OFFSET                                       22
#define AVR32_ERAY_TSM_SIZE                                          1
#define AVR32_ERAY_TSR                                      0x0000080c
#define AVR32_ERAY_TSR_MASK                                 0xffffffff
#define AVR32_ERAY_TSR_RESETVALUE                           0x00000000
#define AVR32_ERAY_TSR_STAT1                                         0
#define AVR32_ERAY_TSR_STAT1_MASK                           0x0000ffff
#define AVR32_ERAY_TSR_STAT1_OFFSET                                  0
#define AVR32_ERAY_TSR_STAT1_SIZE                                   16
#define AVR32_ERAY_TSR_STAT2                                        16
#define AVR32_ERAY_TSR_STAT2_MASK                           0xffff0000
#define AVR32_ERAY_TSR_STAT2_OFFSET                                 16
#define AVR32_ERAY_TSR_STAT2_SIZE                                   16
#define AVR32_ERAY_TSST                                              0
#define AVR32_ERAY_TSST_MASK                                0x0000000f
#define AVR32_ERAY_TSST_OFFSET                                       0
#define AVR32_ERAY_TSST_SIZE                                         4
#define AVR32_ERAY_TXA                                              18
#define AVR32_ERAY_TXA_MASK                                 0x00040000
#define AVR32_ERAY_TXA_OFFSET                                       18
#define AVR32_ERAY_TXA_SIZE                                          1
#define AVR32_ERAY_TXB                                              19
#define AVR32_ERAY_TXB_MASK                                 0x00080000
#define AVR32_ERAY_TXB_OFFSET                                       19
#define AVR32_ERAY_TXB_SIZE                                          1
#define AVR32_ERAY_TXENA                                            20
#define AVR32_ERAY_TXENA_MASK                               0x00100000
#define AVR32_ERAY_TXENA_OFFSET                                     20
#define AVR32_ERAY_TXENA_SIZE                                        1
#define AVR32_ERAY_TXENB                                            21
#define AVR32_ERAY_TXENB_MASK                               0x00200000
#define AVR32_ERAY_TXENB_OFFSET                                     21
#define AVR32_ERAY_TXENB_SIZE                                        1
#define AVR32_ERAY_TXIE                                              3
#define AVR32_ERAY_TXIE_MASK                                0x00000008
#define AVR32_ERAY_TXIE_OFFSET                                       3
#define AVR32_ERAY_TXIE_SIZE                                         1
#define AVR32_ERAY_TXIL                                              3
#define AVR32_ERAY_TXIL_MASK                                0x00000008
#define AVR32_ERAY_TXIL_OFFSET                                       3
#define AVR32_ERAY_TXIL_SIZE                                         1
#define AVR32_ERAY_TXL                                              24
#define AVR32_ERAY_TXL_MASK                                 0x3f000000
#define AVR32_ERAY_TXL_OFFSET                                       24
#define AVR32_ERAY_TXL_SIZE                                          6
#define AVR32_ERAY_TXM                                              28
#define AVR32_ERAY_TXM_MASK                                 0x10000000
#define AVR32_ERAY_TXM_OFFSET                                       28
#define AVR32_ERAY_TXM_SIZE                                          1
#define AVR32_ERAY_TXR                                               0
#define AVR32_ERAY_TXRQ1                                    0x00000320
#define AVR32_ERAY_TXRQ1_MASK                               0xffffffff
#define AVR32_ERAY_TXRQ1_RESETVALUE                         0x00000000
#define AVR32_ERAY_TXRQ1_TXR                                         0
#define AVR32_ERAY_TXRQ1_TXR_MASK                           0xffffffff
#define AVR32_ERAY_TXRQ1_TXR_OFFSET                                  0
#define AVR32_ERAY_TXRQ1_TXR_SIZE                                   32
#define AVR32_ERAY_TXRQ2                                    0x00000324
#define AVR32_ERAY_TXRQ2_MASK                               0xffffffff
#define AVR32_ERAY_TXRQ2_RESETVALUE                         0x00000000
#define AVR32_ERAY_TXRQ2_TXR                                         0
#define AVR32_ERAY_TXRQ2_TXR_MASK                           0xffffffff
#define AVR32_ERAY_TXRQ2_TXR_OFFSET                                  0
#define AVR32_ERAY_TXRQ2_TXR_SIZE                                   32
#define AVR32_ERAY_TXRQ3                                    0x00000328
#define AVR32_ERAY_TXRQ3_MASK                               0xffffffff
#define AVR32_ERAY_TXRQ3_RESETVALUE                         0x00000000
#define AVR32_ERAY_TXRQ3_TXR                                         0
#define AVR32_ERAY_TXRQ3_TXR_MASK                           0xffffffff
#define AVR32_ERAY_TXRQ3_TXR_OFFSET                                  0
#define AVR32_ERAY_TXRQ3_TXR_SIZE                                   32
#define AVR32_ERAY_TXRQ4                                    0x0000032c
#define AVR32_ERAY_TXRQ4_MASK                               0xffffffff
#define AVR32_ERAY_TXRQ4_RESETVALUE                         0x00000000
#define AVR32_ERAY_TXRQ4_TXR                                         0
#define AVR32_ERAY_TXRQ4_TXR_MASK                           0xffffffff
#define AVR32_ERAY_TXRQ4_TXR_OFFSET                                  0
#define AVR32_ERAY_TXRQ4_TXR_SIZE                                   32
#define AVR32_ERAY_TXR_MASK                                 0xffffffff
#define AVR32_ERAY_TXR_OFFSET                                        0
#define AVR32_ERAY_TXR_SIZE                                         32
#define AVR32_ERAY_TXST                                              8
#define AVR32_ERAY_TXST_MASK                                0x00000100
#define AVR32_ERAY_TXST_OFFSET                                       8
#define AVR32_ERAY_TXST_SIZE                                         1
#define AVR32_ERAY_TXSY                                              9
#define AVR32_ERAY_TXSY_MASK                                0x00000200
#define AVR32_ERAY_TXSY_OFFSET                                       9
#define AVR32_ERAY_TXSY_SIZE                                         1
#define AVR32_ERAY_UIOA                                              0
#define AVR32_ERAY_UIOA_MASK                                0x000000ff
#define AVR32_ERAY_UIOA_OFFSET                                       0
#define AVR32_ERAY_UIOA_SIZE                                         8
#define AVR32_ERAY_UIOB                                              8
#define AVR32_ERAY_UIOB_MASK                                0x0000ff00
#define AVR32_ERAY_UIOB_OFFSET                                       8
#define AVR32_ERAY_UIOB_SIZE                                         8
#define AVR32_ERAY_UT                                                0
#define AVR32_ERAY_UT_MASK                                  0x000fffff
#define AVR32_ERAY_UT_OFFSET                                         0
#define AVR32_ERAY_UT_SIZE                                          20
#define AVR32_ERAY_VER                                               0
#define AVR32_ERAY_VERSION                                  0x00000000
#define AVR32_ERAY_VERSION_FIXNO                                    16
#define AVR32_ERAY_VERSION_FIXNO_MASK                       0x00070000
#define AVR32_ERAY_VERSION_FIXNO_OFFSET                             16
#define AVR32_ERAY_VERSION_FIXNO_SIZE                                3
#define AVR32_ERAY_VERSION_IFVER                                    12
#define AVR32_ERAY_VERSION_IFVER_MASK                       0x0000f000
#define AVR32_ERAY_VERSION_IFVER_OFFSET                             12
#define AVR32_ERAY_VERSION_IFVER_SIZE                                4
#define AVR32_ERAY_VERSION_MASK                             0x0007ffff
#define AVR32_ERAY_VERSION_RESETVALUE                       0x00000000
#define AVR32_ERAY_VERSION_VER                                       0
#define AVR32_ERAY_VERSION_VER_MASK                         0x00000fff
#define AVR32_ERAY_VERSION_VER_OFFSET                                0
#define AVR32_ERAY_VERSION_VER_SIZE                                 12
#define AVR32_ERAY_VER_MASK                                 0x00000fff
#define AVR32_ERAY_VER_OFFSET                                        0
#define AVR32_ERAY_VER_SIZE                                         12
#define AVR32_ERAY_VFRA                                              0
#define AVR32_ERAY_VFRA_MASK                                0x00000001
#define AVR32_ERAY_VFRA_OFFSET                                       0
#define AVR32_ERAY_VFRA_SIZE                                         1
#define AVR32_ERAY_VFRB_SIZE                                         1
#define AVR32_ERAY_VIEW                                              8
#define AVR32_ERAY_VIEW_MASK                                0x00000100
#define AVR32_ERAY_VIEW_OFFSET                                       8
#define AVR32_ERAY_VIEW_SIZE                                         1
#define AVR32_ERAY_VSAE                                              0
#define AVR32_ERAY_VSAE_MASK                                0x0000000f
#define AVR32_ERAY_VSAE_OFFSET                                       0
#define AVR32_ERAY_VSAE_SIZE                                         4
#define AVR32_ERAY_VSAO                                              4
#define AVR32_ERAY_VSAO_MASK                                0x000000f0
#define AVR32_ERAY_VSAO_OFFSET                                       4
#define AVR32_ERAY_VSAO_SIZE                                         4
#define AVR32_ERAY_VSBE                                              8
#define AVR32_ERAY_VSBE_MASK                                0x00000f00
#define AVR32_ERAY_VSBE_OFFSET                                       8
#define AVR32_ERAY_VSBE_SIZE                                         4
#define AVR32_ERAY_VSBO                                             12
#define AVR32_ERAY_VSBO_MASK                                0x0000f000
#define AVR32_ERAY_VSBO_OFFSET                                      12
#define AVR32_ERAY_VSBO_SIZE                                         4
#define AVR32_ERAY_WAHP                                              8
#define AVR32_ERAY_WAHP_MASK                                0x00000100
#define AVR32_ERAY_WAHP_OFFSET                                       8
#define AVR32_ERAY_WAHP_SIZE                                         1
#define AVR32_ERAY_WCF                                               4
#define AVR32_ERAY_WCF_MASK                                 0x000000f0
#define AVR32_ERAY_WCF_OFFSET                                        4
#define AVR32_ERAY_WCF_SIZE                                          4
#define AVR32_ERAY_WCP                                               0
#define AVR32_ERAY_WCP_MASK                                 0x0000000f
#define AVR32_ERAY_WCP_OFFSET                                        0
#define AVR32_ERAY_WCP_SIZE                                          4
#define AVR32_ERAY_WRDS                                     0x00000400
#define AVR32_ERAY_WRDS_MASK                                0x00000000
#define AVR32_ERAY_WRDS_RESETVALUE                          0x00000000
#define AVR32_ERAY_WRHS1                                    0x00000500
#define AVR32_ERAY_WRHS1_CFG                                        26
#define AVR32_ERAY_WRHS1_CFG_MASK                           0x04000000
#define AVR32_ERAY_WRHS1_CFG_OFFSET                                 26
#define AVR32_ERAY_WRHS1_CFG_SIZE                                    1
#define AVR32_ERAY_WRHS1_CHA                                        24
#define AVR32_ERAY_WRHS1_CHA_MASK                           0x01000000
#define AVR32_ERAY_WRHS1_CHA_OFFSET                                 24
#define AVR32_ERAY_WRHS1_CHA_SIZE                                    1
#define AVR32_ERAY_WRHS1_CHB                                        25
#define AVR32_ERAY_WRHS1_CHB_MASK                           0x02000000
#define AVR32_ERAY_WRHS1_CHB_OFFSET                                 25
#define AVR32_ERAY_WRHS1_CHB_SIZE                                    1
#define AVR32_ERAY_WRHS1_CYC                                        16
#define AVR32_ERAY_WRHS1_CYC_MASK                           0x007f0000
#define AVR32_ERAY_WRHS1_CYC_OFFSET                                 16
#define AVR32_ERAY_WRHS1_CYC_SIZE                                    7
#define AVR32_ERAY_WRHS1_FID                                         0
#define AVR32_ERAY_WRHS1_FID_MASK                           0x000007ff
#define AVR32_ERAY_WRHS1_FID_OFFSET                                  0
#define AVR32_ERAY_WRHS1_FID_SIZE                                   11
#define AVR32_ERAY_WRHS1_MASK                               0x3f7f07ff
#define AVR32_ERAY_WRHS1_MBI                                        29
#define AVR32_ERAY_WRHS1_MBI_MASK                           0x20000000
#define AVR32_ERAY_WRHS1_MBI_OFFSET                                 29
#define AVR32_ERAY_WRHS1_MBI_SIZE                                    1
#define AVR32_ERAY_WRHS1_PPIT                                       27
#define AVR32_ERAY_WRHS1_PPIT_MASK                          0x08000000
#define AVR32_ERAY_WRHS1_PPIT_OFFSET                                27
#define AVR32_ERAY_WRHS1_PPIT_SIZE                                   1
#define AVR32_ERAY_WRHS1_RESETVALUE                         0x00000000
#define AVR32_ERAY_WRHS1_TXM                                        28
#define AVR32_ERAY_WRHS1_TXM_MASK                           0x10000000
#define AVR32_ERAY_WRHS1_TXM_OFFSET                                 28
#define AVR32_ERAY_WRHS1_TXM_SIZE                                    1
#define AVR32_ERAY_WRHS2                                    0x00000504
#define AVR32_ERAY_WRHS2_CRC                                         0
#define AVR32_ERAY_WRHS2_CRC_MASK                           0x000007ff
#define AVR32_ERAY_WRHS2_CRC_OFFSET                                  0
#define AVR32_ERAY_WRHS2_CRC_SIZE                                   11
#define AVR32_ERAY_WRHS2_MASK                               0x007f07ff
#define AVR32_ERAY_WRHS2_PLC                                        16
#define AVR32_ERAY_WRHS2_PLC_MASK                           0x007f0000
#define AVR32_ERAY_WRHS2_PLC_OFFSET                                 16
#define AVR32_ERAY_WRHS2_PLC_SIZE                                    7
#define AVR32_ERAY_WRHS2_RESETVALUE                         0x00000000
#define AVR32_ERAY_WRHS3                                    0x00000508
#define AVR32_ERAY_WRHS3_DP                                          0
#define AVR32_ERAY_WRHS3_DP_MASK                            0x000007ff
#define AVR32_ERAY_WRHS3_DP_OFFSET                                   0
#define AVR32_ERAY_WRHS3_DP_SIZE                                    11
#define AVR32_ERAY_WRHS3_MASK                               0x000007ff
#define AVR32_ERAY_WRHS3_RESETVALUE                         0x00000000
#define AVR32_ERAY_WRPB                                             14
#define AVR32_ERAY_WRPB_MASK                                0x00004000
#define AVR32_ERAY_WRPB_OFFSET                                      14
#define AVR32_ERAY_WRPB_SIZE                                         1
#define AVR32_ERAY_WRTEN                                             0
#define AVR32_ERAY_WRTEN_MASK                               0x00000001
#define AVR32_ERAY_WRTEN_OFFSET                                      0
#define AVR32_ERAY_WRTEN_SIZE                                        1
#define AVR32_ERAY_WST                                               0
#define AVR32_ERAY_WSTE                                              0
#define AVR32_ERAY_WSTE_MASK                                0x00000001
#define AVR32_ERAY_WSTE_OFFSET                                       0
#define AVR32_ERAY_WSTE_SIZE                                         1
#define AVR32_ERAY_WSTL                                              0
#define AVR32_ERAY_WSTL_MASK                                0x00000001
#define AVR32_ERAY_WSTL_OFFSET                                       0
#define AVR32_ERAY_WSTL_SIZE                                         1
#define AVR32_ERAY_WST_MASK                                 0x00000001
#define AVR32_ERAY_WST_OFFSET                                        0
#define AVR32_ERAY_WST_SIZE                                          1
#define AVR32_ERAY_WSV                                              16
#define AVR32_ERAY_WSV_MASK                                 0x00070000
#define AVR32_ERAY_WSV_OFFSET                                       16
#define AVR32_ERAY_WSV_SIZE                                          3
#define AVR32_ERAY_WUCS                                             21
#define AVR32_ERAY_WUCS_MASK                                0x00200000
#define AVR32_ERAY_WUCS_OFFSET                                      21
#define AVR32_ERAY_WUCS_SIZE                                         1
#define AVR32_ERAY_WUPA                                             16
#define AVR32_ERAY_WUPAE                                            16
#define AVR32_ERAY_WUPAE_MASK                               0x00010000
#define AVR32_ERAY_WUPAE_OFFSET                                     16
#define AVR32_ERAY_WUPAE_SIZE                                        1
#define AVR32_ERAY_WUPAL                                            16
#define AVR32_ERAY_WUPAL_MASK                               0x00010000
#define AVR32_ERAY_WUPAL_OFFSET                                     16
#define AVR32_ERAY_WUPAL_SIZE                                        1
#define AVR32_ERAY_WUPA_MASK                                0x00010000
#define AVR32_ERAY_WUPA_OFFSET                                      16
#define AVR32_ERAY_WUPA_SIZE                                         1
#define AVR32_ERAY_WUPB                                             24
#define AVR32_ERAY_WUPBE                                            24
#define AVR32_ERAY_WUPBE_MASK                               0x01000000
#define AVR32_ERAY_WUPBE_OFFSET                                     24
#define AVR32_ERAY_WUPBE_SIZE                                        1
#define AVR32_ERAY_WUPBL                                            24
#define AVR32_ERAY_WUPBL_MASK                               0x01000000
#define AVR32_ERAY_WUPBL_OFFSET                                     24
#define AVR32_ERAY_WUPBL_SIZE                                        1
#define AVR32_ERAY_WUPB_MASK                                0x01000000
#define AVR32_ERAY_WUPB_OFFSET                                      24
#define AVR32_ERAY_WUPB_SIZE                                         1
#define AVR32_ERAY_YEAR                                             16
#define AVR32_ERAY_YEAR_MASK                                0x000f0000
#define AVR32_ERAY_YEAR_OFFSET                                      16
#define AVR32_ERAY_YEAR_SIZE                                         4




#ifdef __AVR32_ABI_COMPILER__


typedef struct avr32_eray_version_t {
    unsigned int                 :13;
    unsigned int fixno           : 3;
    unsigned int ifver           : 4;
    unsigned int ver             :12;
} avr32_eray_version_t;



typedef struct avr32_eray_test1_t {
    unsigned int cerb            : 4;
    unsigned int cera            : 4;
    unsigned int                 : 2;
    unsigned int txenb           : 1;
    unsigned int txena           : 1;
    unsigned int txb             : 1;
    unsigned int txa             : 1;
    unsigned int rxb             : 1;
    unsigned int rxa             : 1;
    unsigned int                 : 6;
    unsigned int aob             : 1;
    unsigned int aoa             : 1;
    unsigned int                 : 2;
    unsigned int tmc             : 2;
    unsigned int                 : 2;
    unsigned int elbe            : 1;
    unsigned int wrten           : 1;
} avr32_eray_test1_t;



typedef struct avr32_eray_test2_t {
    unsigned int                 :16;
    unsigned int rdpb            : 1;
    unsigned int wrpb            : 1;
    unsigned int                 : 7;
    unsigned int ssel            : 3;
    unsigned int                 : 1;
    unsigned int rs              : 3;
} avr32_eray_test2_t;



typedef struct avr32_eray_lck_t {
    unsigned int                 :16;
    unsigned int tmk             : 8;
    unsigned int clk             : 8;
} avr32_eray_lck_t;



typedef struct avr32_eray_eir_t {
    unsigned int                 : 5;
    unsigned int tabb            : 1;
    unsigned int ltvb            : 1;
    unsigned int edb             : 1;
    unsigned int                 : 5;
    unsigned int taba            : 1;
    unsigned int ltva            : 1;
    unsigned int eda             : 1;
    unsigned int                 : 4;
    unsigned int mhf             : 1;
    unsigned int ioba            : 1;
    unsigned int iiba            : 1;
    unsigned int efa             : 1;
    unsigned int rfo             : 1;
    unsigned int perr            : 1;
    unsigned int ccl             : 1;
    unsigned int ccf             : 1;
    unsigned int sfo             : 1;
    unsigned int sfbm            : 1;
    unsigned int cna             : 1;
    unsigned int pemc            : 1;
} avr32_eray_eir_t;



typedef struct avr32_eray_sir_t {
    unsigned int                 : 6;
    unsigned int mtsb            : 1;
    unsigned int wupb            : 1;
    unsigned int                 : 6;
    unsigned int mtsa            : 1;
    unsigned int wupa            : 1;
    unsigned int sds             : 1;
    unsigned int mbsi            : 1;
    unsigned int sucs            : 1;
    unsigned int swe             : 1;
    unsigned int tobc            : 1;
    unsigned int tibc            : 1;
    unsigned int ti1             : 1;
    unsigned int ti0             : 1;
    unsigned int nmvc            : 1;
    unsigned int rfcl            : 1;
    unsigned int rfne            : 1;
    unsigned int rxi             : 1;
    unsigned int txi             : 1;
    unsigned int cycs            : 1;
    unsigned int cas             : 1;
    unsigned int wst             : 1;
} avr32_eray_sir_t;



typedef struct avr32_eray_eils_t {
    unsigned int                 : 5;
    unsigned int tabbl           : 1;
    unsigned int ltvbl           : 1;
    unsigned int edbl            : 1;
    unsigned int                 : 5;
    unsigned int tabal           : 1;
    unsigned int ltval           : 1;
    unsigned int edal            : 1;
    unsigned int                 : 4;
    unsigned int mhfl            : 1;
    unsigned int iobal           : 1;
    unsigned int iibal           : 1;
    unsigned int efal            : 1;
    unsigned int rfol            : 1;
    unsigned int perrl           : 1;
    unsigned int ccll            : 1;
    unsigned int ccfl            : 1;
    unsigned int sfol            : 1;
    unsigned int sfbml           : 1;
    unsigned int cnal            : 1;
    unsigned int pemcl           : 1;
} avr32_eray_eils_t;



typedef struct avr32_eray_sils_t {
    unsigned int                 : 6;
    unsigned int mtsbl           : 1;
    unsigned int wupbl           : 1;
    unsigned int                 : 6;
    unsigned int mtsal           : 1;
    unsigned int wupal           : 1;
    unsigned int sdsl            : 1;
    unsigned int mbsil           : 1;
    unsigned int sucsl           : 1;
    unsigned int swel            : 1;
    unsigned int tobcl           : 1;
    unsigned int tibcl           : 1;
    unsigned int ti1l            : 1;
    unsigned int ti0l            : 1;
    unsigned int nmvcl           : 1;
    unsigned int rfcll           : 1;
    unsigned int rfnel           : 1;
    unsigned int rxil            : 1;
    unsigned int txil            : 1;
    unsigned int cycsl           : 1;
    unsigned int casl            : 1;
    unsigned int wstl            : 1;
} avr32_eray_sils_t;



typedef struct avr32_eray_eies_t {
    unsigned int                 : 5;
    unsigned int tabbe           : 1;
    unsigned int ltvbe           : 1;
    unsigned int edbe            : 1;
    unsigned int                 : 5;
    unsigned int tabae           : 1;
    unsigned int ltvae           : 1;
    unsigned int edae            : 1;
    unsigned int                 : 4;
    unsigned int mhfe            : 1;
    unsigned int iobae           : 1;
    unsigned int iibae           : 1;
    unsigned int efae            : 1;
    unsigned int rfoe            : 1;
    unsigned int perre           : 1;
    unsigned int ccle            : 1;
    unsigned int ccfe            : 1;
    unsigned int sfoe            : 1;
    unsigned int sfbme           : 1;
    unsigned int cnae            : 1;
    unsigned int pemce           : 1;
} avr32_eray_eies_t;



typedef struct avr32_eray_eier_t {
    unsigned int                 : 5;
    unsigned int tabbe           : 1;
    unsigned int ltvbe           : 1;
    unsigned int edbe            : 1;
    unsigned int                 : 5;
    unsigned int tabae           : 1;
    unsigned int ltvae           : 1;
    unsigned int edae            : 1;
    unsigned int                 : 4;
    unsigned int mhfe            : 1;
    unsigned int iobae           : 1;
    unsigned int iibae           : 1;
    unsigned int efae            : 1;
    unsigned int rfoe            : 1;
    unsigned int perre           : 1;
    unsigned int ccle            : 1;
    unsigned int ccfe            : 1;
    unsigned int sfoe            : 1;
    unsigned int sfbme           : 1;
    unsigned int cnae            : 1;
    unsigned int pemce           : 1;
} avr32_eray_eier_t;



typedef struct avr32_eray_sies_t {
    unsigned int                 : 6;
    unsigned int mtsbe           : 1;
    unsigned int wupbe           : 1;
    unsigned int                 : 6;
    unsigned int mtsae           : 1;
    unsigned int wupae           : 1;
    unsigned int sdse            : 1;
    unsigned int mbsie           : 1;
    unsigned int sucse           : 1;
    unsigned int swee            : 1;
    unsigned int tobce           : 1;
    unsigned int tibce           : 1;
    unsigned int ti1e            : 1;
    unsigned int ti0e            : 1;
    unsigned int nmvce           : 1;
    unsigned int rfcle           : 1;
    unsigned int rfnee           : 1;
    unsigned int rxie            : 1;
    unsigned int txie            : 1;
    unsigned int cycse           : 1;
    unsigned int case_           : 1;
    unsigned int wste            : 1;
} avr32_eray_sies_t;



typedef struct avr32_eray_sier_t {
    unsigned int                 : 6;
    unsigned int mtsbe           : 1;
    unsigned int wupbe           : 1;
    unsigned int                 : 6;
    unsigned int mtsae           : 1;
    unsigned int wupae           : 1;
    unsigned int sdse            : 1;
    unsigned int mbsie           : 1;
    unsigned int sucse           : 1;
    unsigned int swee            : 1;
    unsigned int tobce           : 1;
    unsigned int tibce           : 1;
    unsigned int ti1e            : 1;
    unsigned int ti0e            : 1;
    unsigned int nmvce           : 1;
    unsigned int rfcle           : 1;
    unsigned int rfnee           : 1;
    unsigned int rxie            : 1;
    unsigned int txie            : 1;
    unsigned int cycse           : 1;
    unsigned int case_           : 1;
    unsigned int wste            : 1;
} avr32_eray_sier_t;



typedef struct avr32_eray_ile_t {
    unsigned int                 :30;
    unsigned int eint1           : 1;
    unsigned int eint0           : 1;
} avr32_eray_ile_t;



typedef struct avr32_eray_t0c_t {
    unsigned int                 : 2;
    unsigned int t0mo            :14;
    unsigned int                 : 1;
    unsigned int t0cc            : 7;
    unsigned int                 : 6;
    unsigned int t0ms            : 1;
    unsigned int t0rc            : 1;
} avr32_eray_t0c_t;



typedef struct avr32_eray_t1c_t {
    unsigned int                 : 2;
    unsigned int t1mc            :14;
    unsigned int                 :14;
    unsigned int t1ms            : 1;
    unsigned int t1rc            : 1;
} avr32_eray_t1c_t;



typedef struct avr32_eray_stpw1_t {
    unsigned int                 : 2;
    unsigned int smtv            :14;
    unsigned int                 : 2;
    unsigned int sccv            : 6;
    unsigned int                 : 1;
    unsigned int eint1           : 1;
    unsigned int eint0           : 1;
    unsigned int eetp            : 1;
    unsigned int sswt            : 1;
    unsigned int edge            : 1;
    unsigned int swms            : 1;
    unsigned int eswt            : 1;
} avr32_eray_stpw1_t;



typedef struct avr32_eray_stpw2_t {
    unsigned int                 : 5;
    unsigned int sscvb           :11;
    unsigned int                 : 5;
    unsigned int sscva           :11;
} avr32_eray_stpw2_t;



typedef struct avr32_eray_succ1_t {
    unsigned int                 : 4;
    unsigned int cchb            : 1;
    unsigned int ccha            : 1;
    unsigned int mtsb            : 1;
    unsigned int mtsa            : 1;
    unsigned int hcse            : 1;
    unsigned int tsm             : 1;
    unsigned int wucs            : 1;
    unsigned int pta             : 5;
    unsigned int csa             : 5;
    unsigned int                 : 1;
    unsigned int txsy            : 1;
    unsigned int txst            : 1;
    unsigned int pbsy            : 1;
    unsigned int                 : 3;
    unsigned int cmd             : 4;
} avr32_eray_succ1_t;



typedef struct avr32_eray_succ2_t {
    unsigned int                 : 4;
    unsigned int ltn             : 4;
    unsigned int                 : 3;
    unsigned int lt              :21;
} avr32_eray_succ2_t;



typedef struct avr32_eray_succ3_t {
    unsigned int                 :24;
    unsigned int wcf             : 4;
    unsigned int wcp             : 4;
} avr32_eray_succ3_t;



typedef struct avr32_eray_nemc_t {
    unsigned int                 :28;
    unsigned int nml             : 4;
} avr32_eray_nemc_t;



typedef struct avr32_eray_prtc1_t {
    unsigned int rwp             : 6;
    unsigned int                 : 1;
    unsigned int rxw             : 9;
    unsigned int brp             : 2;
    unsigned int spp             : 2;
    unsigned int                 : 1;
    unsigned int casm            : 7;
    unsigned int tsst            : 4;
} avr32_eray_prtc1_t;



typedef struct avr32_eray_prtc2_t {
    unsigned int                 : 2;
    unsigned int txl             : 6;
    unsigned int txi             : 8;
    unsigned int                 : 2;
    unsigned int rxl             : 6;
    unsigned int                 : 2;
    unsigned int rxi             : 6;
} avr32_eray_prtc2_t;



typedef struct avr32_eray_mhdc_t {
    unsigned int                 : 3;
    unsigned int slt             :13;
    unsigned int                 : 9;
    unsigned int sfdl            : 7;
} avr32_eray_mhdc_t;



typedef struct avr32_eray_gtuc1_t {
    unsigned int                 :12;
    unsigned int ut              :20;
} avr32_eray_gtuc1_t;



typedef struct avr32_eray_gtuc2_t {
    unsigned int                 :12;
    unsigned int snm             : 4;
    unsigned int                 : 2;
    unsigned int mpc             :14;
} avr32_eray_gtuc2_t;



typedef struct avr32_eray_gtuc3_t {
    unsigned int                 : 1;
    unsigned int miob            : 7;
    unsigned int                 : 1;
    unsigned int mioa            : 7;
    unsigned int uiob            : 8;
    unsigned int uioa            : 8;
} avr32_eray_gtuc3_t;



typedef struct avr32_eray_gtuc4_t {
    unsigned int                 : 2;
    unsigned int ocs             :14;
    unsigned int                 : 2;
    unsigned int nit             :14;
} avr32_eray_gtuc4_t;



typedef struct avr32_eray_gtuc5_t {
    unsigned int dec             : 8;
    unsigned int                 : 3;
    unsigned int cdd             : 5;
    unsigned int dcb             : 8;
    unsigned int dca             : 8;
} avr32_eray_gtuc5_t;



typedef struct avr32_eray_gtuc6_t {
    unsigned int                 : 5;
    unsigned int mod             :11;
    unsigned int                 : 5;
    unsigned int asr             :11;
} avr32_eray_gtuc6_t;



typedef struct avr32_eray_gtuc7_t {
    unsigned int                 : 6;
    unsigned int nss             :10;
    unsigned int                 : 6;
    unsigned int ssl             :10;
} avr32_eray_gtuc7_t;



typedef struct avr32_eray_gtuc8_t {
    unsigned int                 : 3;
    unsigned int nms             :13;
    unsigned int                 :10;
    unsigned int msl             : 6;
} avr32_eray_gtuc8_t;



typedef struct avr32_eray_gtuc9_t {
    unsigned int                 :14;
    unsigned int dsi             : 2;
    unsigned int                 : 3;
    unsigned int mapo            : 5;
    unsigned int                 : 2;
    unsigned int apo             : 6;
} avr32_eray_gtuc9_t;



typedef struct avr32_eray_gtuc10_t {
    unsigned int                 : 5;
    unsigned int mrc             :11;
    unsigned int                 : 2;
    unsigned int moc             :14;
} avr32_eray_gtuc10_t;



typedef struct avr32_eray_gtuc11_t {
    unsigned int                 : 5;
    unsigned int erc             : 3;
    unsigned int                 : 5;
    unsigned int eoc             : 3;
    unsigned int                 : 6;
    unsigned int ercc            : 2;
    unsigned int                 : 6;
    unsigned int eocc            : 2;
} avr32_eray_gtuc11_t;



typedef struct avr32_eray_ccsv_t {
    unsigned int                 : 2;
    unsigned int psl             : 6;
    unsigned int rca             : 5;
    unsigned int wsv             : 3;
    unsigned int                 : 1;
    unsigned int csi             : 1;
    unsigned int csai            : 1;
    unsigned int csni            : 1;
    unsigned int                 : 2;
    unsigned int slm             : 2;
    unsigned int hrq             : 1;
    unsigned int fsi             : 1;
    unsigned int pocs            : 6;
} avr32_eray_ccsv_t;



typedef struct avr32_eray_ccev_t {
    unsigned int                 :19;
    unsigned int ptac            : 5;
    unsigned int errm            : 2;
    unsigned int                 : 2;
    unsigned int ccfc            : 4;
} avr32_eray_ccev_t;



typedef struct avr32_eray_scv_t {
    unsigned int                 : 5;
    unsigned int sccb            :11;
    unsigned int                 : 5;
    unsigned int scca            :11;
} avr32_eray_scv_t;



typedef struct avr32_eray_mtccv_t {
    unsigned int                 :10;
    unsigned int ccv             : 6;
    unsigned int                 : 2;
    unsigned int mtv             :14;
} avr32_eray_mtccv_t;



typedef struct avr32_eray_rcv_t {
    unsigned int                 :20;
    unsigned int rcv             :12;
} avr32_eray_rcv_t;



typedef struct avr32_eray_ocv_t {
    unsigned int                 :13;
    unsigned int ocv             :19;
} avr32_eray_ocv_t;



typedef struct avr32_eray_sfs_t {
    unsigned int                 :12;
    unsigned int rclr            : 1;
    unsigned int mrcs            : 1;
    unsigned int oclr            : 1;
    unsigned int mocs            : 1;
    unsigned int vsbo            : 4;
    unsigned int vsbe            : 4;
    unsigned int vsao            : 4;
    unsigned int vsae            : 4;
} avr32_eray_sfs_t;



typedef struct avr32_eray_swnit_t {
    unsigned int                 :20;
    unsigned int sbnb            : 1;
    unsigned int senb            : 1;
    unsigned int sbna            : 1;
    unsigned int sena            : 1;
    unsigned int mtsb            : 1;
    unsigned int mtsa            : 1;
    unsigned int tcsb            : 1;
    unsigned int sbsb            : 1;
    unsigned int sesb            : 1;
    unsigned int tcsa            : 1;
    unsigned int sbsa            : 1;
    unsigned int sesa            : 1;
} avr32_eray_swnit_t;



typedef struct avr32_eray_acs_t {
    unsigned int                 :19;
    unsigned int sbvb            : 1;
    unsigned int cib             : 1;
    unsigned int cedb            : 1;
    unsigned int sedb            : 1;
    unsigned int vfrb            : 1;
    unsigned int                 : 3;
    unsigned int sbva            : 1;
    unsigned int cia             : 1;
    unsigned int ceda            : 1;
    unsigned int seda            : 1;
    unsigned int vfra            : 1;
} avr32_eray_acs_t;



typedef struct avr32_eray_esid1_t {
    unsigned int                 :16;
    unsigned int rxeb            : 1;
    unsigned int rxea            : 1;
    unsigned int                 : 4;
    unsigned int eid             :10;
} avr32_eray_esid1_t;



typedef struct avr32_eray_esid2_t {
    unsigned int                 :16;
    unsigned int rxeb            : 1;
    unsigned int rxea            : 1;
    unsigned int                 : 4;
    unsigned int eid             :10;
} avr32_eray_esid2_t;



typedef struct avr32_eray_esid3_t {
    unsigned int                 :16;
    unsigned int rxeb            : 1;
    unsigned int rxea            : 1;
    unsigned int                 : 4;
    unsigned int eid             :10;
} avr32_eray_esid3_t;



typedef struct avr32_eray_esid4_t {
    unsigned int                 :16;
    unsigned int rxeb            : 1;
    unsigned int rxea            : 1;
    unsigned int                 : 4;
    unsigned int eid             :10;
} avr32_eray_esid4_t;



typedef struct avr32_eray_esid5_t {
    unsigned int                 :16;
    unsigned int rxeb            : 1;
    unsigned int rxea            : 1;
    unsigned int                 : 4;
    unsigned int eid             :10;
} avr32_eray_esid5_t;



typedef struct avr32_eray_esid6_t {
    unsigned int                 :16;
    unsigned int rxeb            : 1;
    unsigned int rxea            : 1;
    unsigned int                 : 4;
    unsigned int eid             :10;
} avr32_eray_esid6_t;



typedef struct avr32_eray_esid7_t {
    unsigned int                 :16;
    unsigned int rxeb            : 1;
    unsigned int rxea            : 1;
    unsigned int                 : 4;
    unsigned int eid             :10;
} avr32_eray_esid7_t;



typedef struct avr32_eray_esid8_t {
    unsigned int                 :16;
    unsigned int rxeb            : 1;
    unsigned int rxea            : 1;
    unsigned int                 : 4;
    unsigned int eid             :10;
} avr32_eray_esid8_t;



typedef struct avr32_eray_esid9_t {
    unsigned int                 :16;
    unsigned int rxeb            : 1;
    unsigned int rxea            : 1;
    unsigned int                 : 4;
    unsigned int eid             :10;
} avr32_eray_esid9_t;



typedef struct avr32_eray_esid10_t {
    unsigned int                 :16;
    unsigned int rxeb            : 1;
    unsigned int rxea            : 1;
    unsigned int                 : 4;
    unsigned int eid             :10;
} avr32_eray_esid10_t;



typedef struct avr32_eray_esid11_t {
    unsigned int                 :16;
    unsigned int rxeb            : 1;
    unsigned int rxea            : 1;
    unsigned int                 : 4;
    unsigned int eid             :10;
} avr32_eray_esid11_t;



typedef struct avr32_eray_esid12_t {
    unsigned int                 :16;
    unsigned int rxeb            : 1;
    unsigned int rxea            : 1;
    unsigned int                 : 4;
    unsigned int eid             :10;
} avr32_eray_esid12_t;



typedef struct avr32_eray_esid13_t {
    unsigned int                 :16;
    unsigned int rxeb            : 1;
    unsigned int rxea            : 1;
    unsigned int                 : 4;
    unsigned int eid             :10;
} avr32_eray_esid13_t;



typedef struct avr32_eray_esid14_t {
    unsigned int                 :16;
    unsigned int rxeb            : 1;
    unsigned int rxea            : 1;
    unsigned int                 : 4;
    unsigned int eid             :10;
} avr32_eray_esid14_t;



typedef struct avr32_eray_esid15_t {
    unsigned int                 :16;
    unsigned int rxeb            : 1;
    unsigned int rxea            : 1;
    unsigned int                 : 4;
    unsigned int eid             :10;
} avr32_eray_esid15_t;



typedef struct avr32_eray_osid1_t {
    unsigned int                 :16;
    unsigned int rxob            : 1;
    unsigned int rxoa            : 1;
    unsigned int                 : 4;
    unsigned int oid             :10;
} avr32_eray_osid1_t;



typedef struct avr32_eray_osid2_t {
    unsigned int                 :16;
    unsigned int rxob            : 1;
    unsigned int rxoa            : 1;
    unsigned int                 : 4;
    unsigned int oid             :10;
} avr32_eray_osid2_t;



typedef struct avr32_eray_osid3_t {
    unsigned int                 :16;
    unsigned int rxob            : 1;
    unsigned int rxoa            : 1;
    unsigned int                 : 4;
    unsigned int oid             :10;
} avr32_eray_osid3_t;



typedef struct avr32_eray_osid4_t {
    unsigned int                 :16;
    unsigned int rxob            : 1;
    unsigned int rxoa            : 1;
    unsigned int                 : 4;
    unsigned int oid             :10;
} avr32_eray_osid4_t;



typedef struct avr32_eray_osid5_t {
    unsigned int                 :16;
    unsigned int rxob            : 1;
    unsigned int rxoa            : 1;
    unsigned int                 : 4;
    unsigned int oid             :10;
} avr32_eray_osid5_t;



typedef struct avr32_eray_osid6_t {
    unsigned int                 :16;
    unsigned int rxob            : 1;
    unsigned int rxoa            : 1;
    unsigned int                 : 4;
    unsigned int oid             :10;
} avr32_eray_osid6_t;



typedef struct avr32_eray_osid7_t {
    unsigned int                 :16;
    unsigned int rxob            : 1;
    unsigned int rxoa            : 1;
    unsigned int                 : 4;
    unsigned int oid             :10;
} avr32_eray_osid7_t;



typedef struct avr32_eray_osid8_t {
    unsigned int                 :16;
    unsigned int rxob            : 1;
    unsigned int rxoa            : 1;
    unsigned int                 : 4;
    unsigned int oid             :10;
} avr32_eray_osid8_t;



typedef struct avr32_eray_osid9_t {
    unsigned int                 :16;
    unsigned int rxob            : 1;
    unsigned int rxoa            : 1;
    unsigned int                 : 4;
    unsigned int oid             :10;
} avr32_eray_osid9_t;



typedef struct avr32_eray_osid10_t {
    unsigned int                 :16;
    unsigned int rxob            : 1;
    unsigned int rxoa            : 1;
    unsigned int                 : 4;
    unsigned int oid             :10;
} avr32_eray_osid10_t;



typedef struct avr32_eray_osid11_t {
    unsigned int                 :16;
    unsigned int rxob            : 1;
    unsigned int rxoa            : 1;
    unsigned int                 : 4;
    unsigned int oid             :10;
} avr32_eray_osid11_t;



typedef struct avr32_eray_osid12_t {
    unsigned int                 :16;
    unsigned int rxob            : 1;
    unsigned int rxoa            : 1;
    unsigned int                 : 4;
    unsigned int oid             :10;
} avr32_eray_osid12_t;



typedef struct avr32_eray_osid13_t {
    unsigned int                 :16;
    unsigned int rxob            : 1;
    unsigned int rxoa            : 1;
    unsigned int                 : 4;
    unsigned int oid             :10;
} avr32_eray_osid13_t;



typedef struct avr32_eray_osid14_t {
    unsigned int                 :16;
    unsigned int rxob            : 1;
    unsigned int rxoa            : 1;
    unsigned int                 : 4;
    unsigned int oid             :10;
} avr32_eray_osid14_t;



typedef struct avr32_eray_osid15_t {
    unsigned int                 :16;
    unsigned int rxob            : 1;
    unsigned int rxoa            : 1;
    unsigned int                 : 4;
    unsigned int oid             :10;
} avr32_eray_osid15_t;



typedef struct avr32_eray_mrc_t {
    unsigned int                 : 5;
    unsigned int splm            : 1;
    unsigned int sec             : 2;
    unsigned int lcb             : 8;
    unsigned int ffb             : 8;
    unsigned int fdb             : 8;
} avr32_eray_mrc_t;



typedef struct avr32_eray_frf_t {
    unsigned int                 : 7;
    unsigned int rnf             : 1;
    unsigned int rss             : 1;
    unsigned int cyf             : 7;
    unsigned int                 : 3;
    unsigned int fid             :11;
    unsigned int ch              : 2;
} avr32_eray_frf_t;



typedef struct avr32_eray_frfm_t {
    unsigned int                 :19;
    unsigned int mfid            :11;
    unsigned int                 : 2;
} avr32_eray_frfm_t;



typedef struct avr32_eray_fcl_t {
    unsigned int                 :24;
    unsigned int cl              : 8;
} avr32_eray_fcl_t;



typedef struct avr32_eray_mhds_t {
    unsigned int                 : 1;
    unsigned int mbu             : 7;
    unsigned int                 : 1;
    unsigned int mbt             : 7;
    unsigned int                 : 1;
    unsigned int fmb             : 7;
    unsigned int cram            : 1;
    unsigned int mfmb            : 1;
    unsigned int fmbd            : 1;
    unsigned int ptbf2           : 1;
    unsigned int ptbf1           : 1;
    unsigned int pmr             : 1;
    unsigned int pobf            : 1;
    unsigned int pibf            : 1;
} avr32_eray_mhds_t;



typedef struct avr32_eray_ldts_t {
    unsigned int                 : 5;
    unsigned int ldtb            :11;
    unsigned int                 : 5;
    unsigned int ldta            :11;
} avr32_eray_ldts_t;



typedef struct avr32_eray_fsr_t {
    unsigned int                 :16;
    unsigned int rffl            : 8;
    unsigned int                 : 5;
    unsigned int rfo             : 1;
    unsigned int rfcl            : 1;
    unsigned int rfne            : 1;
} avr32_eray_fsr_t;



typedef struct avr32_eray_mhdf_t {
    unsigned int                 :23;
    unsigned int wahp            : 1;
    unsigned int tnsb            : 1;
    unsigned int tnsa            : 1;
    unsigned int tbfb            : 1;
    unsigned int tbfa            : 1;
    unsigned int fnfb            : 1;
    unsigned int fnfa            : 1;
    unsigned int snub            : 1;
    unsigned int snua            : 1;
} avr32_eray_mhdf_t;



typedef struct avr32_eray_crel_t {
    unsigned int rel             : 4;
    unsigned int step            : 8;
    unsigned int year            : 4;
    unsigned int mon             : 8;
    unsigned int day             : 8;
} avr32_eray_crel_t;



typedef struct avr32_eray_wrhs1_t {
    unsigned int                 : 2;
    unsigned int mbi             : 1;
    unsigned int txm             : 1;
    unsigned int ppit            : 1;
    unsigned int cfg             : 1;
    unsigned int chb             : 1;
    unsigned int cha             : 1;
    unsigned int                 : 1;
    unsigned int cyc             : 7;
    unsigned int                 : 5;
    unsigned int fid             :11;
} avr32_eray_wrhs1_t;



typedef struct avr32_eray_wrhs2_t {
    unsigned int                 : 9;
    unsigned int plc             : 7;
    unsigned int                 : 5;
    unsigned int crc             :11;
} avr32_eray_wrhs2_t;



typedef struct avr32_eray_wrhs3_t {
    unsigned int                 :21;
    unsigned int dp              :11;
} avr32_eray_wrhs3_t;



typedef struct avr32_eray_ibcm_t {
    unsigned int                 :13;
    unsigned int stxrs           : 1;
    unsigned int ldss            : 1;
    unsigned int lhss            : 1;
    unsigned int                 :13;
    unsigned int stxrh           : 1;
    unsigned int ldsh            : 1;
    unsigned int lhsh            : 1;
} avr32_eray_ibcm_t;



typedef struct avr32_eray_ibcr_t {
    unsigned int ibsys           : 1;
    unsigned int                 : 8;
    unsigned int ibrs            : 7;
    unsigned int ibsyh           : 1;
    unsigned int                 : 8;
    unsigned int ibrh            : 7;
} avr32_eray_ibcr_t;



typedef struct avr32_eray_rdhs1_t {
    unsigned int                 : 2;
    unsigned int mbi             : 1;
    unsigned int txm             : 1;
    unsigned int ppit            : 1;
    unsigned int cfg             : 1;
    unsigned int chb             : 1;
    unsigned int cha             : 1;
    unsigned int                 : 1;
    unsigned int cyc             : 7;
    unsigned int                 : 5;
    unsigned int fid             :11;
} avr32_eray_rdhs1_t;



typedef struct avr32_eray_rdhs2_t {
    unsigned int                 : 1;
    unsigned int plr             : 7;
    unsigned int                 : 1;
    unsigned int plc             : 7;
    unsigned int                 : 5;
    unsigned int crc             :11;
} avr32_eray_rdhs2_t;



typedef struct avr32_eray_rdhs3_t {
    unsigned int                 : 2;
    unsigned int res             : 1;
    unsigned int ppi             : 1;
    unsigned int nfi             : 1;
    unsigned int syn             : 1;
    unsigned int sfi             : 1;
    unsigned int rci             : 1;
    unsigned int                 : 2;
    unsigned int rcc             : 6;
    unsigned int                 : 5;
    unsigned int dp              :11;
} avr32_eray_rdhs3_t;



typedef struct avr32_eray_mbs_t {
    unsigned int                 : 2;
    unsigned int ress            : 1;
    unsigned int ppis            : 1;
    unsigned int nfis            : 1;
    unsigned int syns            : 1;
    unsigned int sfis            : 1;
    unsigned int rcis            : 1;
    unsigned int                 : 2;
    unsigned int ccs             : 6;
    unsigned int ftb             : 1;
    unsigned int fta             : 1;
    unsigned int                 : 1;
    unsigned int mlst            : 1;
    unsigned int esb             : 1;
    unsigned int esa             : 1;
    unsigned int tcib            : 1;
    unsigned int tcia            : 1;
    unsigned int svob            : 1;
    unsigned int svoa            : 1;
    unsigned int ceob            : 1;
    unsigned int ceoa            : 1;
    unsigned int seob            : 1;
    unsigned int seoa            : 1;
    unsigned int vfrb            : 1;
    unsigned int vfra            : 1;
} avr32_eray_mbs_t;



typedef struct avr32_eray_obcm_t {
    unsigned int                 :14;
    unsigned int rdsh            : 1;
    unsigned int rhsh            : 1;
    unsigned int                 :14;
    unsigned int rdss            : 1;
    unsigned int rhss            : 1;
} avr32_eray_obcm_t;



typedef struct avr32_eray_obcr_t {
    unsigned int                 : 9;
    unsigned int obrh            : 7;
    unsigned int obsys           : 1;
    unsigned int                 : 5;
    unsigned int req             : 1;
    unsigned int view            : 1;
    unsigned int                 : 1;
    unsigned int obrs            : 7;
} avr32_eray_obcr_t;



typedef struct avr32_eray_or_t {
    unsigned int                 :30;
    unsigned int sdiag2          : 1;
    unsigned int sdiag1          : 1;
} avr32_eray_or_t;



typedef struct avr32_eray_ccr_t {
    unsigned int                 :12;
    unsigned int bn              : 4;
    unsigned int                 : 5;
    unsigned int ckdiv           :11;
} avr32_eray_ccr_t;



typedef struct avr32_eray_ovr_t {
    unsigned int                 :30;
    unsigned int en2             : 1;
    unsigned int en1             : 1;
} avr32_eray_ovr_t;



typedef struct avr32_eray_tsr_t {
    unsigned int stat2           :16;
    unsigned int stat1           :16;
} avr32_eray_tsr_t;



typedef struct avr32_eray_sr_t {
    unsigned int                 :22;
    unsigned int diagr2          : 1;
    unsigned int diagr1          : 1;
    unsigned int                 : 6;
    unsigned int sa2             : 1;
    unsigned int sa1             : 1;
} avr32_eray_sr_t;



typedef struct avr32_eray_scr_t {
    unsigned int                 :30;
    unsigned int sa2             : 1;
    unsigned int sa1             : 1;
} avr32_eray_scr_t;



typedef struct avr32_eray_imr_t {
    unsigned int                 :30;
    unsigned int saim2           : 1;
    unsigned int saim1           : 1;
} avr32_eray_imr_t;



typedef struct avr32_eray_ier_t {
    unsigned int                 :30;
    unsigned int saim2           : 1;
    unsigned int saim1           : 1;
} avr32_eray_ier_t;



typedef struct avr32_eray_idr_t {
    unsigned int                 :30;
    unsigned int saim2           : 1;
    unsigned int saim1           : 1;
} avr32_eray_idr_t;



typedef struct avr32_eray_t {
  union {
    const unsigned long                  version   ;//0x0000
    const avr32_eray_version_t           VERSION   ;
  };
    const unsigned long                  cust1     ;//0x0004
    const unsigned long                  cust2     ;//0x0008
    const unsigned long                  cust3     ;//0x000c
  union {
          unsigned long                  test1     ;//0x0010
          avr32_eray_test1_t             TEST1     ;
  };
  union {
          unsigned long                  test2     ;//0x0014
          avr32_eray_test2_t             TEST2     ;
  };
          unsigned int                   :32       ;//0x0018
  union {
          unsigned long                  lck       ;//0x001c
          avr32_eray_lck_t               LCK       ;
  };
  union {
          unsigned long                  eir       ;//0x0020
          avr32_eray_eir_t               EIR       ;
  };
  union {
          unsigned long                  sir       ;//0x0024
          avr32_eray_sir_t               SIR       ;
  };
  union {
          unsigned long                  eils      ;//0x0028
          avr32_eray_eils_t              EILS      ;
  };
  union {
          unsigned long                  sils      ;//0x002c
          avr32_eray_sils_t              SILS      ;
  };
  union {
          unsigned long                  eies      ;//0x0030
          avr32_eray_eies_t              EIES      ;
  };
  union {
          unsigned long                  eier      ;//0x0034
          avr32_eray_eier_t              EIER      ;
  };
  union {
          unsigned long                  sies      ;//0x0038
          avr32_eray_sies_t              SIES      ;
  };
  union {
          unsigned long                  sier      ;//0x003c
          avr32_eray_sier_t              SIER      ;
  };
  union {
          unsigned long                  ile       ;//0x0040
          avr32_eray_ile_t               ILE       ;
  };
  union {
          unsigned long                  t0c       ;//0x0044
          avr32_eray_t0c_t               T0C       ;
  };
  union {
          unsigned long                  t1c       ;//0x0048
          avr32_eray_t1c_t               T1C       ;
  };
  union {
          unsigned long                  stpw1     ;//0x004c
          avr32_eray_stpw1_t             STPW1     ;
  };
  union {
          unsigned long                  stpw2     ;//0x0050
          avr32_eray_stpw2_t             STPW2     ;
  };
          unsigned int                   :32       ;//0x0054
          unsigned int                   :32       ;//0x0058
          unsigned int                   :32       ;//0x005c
          unsigned int                   :32       ;//0x0060
          unsigned int                   :32       ;//0x0064
          unsigned int                   :32       ;//0x0068
          unsigned int                   :32       ;//0x006c
          unsigned int                   :32       ;//0x0070
          unsigned int                   :32       ;//0x0074
          unsigned int                   :32       ;//0x0078
          unsigned int                   :32       ;//0x007c
  union {
          unsigned long                  succ1     ;//0x0080
          avr32_eray_succ1_t             SUCC1     ;
  };
  union {
          unsigned long                  succ2     ;//0x0084
          avr32_eray_succ2_t             SUCC2     ;
  };
  union {
          unsigned long                  succ3     ;//0x0088
          avr32_eray_succ3_t             SUCC3     ;
  };
  union {
          unsigned long                  nemc      ;//0x008c
          avr32_eray_nemc_t              NEMC      ;
  };
  union {
          unsigned long                  prtc1     ;//0x0090
          avr32_eray_prtc1_t             PRTC1     ;
  };
  union {
          unsigned long                  prtc2     ;//0x0094
          avr32_eray_prtc2_t             PRTC2     ;
  };
  union {
          unsigned long                  mhdc      ;//0x0098
          avr32_eray_mhdc_t              MHDC      ;
  };
          unsigned int                   :32       ;//0x009c
  union {
          unsigned long                  gtuc1     ;//0x00a0
          avr32_eray_gtuc1_t             GTUC1     ;
  };
  union {
          unsigned long                  gtuc2     ;//0x00a4
          avr32_eray_gtuc2_t             GTUC2     ;
  };
  union {
          unsigned long                  gtuc3     ;//0x00a8
          avr32_eray_gtuc3_t             GTUC3     ;
  };
  union {
          unsigned long                  gtuc4     ;//0x00ac
          avr32_eray_gtuc4_t             GTUC4     ;
  };
  union {
          unsigned long                  gtuc5     ;//0x00b0
          avr32_eray_gtuc5_t             GTUC5     ;
  };
  union {
          unsigned long                  gtuc6     ;//0x00b4
          avr32_eray_gtuc6_t             GTUC6     ;
  };
  union {
          unsigned long                  gtuc7     ;//0x00b8
          avr32_eray_gtuc7_t             GTUC7     ;
  };
  union {
          unsigned long                  gtuc8     ;//0x00bc
          avr32_eray_gtuc8_t             GTUC8     ;
  };
  union {
          unsigned long                  gtuc9     ;//0x00c0
          avr32_eray_gtuc9_t             GTUC9     ;
  };
  union {
          unsigned long                  gtuc10    ;//0x00c4
          avr32_eray_gtuc10_t            GTUC10    ;
  };
  union {
          unsigned long                  gtuc11    ;//0x00c8
          avr32_eray_gtuc11_t            GTUC11    ;
  };
          unsigned int                   :32       ;//0x00cc
          unsigned int                   :32       ;//0x00d0
          unsigned int                   :32       ;//0x00d4
          unsigned int                   :32       ;//0x00d8
          unsigned int                   :32       ;//0x00dc
          unsigned int                   :32       ;//0x00e0
          unsigned int                   :32       ;//0x00e4
          unsigned int                   :32       ;//0x00e8
          unsigned int                   :32       ;//0x00ec
          unsigned int                   :32       ;//0x00f0
          unsigned int                   :32       ;//0x00f4
          unsigned int                   :32       ;//0x00f8
          unsigned int                   :32       ;//0x00fc
  union {
          unsigned long                  ccsv      ;//0x0100
          avr32_eray_ccsv_t              CCSV      ;
  };
  union {
          unsigned long                  ccev      ;//0x0104
          avr32_eray_ccev_t              CCEV      ;
  };
          unsigned int                   :32       ;//0x0108
          unsigned int                   :32       ;//0x010c
  union {
          unsigned long                  scv       ;//0x0110
          avr32_eray_scv_t               SCV       ;
  };
  union {
          unsigned long                  mtccv     ;//0x0114
          avr32_eray_mtccv_t             MTCCV     ;
  };
  union {
          unsigned long                  rcv       ;//0x0118
          avr32_eray_rcv_t               RCV       ;
  };
  union {
          unsigned long                  ocv       ;//0x011c
          avr32_eray_ocv_t               OCV       ;
  };
  union {
          unsigned long                  sfs       ;//0x0120
          avr32_eray_sfs_t               SFS       ;
  };
  union {
          unsigned long                  swnit     ;//0x0124
          avr32_eray_swnit_t             SWNIT     ;
  };
  union {
          unsigned long                  acs       ;//0x0128
          avr32_eray_acs_t               ACS       ;
  };
          unsigned int                   :32       ;//0x012c
  union {
          unsigned long                  esid1     ;//0x0130
          avr32_eray_esid1_t             ESID1     ;
  };
  union {
          unsigned long                  esid2     ;//0x0134
          avr32_eray_esid2_t             ESID2     ;
  };
  union {
          unsigned long                  esid3     ;//0x0138
          avr32_eray_esid3_t             ESID3     ;
  };
  union {
          unsigned long                  esid4     ;//0x013c
          avr32_eray_esid4_t             ESID4     ;
  };
  union {
          unsigned long                  esid5     ;//0x0140
          avr32_eray_esid5_t             ESID5     ;
  };
  union {
          unsigned long                  esid6     ;//0x0144
          avr32_eray_esid6_t             ESID6     ;
  };
  union {
          unsigned long                  esid7     ;//0x0148
          avr32_eray_esid7_t             ESID7     ;
  };
  union {
          unsigned long                  esid8     ;//0x014c
          avr32_eray_esid8_t             ESID8     ;
  };
  union {
          unsigned long                  esid9     ;//0x0150
          avr32_eray_esid9_t             ESID9     ;
  };
  union {
          unsigned long                  esid10    ;//0x0154
          avr32_eray_esid10_t            ESID10    ;
  };
  union {
          unsigned long                  esid11    ;//0x0158
          avr32_eray_esid11_t            ESID11    ;
  };
  union {
          unsigned long                  esid12    ;//0x015c
          avr32_eray_esid12_t            ESID12    ;
  };
  union {
          unsigned long                  esid13    ;//0x0160
          avr32_eray_esid13_t            ESID13    ;
  };
  union {
          unsigned long                  esid14    ;//0x0164
          avr32_eray_esid14_t            ESID14    ;
  };
  union {
          unsigned long                  esid15    ;//0x0168
          avr32_eray_esid15_t            ESID15    ;
  };
          unsigned int                   :32       ;//0x016c
  union {
          unsigned long                  osid1     ;//0x0170
          avr32_eray_osid1_t             OSID1     ;
  };
  union {
          unsigned long                  osid2     ;//0x0174
          avr32_eray_osid2_t             OSID2     ;
  };
  union {
          unsigned long                  osid3     ;//0x0178
          avr32_eray_osid3_t             OSID3     ;
  };
  union {
          unsigned long                  osid4     ;//0x017c
          avr32_eray_osid4_t             OSID4     ;
  };
  union {
          unsigned long                  osid5     ;//0x0180
          avr32_eray_osid5_t             OSID5     ;
  };
  union {
          unsigned long                  osid6     ;//0x0184
          avr32_eray_osid6_t             OSID6     ;
  };
  union {
          unsigned long                  osid7     ;//0x0188
          avr32_eray_osid7_t             OSID7     ;
  };
  union {
          unsigned long                  osid8     ;//0x018c
          avr32_eray_osid8_t             OSID8     ;
  };
  union {
          unsigned long                  osid9     ;//0x0190
          avr32_eray_osid9_t             OSID9     ;
  };
  union {
          unsigned long                  osid10    ;//0x0194
          avr32_eray_osid10_t            OSID10    ;
  };
  union {
          unsigned long                  osid11    ;//0x0198
          avr32_eray_osid11_t            OSID11    ;
  };
  union {
          unsigned long                  osid12    ;//0x019c
          avr32_eray_osid12_t            OSID12    ;
  };
  union {
          unsigned long                  osid13    ;//0x01a0
          avr32_eray_osid13_t            OSID13    ;
  };
  union {
          unsigned long                  osid14    ;//0x01a4
          avr32_eray_osid14_t            OSID14    ;
  };
  union {
          unsigned long                  osid15    ;//0x01a8
          avr32_eray_osid15_t            OSID15    ;
  };
          unsigned int                   :32       ;//0x01ac
          unsigned long                  nmv1      ;//0x01b0
          unsigned long                  nmv2      ;//0x01b4
          unsigned long                  nmv3      ;//0x01b8
          unsigned int                   :32       ;//0x01bc
          unsigned int                   :32       ;//0x01c0
          unsigned int                   :32       ;//0x01c4
          unsigned int                   :32       ;//0x01c8
          unsigned int                   :32       ;//0x01cc
          unsigned int                   :32       ;//0x01d0
          unsigned int                   :32       ;//0x01d4
          unsigned int                   :32       ;//0x01d8
          unsigned int                   :32       ;//0x01dc
          unsigned int                   :32       ;//0x01e0
          unsigned int                   :32       ;//0x01e4
          unsigned int                   :32       ;//0x01e8
          unsigned int                   :32       ;//0x01ec
          unsigned int                   :32       ;//0x01f0
          unsigned int                   :32       ;//0x01f4
          unsigned int                   :32       ;//0x01f8
          unsigned int                   :32       ;//0x01fc
          unsigned int                   :32       ;//0x0200
          unsigned int                   :32       ;//0x0204
          unsigned int                   :32       ;//0x0208
          unsigned int                   :32       ;//0x020c
          unsigned int                   :32       ;//0x0210
          unsigned int                   :32       ;//0x0214
          unsigned int                   :32       ;//0x0218
          unsigned int                   :32       ;//0x021c
          unsigned int                   :32       ;//0x0220
          unsigned int                   :32       ;//0x0224
          unsigned int                   :32       ;//0x0228
          unsigned int                   :32       ;//0x022c
          unsigned int                   :32       ;//0x0230
          unsigned int                   :32       ;//0x0234
          unsigned int                   :32       ;//0x0238
          unsigned int                   :32       ;//0x023c
          unsigned int                   :32       ;//0x0240
          unsigned int                   :32       ;//0x0244
          unsigned int                   :32       ;//0x0248
          unsigned int                   :32       ;//0x024c
          unsigned int                   :32       ;//0x0250
          unsigned int                   :32       ;//0x0254
          unsigned int                   :32       ;//0x0258
          unsigned int                   :32       ;//0x025c
          unsigned int                   :32       ;//0x0260
          unsigned int                   :32       ;//0x0264
          unsigned int                   :32       ;//0x0268
          unsigned int                   :32       ;//0x026c
          unsigned int                   :32       ;//0x0270
          unsigned int                   :32       ;//0x0274
          unsigned int                   :32       ;//0x0278
          unsigned int                   :32       ;//0x027c
          unsigned int                   :32       ;//0x0280
          unsigned int                   :32       ;//0x0284
          unsigned int                   :32       ;//0x0288
          unsigned int                   :32       ;//0x028c
          unsigned int                   :32       ;//0x0290
          unsigned int                   :32       ;//0x0294
          unsigned int                   :32       ;//0x0298
          unsigned int                   :32       ;//0x029c
          unsigned int                   :32       ;//0x02a0
          unsigned int                   :32       ;//0x02a4
          unsigned int                   :32       ;//0x02a8
          unsigned int                   :32       ;//0x02ac
          unsigned int                   :32       ;//0x02b0
          unsigned int                   :32       ;//0x02b4
          unsigned int                   :32       ;//0x02b8
          unsigned int                   :32       ;//0x02bc
          unsigned int                   :32       ;//0x02c0
          unsigned int                   :32       ;//0x02c4
          unsigned int                   :32       ;//0x02c8
          unsigned int                   :32       ;//0x02cc
          unsigned int                   :32       ;//0x02d0
          unsigned int                   :32       ;//0x02d4
          unsigned int                   :32       ;//0x02d8
          unsigned int                   :32       ;//0x02dc
          unsigned int                   :32       ;//0x02e0
          unsigned int                   :32       ;//0x02e4
          unsigned int                   :32       ;//0x02e8
          unsigned int                   :32       ;//0x02ec
          unsigned int                   :32       ;//0x02f0
          unsigned int                   :32       ;//0x02f4
          unsigned int                   :32       ;//0x02f8
          unsigned int                   :32       ;//0x02fc
  union {
          unsigned long                  mrc       ;//0x0300
          avr32_eray_mrc_t               MRC       ;
  };
  union {
          unsigned long                  frf       ;//0x0304
          avr32_eray_frf_t               FRF       ;
  };
  union {
          unsigned long                  frfm      ;//0x0308
          avr32_eray_frfm_t              FRFM      ;
  };
  union {
          unsigned long                  fcl       ;//0x030c
          avr32_eray_fcl_t               FCL       ;
  };
  union {
          unsigned long                  mhds      ;//0x0310
          avr32_eray_mhds_t              MHDS      ;
  };
  union {
          unsigned long                  ldts      ;//0x0314
          avr32_eray_ldts_t              LDTS      ;
  };
  union {
          unsigned long                  fsr       ;//0x0318
          avr32_eray_fsr_t               FSR       ;
  };
  union {
          unsigned long                  mhdf      ;//0x031c
          avr32_eray_mhdf_t              MHDF      ;
  };
          unsigned long                  txrq1     ;//0x0320
          unsigned long                  txrq2     ;//0x0324
          unsigned long                  txrq3     ;//0x0328
          unsigned long                  txrq4     ;//0x032c
          unsigned long                  ndat1     ;//0x0330
          unsigned long                  ndat2     ;//0x0334
          unsigned long                  ndat3     ;//0x0338
          unsigned long                  ndat4     ;//0x033c
          unsigned long                  mbsc1     ;//0x0340
          unsigned long                  mbsc2     ;//0x0344
          unsigned long                  mbsc3     ;//0x0348
          unsigned long                  mbsc4     ;//0x034c
          unsigned int                   :32       ;//0x0350
          unsigned int                   :32       ;//0x0354
          unsigned int                   :32       ;//0x0358
          unsigned int                   :32       ;//0x035c
          unsigned int                   :32       ;//0x0360
          unsigned int                   :32       ;//0x0364
          unsigned int                   :32       ;//0x0368
          unsigned int                   :32       ;//0x036c
          unsigned int                   :32       ;//0x0370
          unsigned int                   :32       ;//0x0374
          unsigned int                   :32       ;//0x0378
          unsigned int                   :32       ;//0x037c
          unsigned int                   :32       ;//0x0380
          unsigned int                   :32       ;//0x0384
          unsigned int                   :32       ;//0x0388
          unsigned int                   :32       ;//0x038c
          unsigned int                   :32       ;//0x0390
          unsigned int                   :32       ;//0x0394
          unsigned int                   :32       ;//0x0398
          unsigned int                   :32       ;//0x039c
          unsigned int                   :32       ;//0x03a0
          unsigned int                   :32       ;//0x03a4
          unsigned int                   :32       ;//0x03a8
          unsigned int                   :32       ;//0x03ac
          unsigned int                   :32       ;//0x03b0
          unsigned int                   :32       ;//0x03b4
          unsigned int                   :32       ;//0x03b8
          unsigned int                   :32       ;//0x03bc
          unsigned int                   :32       ;//0x03c0
          unsigned int                   :32       ;//0x03c4
          unsigned int                   :32       ;//0x03c8
          unsigned int                   :32       ;//0x03cc
          unsigned int                   :32       ;//0x03d0
          unsigned int                   :32       ;//0x03d4
          unsigned int                   :32       ;//0x03d8
          unsigned int                   :32       ;//0x03dc
          unsigned int                   :32       ;//0x03e0
          unsigned int                   :32       ;//0x03e4
          unsigned int                   :32       ;//0x03e8
          unsigned int                   :32       ;//0x03ec
  union {
          unsigned long                  crel      ;//0x03f0
          avr32_eray_crel_t              CREL      ;
  };
          unsigned long                  endn      ;//0x03f4
          unsigned int                   :32       ;//0x03f8
          unsigned int                   :32       ;//0x03fc
          unsigned long                  wrds      [64];//0x0400
  union {
          unsigned long                  wrhs1     ;//0x0500
          avr32_eray_wrhs1_t             WRHS1     ;
  };
  union {
          unsigned long                  wrhs2     ;//0x0504
          avr32_eray_wrhs2_t             WRHS2     ;
  };
  union {
          unsigned long                  wrhs3     ;//0x0508
          avr32_eray_wrhs3_t             WRHS3     ;
  };
          unsigned int                   :32       ;//0x050c
  union {
          unsigned long                  ibcm      ;//0x0510
          avr32_eray_ibcm_t              IBCM      ;
  };
  union {
          unsigned long                  ibcr      ;//0x0514
          avr32_eray_ibcr_t              IBCR      ;
  };
          unsigned int                   :32       ;//0x0518
          unsigned int                   :32       ;//0x051c
          unsigned int                   :32       ;//0x0520
          unsigned int                   :32       ;//0x0524
          unsigned int                   :32       ;//0x0528
          unsigned int                   :32       ;//0x052c
          unsigned int                   :32       ;//0x0530
          unsigned int                   :32       ;//0x0534
          unsigned int                   :32       ;//0x0538
          unsigned int                   :32       ;//0x053c
          unsigned int                   :32       ;//0x0540
          unsigned int                   :32       ;//0x0544
          unsigned int                   :32       ;//0x0548
          unsigned int                   :32       ;//0x054c
          unsigned int                   :32       ;//0x0550
          unsigned int                   :32       ;//0x0554
          unsigned int                   :32       ;//0x0558
          unsigned int                   :32       ;//0x055c
          unsigned int                   :32       ;//0x0560
          unsigned int                   :32       ;//0x0564
          unsigned int                   :32       ;//0x0568
          unsigned int                   :32       ;//0x056c
          unsigned int                   :32       ;//0x0570
          unsigned int                   :32       ;//0x0574
          unsigned int                   :32       ;//0x0578
          unsigned int                   :32       ;//0x057c
          unsigned int                   :32       ;//0x0580
          unsigned int                   :32       ;//0x0584
          unsigned int                   :32       ;//0x0588
          unsigned int                   :32       ;//0x058c
          unsigned int                   :32       ;//0x0590
          unsigned int                   :32       ;//0x0594
          unsigned int                   :32       ;//0x0598
          unsigned int                   :32       ;//0x059c
          unsigned int                   :32       ;//0x05a0
          unsigned int                   :32       ;//0x05a4
          unsigned int                   :32       ;//0x05a8
          unsigned int                   :32       ;//0x05ac
          unsigned int                   :32       ;//0x05b0
          unsigned int                   :32       ;//0x05b4
          unsigned int                   :32       ;//0x05b8
          unsigned int                   :32       ;//0x05bc
          unsigned int                   :32       ;//0x05c0
          unsigned int                   :32       ;//0x05c4
          unsigned int                   :32       ;//0x05c8
          unsigned int                   :32       ;//0x05cc
          unsigned int                   :32       ;//0x05d0
          unsigned int                   :32       ;//0x05d4
          unsigned int                   :32       ;//0x05d8
          unsigned int                   :32       ;//0x05dc
          unsigned int                   :32       ;//0x05e0
          unsigned int                   :32       ;//0x05e4
          unsigned int                   :32       ;//0x05e8
          unsigned int                   :32       ;//0x05ec
          unsigned int                   :32       ;//0x05f0
          unsigned int                   :32       ;//0x05f4
          unsigned int                   :32       ;//0x05f8
          unsigned int                   :32       ;//0x05fc
          unsigned long                  rdds      [64];//0x0600
  union {
          unsigned long                  rdhs1     ;//0x0700
          avr32_eray_rdhs1_t             RDHS1     ;
  };
  union {
          unsigned long                  rdhs2     ;//0x0704
          avr32_eray_rdhs2_t             RDHS2     ;
  };
  union {
          unsigned long                  rdhs3     ;//0x0708
          avr32_eray_rdhs3_t             RDHS3     ;
  };
  union {
          unsigned long                  mbs       ;//0x070c
          avr32_eray_mbs_t               MBS       ;
  };
  union {
          unsigned long                  obcm      ;//0x0710
          avr32_eray_obcm_t              OBCM      ;
  };
  union {
          unsigned long                  obcr      ;//0x0714
          avr32_eray_obcr_t              OBCR      ;
  };
          unsigned int                   :32       ;//0x0718
          unsigned int                   :32       ;//0x071c
          unsigned int                   :32       ;//0x0720
          unsigned int                   :32       ;//0x0724
          unsigned int                   :32       ;//0x0728
          unsigned int                   :32       ;//0x072c
          unsigned int                   :32       ;//0x0730
          unsigned int                   :32       ;//0x0734
          unsigned int                   :32       ;//0x0738
          unsigned int                   :32       ;//0x073c
          unsigned int                   :32       ;//0x0740
          unsigned int                   :32       ;//0x0744
          unsigned int                   :32       ;//0x0748
          unsigned int                   :32       ;//0x074c
          unsigned int                   :32       ;//0x0750
          unsigned int                   :32       ;//0x0754
          unsigned int                   :32       ;//0x0758
          unsigned int                   :32       ;//0x075c
          unsigned int                   :32       ;//0x0760
          unsigned int                   :32       ;//0x0764
          unsigned int                   :32       ;//0x0768
          unsigned int                   :32       ;//0x076c
          unsigned int                   :32       ;//0x0770
          unsigned int                   :32       ;//0x0774
          unsigned int                   :32       ;//0x0778
          unsigned int                   :32       ;//0x077c
          unsigned int                   :32       ;//0x0780
          unsigned int                   :32       ;//0x0784
          unsigned int                   :32       ;//0x0788
          unsigned int                   :32       ;//0x078c
          unsigned int                   :32       ;//0x0790
          unsigned int                   :32       ;//0x0794
          unsigned int                   :32       ;//0x0798
          unsigned int                   :32       ;//0x079c
          unsigned int                   :32       ;//0x07a0
          unsigned int                   :32       ;//0x07a4
          unsigned int                   :32       ;//0x07a8
          unsigned int                   :32       ;//0x07ac
          unsigned int                   :32       ;//0x07b0
          unsigned int                   :32       ;//0x07b4
          unsigned int                   :32       ;//0x07b8
          unsigned int                   :32       ;//0x07bc
          unsigned int                   :32       ;//0x07c0
          unsigned int                   :32       ;//0x07c4
          unsigned int                   :32       ;//0x07c8
          unsigned int                   :32       ;//0x07cc
          unsigned int                   :32       ;//0x07d0
          unsigned int                   :32       ;//0x07d4
          unsigned int                   :32       ;//0x07d8
          unsigned int                   :32       ;//0x07dc
          unsigned int                   :32       ;//0x07e0
          unsigned int                   :32       ;//0x07e4
          unsigned int                   :32       ;//0x07e8
          unsigned int                   :32       ;//0x07ec
          unsigned int                   :32       ;//0x07f0
          unsigned int                   :32       ;//0x07f4
          unsigned int                   :32       ;//0x07f8
          unsigned int                   :32       ;//0x07fc
  union {
          unsigned long                  or        ;//0x0800
          avr32_eray_or_t                OR        ;
  };
  union {
          unsigned long                  ccr       ;//0x0804
          avr32_eray_ccr_t               CCR       ;
  };
  union {
          unsigned long                  ovr       ;//0x0808
          avr32_eray_ovr_t               OVR       ;
  };
  union {
    const unsigned long                  tsr       ;//0x080c
    const avr32_eray_tsr_t               TSR       ;
  };
  union {
    const unsigned long                  sr        ;//0x0810
    const avr32_eray_sr_t                SR        ;
  };
  union {
          unsigned long                  scr       ;//0x0814
          avr32_eray_scr_t               SCR       ;
  };
  union {
    const unsigned long                  imr       ;//0x0818
    const avr32_eray_imr_t               IMR       ;
  };
  union {
          unsigned long                  ier       ;//0x081c
          avr32_eray_ier_t               IER       ;
  };
  union {
          unsigned long                  idr       ;//0x0820
          avr32_eray_idr_t               IDR       ;
  };
} avr32_eray_t;



/*#ifdef __AVR32_ABI_COMPILER__*/
#endif

/*#ifdef AVR32_ERAY_102_H_INCLUDED*/
#endif

